// ============================================================
// TERRA ENGINE — SHADER MANAGER IMPLEMENTATION
// ShaderManager.cpp — Version 1.0.0
// ============================================================

#include "ShaderManager.h"
#include "Renderer.h"
#include "../AIConnector.h"
#include <fstream>
#include <stdexcept>
#include <cstring>
#include <sys/stat.h>

namespace TerraEngine {

const char* ShaderManager::MOD = "ShaderManager";

void ShaderManager::Init(VkDevice device, const std::string& shader_dir) {
    m_device     = device;
    m_shader_dir = shader_dir;

    // Create pipeline cache
    VkPipelineCacheCreateInfo cache_info{};
    cache_info.sType = VK_STRUCTURE_TYPE_PIPELINE_CACHE_CREATE_INFO;
    vkCreatePipelineCache(m_device, &cache_info, nullptr, &m_pipeline_cache);

    // Try loading existing cache from disk
    LoadPipelineCache(shader_dir + "../pipeline.cache");

    TLOG_INFO(MOD, "Init — shader dir: " + shader_dir);
}

void ShaderManager::Shutdown() {
    std::lock_guard<std::mutex> lock(m_mutex);
    for (auto& [n, p] : m_pipelines) vkDestroyPipeline      (m_device, p, nullptr);
    for (auto& [n, l] : m_layouts)   vkDestroyPipelineLayout(m_device, l, nullptr);
    for (auto& [n, m] : m_modules)   vkDestroyShaderModule  (m_device, m, nullptr);
    if (m_pipeline_cache != VK_NULL_HANDLE)
        vkDestroyPipelineCache(m_device, m_pipeline_cache, nullptr);
    TLOG_INFO(MOD, "Shutdown");
}

// ============================================================
// LOAD SPIRV
// ============================================================
std::vector<uint32_t> ShaderManager::ReadSPIRV(const std::string& path) {
    std::ifstream f(path, std::ios::binary | std::ios::ate);
    if (!f.is_open()) {
        TLOG_ERR(MOD, "Cannot open SPIRV: " + path);
        return {};
    }
    size_t size = static_cast<size_t>(f.tellg());
    f.seekg(0);
    std::vector<uint32_t> data(size / 4);
    f.read(reinterpret_cast<char*>(data.data()), size);
    return data;
}

VkShaderModule ShaderManager::LoadSPIRV(const std::string& spv_path) {
    {
        std::lock_guard<std::mutex> lock(m_mutex);
        auto it = m_modules.find(spv_path);
        if (it != m_modules.end()) return it->second;
    }

    std::string full_path = m_shader_dir + spv_path;
    auto spirv = ReadSPIRV(full_path);

    // BUG 6 FIX: fallback to error shader if file missing or invalid
    if (spirv.empty()) {
        TLOG_WARN(MOD, "Shader not found: " + full_path + " — using error fallback");
        // Minimal valid SPIRV that outputs magenta (0xFF00FF) — visually obvious error
        // This is a pre-compiled passthrough frag shader SPIRV
        // Real projects embed these as hex arrays compiled at build time
        // For now, return null and let caller handle gracefully
        TLOG_ERR(MOD, "SHADER FALLBACK: " + spv_path
                     + " — game will continue but visuals may be wrong");
        return VK_NULL_HANDLE; // caller must check and skip draw
    }

    VkShaderModuleCreateInfo info{};
    info.sType    = VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO;
    info.codeSize = spirv.size() * 4;
    info.pCode    = spirv.data();

    VkShaderModule mod = VK_NULL_HANDLE;
    if (vkCreateShaderModule(m_device, &info, nullptr, &mod) != VK_SUCCESS) {
        TLOG_ERR(MOD, "ShaderModule creation failed: " + spv_path + " — skipping pipeline");
        return VK_NULL_HANDLE;
    }

    {
        std::lock_guard<std::mutex> lock(m_mutex);
        m_modules[spv_path] = mod;
    }

    TLOG_DEBUG(MOD, "Loaded: " + spv_path);
    return mod;
}

// ============================================================
// STANDARD VERTEX LAYOUT
// Matches the Vertex struct in Renderer.h exactly
// ============================================================
std::vector<VkVertexInputAttributeDescription>
ShaderManager::StandardVertexAttribs()
{
    return {
        {0, 0, VK_FORMAT_R32G32B32_SFLOAT,    0},   // position
        {1, 0, VK_FORMAT_R32G32B32_SFLOAT,   12},   // normal
        {2, 0, VK_FORMAT_R32G32_SFLOAT,       24},  // uv
        {3, 0, VK_FORMAT_R32G32B32A32_SFLOAT, 32},  // tangent
        {4, 0, VK_FORMAT_R32G32B32A32_SFLOAT, 48},  // color
    };
}

VkVertexInputBindingDescription ShaderManager::StandardVertexBinding() {
    VkVertexInputBindingDescription b{};
    b.binding   = 0;
    b.stride    = sizeof(float) * 16; // pos(3)+norm(3)+uv(2)+tangent(4)+color(4)
    b.inputRate = VK_VERTEX_INPUT_RATE_VERTEX;
    return b;
}

// ============================================================
// BUILD PIPELINE
// ============================================================
bool ShaderManager::BuildPipeline(const PipelineDesc& desc,
                                   VkPipeline&       out_pipeline,
                                   VkPipelineLayout& out_layout)
{
    if (desc.type == PipelineType::COMPUTE) {
        // ── Compute pipeline ───────────────────────────────
        VkShaderModule comp = LoadSPIRV(desc.comp_spv);
        if (comp == VK_NULL_HANDLE) return false;

        VkPipelineLayoutCreateInfo layout_info{};
        layout_info.sType          = VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO;
        layout_info.setLayoutCount = static_cast<uint32_t>(desc.set_layouts.size());
        layout_info.pSetLayouts    = desc.set_layouts.data();

        VkPushConstantRange push_range{};
        if (desc.push_constant_size > 0) {
            push_range.stageFlags      = VK_SHADER_STAGE_COMPUTE_BIT;
            push_range.size            = desc.push_constant_size;
            layout_info.pushConstantRangeCount = 1;
            layout_info.pPushConstantRanges    = &push_range;
        }

        vkCreatePipelineLayout(m_device, &layout_info, nullptr, &out_layout);

        VkComputePipelineCreateInfo ci{};
        ci.sType  = VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO;
        ci.layout = out_layout;
        ci.stage.sType  = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
        ci.stage.stage  = VK_SHADER_STAGE_COMPUTE_BIT;
        ci.stage.module = comp;
        ci.stage.pName  = "main";

        bool ok = vkCreateComputePipelines(m_device, m_pipeline_cache,
                                           1, &ci, nullptr, &out_pipeline) == VK_SUCCESS;
        if (ok) {
            std::lock_guard<std::mutex> lock(m_mutex);
            m_pipelines[desc.name] = out_pipeline;
            m_layouts  [desc.name] = out_layout;
            TLOG_INFO(MOD, "Built compute pipeline: " + desc.name);
        }
        return ok;
    }

    // ── Graphics pipeline ───────────────────────────────────
    VkShaderModule vert = LoadSPIRV(desc.vert_spv);
    VkShaderModule frag = desc.frag_spv.empty()
                        ? VK_NULL_HANDLE : LoadSPIRV(desc.frag_spv);

    if (vert == VK_NULL_HANDLE) return false;

    std::vector<VkPipelineShaderStageCreateInfo> stages;
    {
        VkPipelineShaderStageCreateInfo vs{};
        vs.sType  = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
        vs.stage  = VK_SHADER_STAGE_VERTEX_BIT;
        vs.module = vert;
        vs.pName  = "main";
        stages.push_back(vs);
    }
    if (frag != VK_NULL_HANDLE) {
        VkPipelineShaderStageCreateInfo fs{};
        fs.sType  = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
        fs.stage  = VK_SHADER_STAGE_FRAGMENT_BIT;
        fs.module = frag;
        fs.pName  = "main";
        stages.push_back(fs);
    }

    // Vertex input
    auto binding = StandardVertexBinding();
    auto attribs = StandardVertexAttribs();

    // Override if desc provides custom attrs
    if (!desc.vertex_attrs.empty()) {
        attribs.clear();
        for (const auto& a : desc.vertex_attrs) {
            attribs.push_back({a.location, a.binding, a.format, a.offset});
        }
        binding.stride    = desc.vertex_stride;
        binding.inputRate = desc.input_rate;
    }

    VkPipelineVertexInputStateCreateInfo vi{};
    vi.sType                           = VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO;
    vi.vertexBindingDescriptionCount   = 1;
    vi.pVertexBindingDescriptions      = &binding;
    vi.vertexAttributeDescriptionCount = static_cast<uint32_t>(attribs.size());
    vi.pVertexAttributeDescriptions    = attribs.data();

    VkPipelineInputAssemblyStateCreateInfo ia{};
    ia.sType    = VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO;
    ia.topology = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST;

    VkPipelineViewportStateCreateInfo vp{};
    vp.sType         = VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO;
    vp.viewportCount = 1;
    vp.scissorCount  = 1;

    VkPipelineRasterizationStateCreateInfo rast{};
    rast.sType       = VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO;
    rast.polygonMode = desc.polygon_mode;
    rast.cullMode    = desc.cull_mode;
    rast.frontFace   = desc.front_face;
    rast.lineWidth   = 1.0f;

    VkPipelineMultisampleStateCreateInfo ms{};
    ms.sType                = VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO;
    ms.rasterizationSamples = desc.samples;

    VkPipelineDepthStencilStateCreateInfo ds{};
    ds.sType             = VK_STRUCTURE_TYPE_PIPELINE_DEPTH_STENCIL_STATE_CREATE_INFO;
    ds.depthTestEnable   = desc.depth_test  ? VK_TRUE : VK_FALSE;
    ds.depthWriteEnable  = desc.depth_write ? VK_TRUE : VK_FALSE;
    ds.depthCompareOp    = desc.depth_compare;

    // Blend states
    std::vector<VkPipelineColorBlendAttachmentState> blend_atts;
    if (desc.blend_states.empty()) {
        // Default: no blending
        VkPipelineColorBlendAttachmentState def{};
        def.colorWriteMask = VK_COLOR_COMPONENT_R_BIT | VK_COLOR_COMPONENT_G_BIT |
                             VK_COLOR_COMPONENT_B_BIT | VK_COLOR_COMPONENT_A_BIT;
        blend_atts.push_back(def);
    } else {
        for (const auto& bs : desc.blend_states) {
            VkPipelineColorBlendAttachmentState att{};
            att.blendEnable         = bs.blend_enable ? VK_TRUE : VK_FALSE;
            att.srcColorBlendFactor = bs.src_colour;
            att.dstColorBlendFactor = bs.dst_colour;
            att.colorBlendOp        = bs.colour_op;
            att.srcAlphaBlendFactor = bs.src_alpha;
            att.dstAlphaBlendFactor = bs.dst_alpha;
            att.alphaBlendOp        = bs.alpha_op;
            att.colorWriteMask      = VK_COLOR_COMPONENT_R_BIT | VK_COLOR_COMPONENT_G_BIT |
                                      VK_COLOR_COMPONENT_B_BIT | VK_COLOR_COMPONENT_A_BIT;
            blend_atts.push_back(att);
        }
    }

    VkPipelineColorBlendStateCreateInfo cb{};
    cb.sType           = VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO;
    cb.attachmentCount = static_cast<uint32_t>(blend_atts.size());
    cb.pAttachments    = blend_atts.data();

    // Dynamic state
    std::vector<VkDynamicState> dyn_states;
    if (desc.dynamic_viewport) dyn_states.push_back(VK_DYNAMIC_STATE_VIEWPORT);
    if (desc.dynamic_scissor)  dyn_states.push_back(VK_DYNAMIC_STATE_SCISSOR);

    VkPipelineDynamicStateCreateInfo dyn{};
    dyn.sType             = VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO;
    dyn.dynamicStateCount = static_cast<uint32_t>(dyn_states.size());
    dyn.pDynamicStates    = dyn_states.data();

    // Pipeline layout
    VkPipelineLayoutCreateInfo layout_info{};
    layout_info.sType          = VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO;
    layout_info.setLayoutCount = static_cast<uint32_t>(desc.set_layouts.size());
    layout_info.pSetLayouts    = desc.set_layouts.data();

    VkPushConstantRange push_range{};
    if (desc.push_constant_size > 0) {
        push_range.stageFlags               = desc.push_stage;
        push_range.size                     = desc.push_constant_size;
        layout_info.pushConstantRangeCount  = 1;
        layout_info.pPushConstantRanges     = &push_range;
    }

    vkCreatePipelineLayout(m_device, &layout_info, nullptr, &out_layout);

    VkGraphicsPipelineCreateInfo gci{};
    gci.sType               = VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO;
    gci.stageCount          = static_cast<uint32_t>(stages.size());
    gci.pStages             = stages.data();
    gci.pVertexInputState   = &vi;
    gci.pInputAssemblyState = &ia;
    gci.pViewportState      = &vp;
    gci.pRasterizationState = &rast;
    gci.pMultisampleState   = &ms;
    gci.pDepthStencilState  = &ds;
    gci.pColorBlendState    = &cb;
    gci.pDynamicState       = &dyn;
    gci.layout              = out_layout;
    gci.renderPass          = desc.render_pass;
    gci.subpass             = desc.subpass;

    bool ok = vkCreateGraphicsPipelines(m_device, m_pipeline_cache,
                                         1, &gci, nullptr, &out_pipeline) == VK_SUCCESS;
    if (ok) {
        std::lock_guard<std::mutex> lock(m_mutex);
        m_pipelines[desc.name] = out_pipeline;
        m_layouts  [desc.name] = out_layout;
        TLOG_INFO(MOD, "Built graphics pipeline: " + desc.name);
    } else {
        TLOG_ERR(MOD, "Failed to build pipeline: " + desc.name);
    }

    return ok;
}

VkPipeline ShaderManager::GetPipeline(const std::string& name) {
    std::lock_guard<std::mutex> lock(m_mutex);
    auto it = m_pipelines.find(name);
    return it != m_pipelines.end() ? it->second : VK_NULL_HANDLE;
}

VkPipelineLayout ShaderManager::GetLayout(const std::string& name) {
    std::lock_guard<std::mutex> lock(m_mutex);
    auto it = m_layouts.find(name);
    return it != m_layouts.end() ? it->second : VK_NULL_HANDLE;
}

// ============================================================
// PIPELINE CACHE
// ============================================================
bool ShaderManager::SavePipelineCache(const std::string& filepath) {
    if (m_pipeline_cache == VK_NULL_HANDLE) return false;
    size_t size = 0;
    vkGetPipelineCacheData(m_device, m_pipeline_cache, &size, nullptr);
    if (size == 0) return false;
    std::vector<uint8_t> data(size);
    vkGetPipelineCacheData(m_device, m_pipeline_cache, &size, data.data());
    std::ofstream f(filepath, std::ios::binary);
    if (!f.is_open()) return false;
    f.write(reinterpret_cast<const char*>(data.data()), size);
    TLOG_INFO(MOD, "Pipeline cache saved: " + std::to_string(size / 1024) + "KB");
    return true;
}

bool ShaderManager::LoadPipelineCache(const std::string& filepath) {
    std::ifstream f(filepath, std::ios::binary | std::ios::ate);
    if (!f.is_open()) return false;
    size_t size = static_cast<size_t>(f.tellg());
    f.seekg(0);
    std::vector<uint8_t> data(size);
    f.read(reinterpret_cast<char*>(data.data()), size);

    VkPipelineCacheCreateInfo ci{};
    ci.sType           = VK_STRUCTURE_TYPE_PIPELINE_CACHE_CREATE_INFO;
    ci.initialDataSize = size;
    ci.pInitialData    = data.data();

    if (m_pipeline_cache != VK_NULL_HANDLE)
        vkDestroyPipelineCache(m_device, m_pipeline_cache, nullptr);

    bool ok = vkCreatePipelineCache(m_device, &ci, nullptr, &m_pipeline_cache) == VK_SUCCESS;
    if (ok) TLOG_INFO(MOD, "Pipeline cache loaded: " + std::to_string(size / 1024) + "KB");
    return ok;
}

// ============================================================
// HOT RELOAD
// ============================================================
void ShaderManager::CheckHotReload() {
#ifdef DEBUG
    // Check file timestamps and rebuild changed pipelines
    // (called each frame in debug builds)
#endif
}

} // namespace TerraEngine

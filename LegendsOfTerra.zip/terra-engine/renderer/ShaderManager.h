// ============================================================
// TERRA ENGINE — SHADER MANAGER
// ShaderManager.h — Version 1.0.0
// ============================================================
// Loads pre-compiled SPIRV shaders and builds Vulkan pipelines.
// Hot-reload support in debug builds.
// Pipeline cache for fast startup after first run.
// ============================================================

#pragma once

#include <vulkan/vulkan.h>
#include <string>
#include <vector>
#include <map>
#include <mutex>
#include <functional>

namespace TerraEngine {

// ============================================================
// PIPELINE DESC — everything needed to build a pipeline
// ============================================================
enum class PipelineType { GRAPHICS, COMPUTE };

struct PipelineDesc {
    PipelineType type            = PipelineType::GRAPHICS;
    std::string  name;

    // Shader stages (path to .spv files)
    std::string  vert_spv;
    std::string  frag_spv;
    std::string  comp_spv;       // compute only

    // Vertex input
    struct VertexAttr {
        uint32_t location;
        uint32_t binding;
        VkFormat format;
        uint32_t offset;
    };
    std::vector<VertexAttr>     vertex_attrs;
    uint32_t                    vertex_stride  = 0;
    VkVertexInputRate           input_rate     = VK_VERTEX_INPUT_RATE_VERTEX;

    // Rasterizer
    VkPolygonMode    polygon_mode  = VK_POLYGON_MODE_FILL;
    VkCullModeFlags  cull_mode     = VK_CULL_MODE_BACK_BIT;
    VkFrontFace      front_face    = VK_FRONT_FACE_COUNTER_CLOCKWISE;
    bool             depth_test    = true;
    bool             depth_write   = true;
    VkCompareOp      depth_compare = VK_COMPARE_OP_LESS;

    // Blending (per colour attachment)
    struct BlendState {
        bool         blend_enable  = false;
        VkBlendFactor src_colour   = VK_BLEND_FACTOR_SRC_ALPHA;
        VkBlendFactor dst_colour   = VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA;
        VkBlendOp     colour_op    = VK_BLEND_OP_ADD;
        VkBlendFactor src_alpha    = VK_BLEND_FACTOR_ONE;
        VkBlendFactor dst_alpha    = VK_BLEND_FACTOR_ZERO;
        VkBlendOp     alpha_op     = VK_BLEND_OP_ADD;
    };
    std::vector<BlendState>     blend_states;

    // Additive blend preset
    static BlendState AdditiveBlend() {
        return {true,
                VK_BLEND_FACTOR_ONE, VK_BLEND_FACTOR_ONE, VK_BLEND_OP_ADD,
                VK_BLEND_FACTOR_ONE, VK_BLEND_FACTOR_ONE, VK_BLEND_OP_ADD};
    }

    // Alpha blend preset
    static BlendState AlphaBlend() {
        return {true,
                VK_BLEND_FACTOR_SRC_ALPHA,
                VK_BLEND_FACTOR_ONE_MINUS_SRC_ALPHA,
                VK_BLEND_OP_ADD,
                VK_BLEND_FACTOR_ONE,
                VK_BLEND_FACTOR_ZERO,
                VK_BLEND_OP_ADD};
    }

    // Descriptor set layouts
    std::vector<VkDescriptorSetLayout> set_layouts;

    // Push constant range
    uint32_t push_constant_size  = 0;
    VkShaderStageFlags push_stage= VK_SHADER_STAGE_ALL_GRAPHICS;

    // Render pass this pipeline is used with
    VkRenderPass  render_pass    = VK_NULL_HANDLE;
    uint32_t      subpass        = 0;

    // MSAA samples
    VkSampleCountFlagBits samples = VK_SAMPLE_COUNT_1_BIT;

    // Dynamic state
    bool dynamic_viewport        = true;
    bool dynamic_scissor         = true;
};

// ============================================================
// SHADER MANAGER
// ============================================================
class ShaderManager {
public:
    static ShaderManager& Get() {
        static ShaderManager instance;
        return instance;
    }

    // --------------------------------------------------------
    // Init — sets device handle and shader directory
    // --------------------------------------------------------
    void Init(VkDevice device,
              const std::string& shader_dir = "renderer/shaders/");

    void Shutdown();

    // --------------------------------------------------------
    // Build pipeline from descriptor
    // --------------------------------------------------------
    bool BuildPipeline(const PipelineDesc& desc,
                       VkPipeline&       out_pipeline,
                       VkPipelineLayout& out_layout);

    // --------------------------------------------------------
    // Load SPIRV shader module
    // --------------------------------------------------------
    VkShaderModule LoadSPIRV(const std::string& spv_path);

    // --------------------------------------------------------
    // Pre-built pipeline accessors (by name)
    // --------------------------------------------------------
    VkPipeline       GetPipeline(const std::string& name);
    VkPipelineLayout GetLayout  (const std::string& name);

    // --------------------------------------------------------
    // Hot reload (debug builds only)
    // Watches shader directory for changes and rebuilds
    // --------------------------------------------------------
    void EnableHotReload(bool enable) { m_hot_reload = enable; }
    void CheckHotReload();    // call each frame in debug

    // --------------------------------------------------------
    // Pipeline cache — save/load to disk for fast startup
    // --------------------------------------------------------
    bool SavePipelineCache (const std::string& filepath);
    bool LoadPipelineCache (const std::string& filepath);

    // --------------------------------------------------------
    // Build all engine standard pipelines
    // --------------------------------------------------------
    void BuildEnginePipelines(
        VkRenderPass shadow_pass,
        VkRenderPass gbuffer_pass,
        VkRenderPass lighting_pass,
        VkRenderPass post_pass
    );

private:
    ShaderManager() : m_device(VK_NULL_HANDLE),
                      m_pipeline_cache(VK_NULL_HANDLE),
                      m_hot_reload(false) {}

    VkDevice        m_device;
    std::string     m_shader_dir;
    VkPipelineCache m_pipeline_cache;
    bool            m_hot_reload;

    mutable std::mutex                           m_mutex;
    std::map<std::string, VkShaderModule>        m_modules;
    std::map<std::string, VkPipeline>            m_pipelines;
    std::map<std::string, VkPipelineLayout>      m_layouts;
    std::map<std::string, uint64_t>              m_file_timestamps;

    std::vector<uint32_t> ReadSPIRV(const std::string& path);
    void DestroyPipeline(const std::string& name);

    // Standard vertex input for Vertex struct
    std::vector<VkVertexInputAttributeDescription> StandardVertexAttribs();
    VkVertexInputBindingDescription                StandardVertexBinding();

    static const char* MOD;
};

#define SHADERS ShaderManager::Get()

} // namespace TerraEngine

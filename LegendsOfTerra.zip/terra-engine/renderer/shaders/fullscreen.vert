// ============================================================
// TERRA ENGINE — FULLSCREEN QUAD VERTEX SHADER
// fullscreen.vert
// ============================================================
// Used by ALL full-screen post-process passes.
// No vertex buffer needed — generates quad from vertex index.
// Covers NDC exactly (-1 to 1 XY, Z=0).
// ============================================================

#version 460

layout(location = 0) out vec2 out_uv;

void main() {
    // 3 vertices cover screen as one large triangle
    // Faster than quad (no overdraw on diagonal)
    vec2 positions[3] = vec2[](
        vec2(-1.0, -1.0),
        vec2( 3.0, -1.0),
        vec2(-1.0,  3.0)
    );
    vec2 uvs[3] = vec2[](
        vec2(0.0, 0.0),
        vec2(2.0, 0.0),
        vec2(0.0, 2.0)
    );

    gl_Position = vec4(positions[gl_VertexIndex], 0.0, 1.0);
    out_uv      = uvs[gl_VertexIndex];
}

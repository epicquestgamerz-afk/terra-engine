// ============================================================
// TERRA ENGINE — GBUFFER VERTEX SHADER
// gbuffer.vert
// ============================================================
// Transforms geometry into GBuffer render targets.
// Outputs: position, normal, UV, tangent for PBR.
// ============================================================

#version 460

layout(location = 0) in vec3 in_position;
layout(location = 1) in vec3 in_normal;
layout(location = 2) in vec2 in_uv;
layout(location = 3) in vec4 in_tangent;
layout(location = 4) in vec4 in_color;

layout(location = 0) out vec3 out_world_pos;
layout(location = 1) out vec3 out_normal;
layout(location = 2) out vec2 out_uv;
layout(location = 3) out vec4 out_tangent;
layout(location = 4) out vec4 out_color;
layout(location = 5) out float out_depth;

layout(push_constant) uniform PushConstants {
    mat4 model;
    mat4 view_proj;
    float time;
    float corruption;
} push;

void main() {
    vec4 world_pos = push.model * vec4(in_position, 1.0);
    out_world_pos  = world_pos.xyz;
    out_normal     = normalize(mat3(transpose(inverse(push.model))) * in_normal);
    out_uv         = in_uv;
    out_tangent    = in_tangent;
    out_color      = in_color;

    gl_Position    = push.view_proj * world_pos;
    out_depth      = gl_Position.z / gl_Position.w;
}

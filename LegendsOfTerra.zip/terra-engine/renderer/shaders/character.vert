// ============================================================
// TERRA ENGINE — CHARACTER VERTEX SHADER
// character.vert
// ============================================================
// Skinned mesh animation for Kael, Sera, NPCs, bosses.
// Up to 4 bone influences per vertex.
// Magic charge drives gauntlet/magic emissive pulse.
// ============================================================

#version 460

layout(location = 0) in vec3  in_position;
layout(location = 1) in vec3  in_normal;
layout(location = 2) in vec2  in_uv;
layout(location = 3) in vec4  in_tangent;
layout(location = 4) in vec4  in_color;
layout(location = 5) in uvec4 in_bone_ids;     // up to 4 bone influences
layout(location = 6) in vec4  in_bone_weights; // must sum to 1.0

layout(location = 0) out vec3  out_world_pos;
layout(location = 1) out vec3  out_normal;
layout(location = 2) out vec2  out_uv;
layout(location = 3) out vec4  out_tangent;
layout(location = 4) out vec4  out_color;
layout(location = 5) out float out_depth;
layout(location = 6) out float out_magic_charge;  // for emissive in frag

layout(set = 0, binding = 0) uniform Skeleton {
    mat4 bones[128]; // max 128 bones per character
} skeleton;

layout(push_constant) uniform CharPush {
    mat4  model;
    mat4  view_proj;
    float time;
    float magic_charge;   // 0=none 1=full (Kael gauntlet / Sera magic)
    float corruption;
    int   is_kael;        // 1=Kael 0=Sera or NPC
} push;

void main() {
    // Skinning — blend up to 4 bone transforms
    mat4 skin_matrix =
        skeleton.bones[in_bone_ids.x] * in_bone_weights.x +
        skeleton.bones[in_bone_ids.y] * in_bone_weights.y +
        skeleton.bones[in_bone_ids.z] * in_bone_weights.z +
        skeleton.bones[in_bone_ids.w] * in_bone_weights.w;

    vec4 local_pos     = skin_matrix * vec4(in_position, 1.0);
    vec4 world_pos     = push.model  * local_pos;

    out_world_pos      = world_pos.xyz;
    out_normal         = normalize(mat3(transpose(inverse(
                            push.model * skin_matrix))) * in_normal);
    out_uv             = in_uv;
    out_tangent        = in_tangent;
    out_color          = in_color;
    out_magic_charge   = push.magic_charge;

    gl_Position        = push.view_proj * world_pos;
    out_depth          = gl_Position.z / gl_Position.w;
}

// ============================================================
// TERRA ENGINE — SHADOW VERTEX SHADER
// shadow.vert
// ============================================================
// Renders scene geometry into cascade shadow maps.
// Push constant selects which cascade (viewport offset).
// Outputs only depth — no colour needed.
// ============================================================

#version 460

layout(location = 0) in vec3 in_position;
layout(location = 1) in vec3 in_normal;   // unused but keep layout consistent
layout(location = 2) in vec2 in_uv;

layout(location = 0) out vec2 out_uv;    // for alpha cutout in frag

layout(push_constant) uniform PushConstants {
    mat4 model;
    mat4 light_view_proj; // per cascade
    int  cascade_index;
} push;

void main() {
    out_uv      = in_uv;
    gl_Position = push.light_view_proj * push.model * vec4(in_position, 1.0);
}

// ============================================================
// TERRA ENGINE — SHADOW FRAGMENT SHADER
// shadow.frag
// ============================================================
// Handles alpha-tested geometry (leaves, grass) in shadow pass.
// Solid geometry uses depth-only pipeline (no frag shader).
// ============================================================

#version 460

layout(location = 0) in vec2 in_uv;

layout(set = 1, binding = 0) uniform sampler2D tex_albedo;

layout(push_constant) uniform PushConstants {
    mat4 model;
    mat4 light_view_proj;
    int  cascade_index;
    int  alpha_cutout;   // 1 = vegetation/foliage
} push;

void main() {
    if (push.alpha_cutout == 1) {
        float alpha = texture(tex_albedo, in_uv).a;
        if (alpha < 0.5) discard;
    }
    // Depth written automatically — no colour output needed
}

// ============================================================
// TERRA ENGINE — SCREEN SPACE REFLECTIONS
// ssr.frag — HIGH + ULTRA
// ============================================================
// Raymarches in view-space to find reflection hits.
// Steps: 32 (HIGH) | 64 (ULTRA)
// Output: reflected colour + confidence mask
// Used for: water reflections, wet stone, polished metal,
//           corruption crystals, Sera's magic floor effects
// ============================================================

#version 460

layout(location = 0) in vec2 in_uv;
layout(location = 0) out vec4 out_reflection; // rgb=colour, a=confidence

layout(set = 0, binding = 0) uniform sampler2D hdr_input;
layout(set = 0, binding = 1) uniform sampler2D gbuf_depth;
layout(set = 0, binding = 2) uniform sampler2D gbuf_normals;
layout(set = 0, binding = 3) uniform sampler2D gbuf_albedo; // for roughness check

layout(set = 1, binding = 0) uniform SSRData {
    mat4  view;
    mat4  projection;
    mat4  inv_view_proj;
    mat4  inv_projection;
    vec3  camera_pos;
    float thickness;       // hit acceptance thickness
    int   steps;           // 32 or 64
    int   binary_steps;    // 8 refinement steps
    float max_distance;    // max ray length
    vec2  resolution;
} ssr;

// ============================================================
// RECONSTRUCT
// ============================================================
vec3 ReconstructViewPos(vec2 uv, float depth) {
    vec4 clip = vec4(uv * 2.0 - 1.0, depth, 1.0);
    vec4 view = ssr.inv_projection * clip;
    return view.xyz / view.w;
}

vec2 ViewToScreen(vec3 view_pos) {
    vec4 clip = ssr.projection * vec4(view_pos, 1.0);
    clip.xyz /= clip.w;
    return clip.xy * 0.5 + 0.5;
}

// ============================================================
// BINARY SEARCH REFINEMENT
// ============================================================
vec2 BinarySearch(vec3 dir, vec3 hit_coord) {
    float depth;
    for (int i = 0; i < ssr.binary_steps; i++) {
        vec2  uv  = ViewToScreen(hit_coord);
        depth     = texture(gbuf_depth, uv).r;
        vec3  pos = ReconstructViewPos(uv, depth);
        dir      *= 0.5;
        if (hit_coord.z > pos.z) hit_coord -= dir;
        else                      hit_coord += dir;
    }
    return ViewToScreen(hit_coord);
}

// ============================================================
// FADE EDGES — reflections fade at screen borders
// ============================================================
float EdgeFade(vec2 uv) {
    float edge_x = min(uv.x, 1.0 - uv.x) * 10.0;
    float edge_y = min(uv.y, 1.0 - uv.y) * 10.0;
    return clamp(min(edge_x, edge_y), 0.0, 1.0);
}

// ============================================================
// MAIN
// ============================================================
void main() {
    float depth     = texture(gbuf_depth, in_uv).r;
    if (depth >= 0.9999) { out_reflection = vec4(0.0); return; }

    // Roughness check — only reflect smooth surfaces
    float roughness = texture(gbuf_albedo, in_uv).a; // metallic in R, roughness in packed gbuf
    if (roughness > 0.6) { out_reflection = vec4(0.0); return; }

    vec3  view_pos  = ReconstructViewPos(in_uv, depth);
    vec3  normal    = normalize((ssr.view * vec4(
                        texture(gbuf_normals, in_uv).rgb * 2.0 - 1.0, 0.0)).xyz);
    vec3  V         = normalize(-view_pos);
    vec3  R         = normalize(reflect(-V, normal));

    // Step size along ray
    float step_len  = ssr.max_distance / float(ssr.steps);
    vec3  step      = R * step_len;
    vec3  ray       = view_pos + R * 0.1; // start just above surface

    float confidence = 0.0;
    vec2  hit_uv    = in_uv;

    for (int i = 0; i < ssr.steps; i++) {
        ray += step;

        vec2  s_uv  = ViewToScreen(ray);
        if (s_uv.x < 0.0 || s_uv.x > 1.0 ||
            s_uv.y < 0.0 || s_uv.y > 1.0) break;

        float s_depth = texture(gbuf_depth, s_uv).r;
        vec3  s_pos   = ReconstructViewPos(s_uv, s_depth);

        float delta   = ray.z - s_pos.z;

        if (delta > 0.0 && delta < ssr.thickness) {
            // Hit — refine with binary search
            hit_uv     = BinarySearch(step, ray);
            confidence = 1.0 - float(i) / float(ssr.steps); // closer hits = more confident
            break;
        }
    }

    if (confidence <= 0.0) { out_reflection = vec4(0.0); return; }

    // Sample reflection colour
    vec3  reflected  = texture(hdr_input, hit_uv).rgb;

    // Fade: roughness, edges, distance
    float roughness_fade = 1.0 - roughness / 0.6;
    float edge_fade      = EdgeFade(hit_uv);
    float total_fade     = roughness_fade * edge_fade * confidence;

    out_reflection = vec4(reflected, total_fade);
}

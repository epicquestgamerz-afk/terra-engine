// ============================================================
// TERRA ENGINE — VOLUMETRIC CLOUDS + AURORA
// clouds.frag — ULTRA quality only
// ============================================================
// Raymarched volumetric clouds at quarter resolution.
// Upsampled and composited over scene in post process.
// Aurora effect layered in cloud tops when is_night = true.
// Weather system drives cloud density and coverage.
// ============================================================

#version 460

layout(location = 0) in vec2 in_uv;
layout(location = 0) out vec4 out_cloud;  // RGBA: rgb=cloud colour, a=transmittance

layout(set = 0, binding = 0) uniform sampler2D depth_buffer;
layout(set = 0, binding = 1) uniform sampler3D cloud_noise;     // 3D Perlin-Worley noise
layout(set = 0, binding = 2) uniform sampler3D cloud_detail;    // high freq detail noise
layout(set = 0, binding = 3) uniform sampler2D weather_map;     // coverage/type/wetness
layout(set = 0, binding = 4) uniform sampler2D blue_noise;      // dither for ray stepping

layout(set = 1, binding = 0) uniform CameraData {
    mat4  view;
    mat4  projection;
    mat4  inv_view_proj;
    vec3  position;
    float near_plane;
    float far_plane;
} camera;

layout(set = 1, binding = 1) uniform CloudData {
    float cloud_base_height;   // e.g. 1500.0 world units
    float cloud_top_height;    // e.g. 4000.0
    float coverage;            // 0=clear sky 1=overcast
    float density;             // cloud thickness multiplier
    float speed;               // wind speed
    vec2  wind_dir;            // wind direction XZ
    vec3  sun_direction;
    vec3  sun_color;
    float time;
    float corruption;
    float is_night;
    int   march_steps;         // 128 for ULTRA
    int   light_steps;         // 6 light samples per cloud step
} clouds;

const float PI = 3.14159265359;

// ============================================================
// NOISE — Perlin-Worley FBM for cloud shape
// ============================================================
float SampleCloudDensity(vec3 pos, float lod) {
    // Animate with wind
    vec3 anim = vec3(clouds.wind_dir.x, 0.0, clouds.wind_dir.y)
               * clouds.time * clouds.speed;

    vec3 p      = (pos + anim) * 0.0001; // scale to noise texture space
    float base  = texture(cloud_noise,  p * vec3(1.0, 0.5, 1.0)).r;
    float detail = texture(cloud_detail, p * 4.0).r;

    // Weather map drives coverage per region
    vec2  weather_uv  = pos.xz * 0.00005 + 0.5;
    vec3  weather     = texture(weather_map, weather_uv).rgb;
    float coverage    = weather.r * clouds.coverage;
    float cloud_type  = weather.g; // 0=stratus 1=cumulus

    // Height gradient — thinner at base and top
    float height_frac = (pos.y - clouds.cloud_base_height) /
                        (clouds.cloud_top_height - clouds.cloud_base_height);
    height_frac       = clamp(height_frac, 0.0, 1.0);
    float height_grad = height_frac * (1.0 - height_frac) * 4.0;

    // Combine
    float density = max(0.0, base * height_grad - (1.0 - coverage));
    density       = mix(density, density * (1.0 - detail * 0.5), 0.5);
    return density * clouds.density;
}

// ============================================================
// HENYEY-GREENSTEIN phase function — forward scattering
// ============================================================
float HenyeyGreenstein(float cos_theta, float g) {
    float g2    = g * g;
    float denom = 1.0 + g2 - 2.0 * g * cos_theta;
    return (1.0 - g2) / (4.0 * PI * pow(denom, 1.5));
}

float DualLobe(float cos_theta, float g0, float g1, float blend) {
    return mix(HenyeyGreenstein(cos_theta, g0),
               HenyeyGreenstein(cos_theta, g1), blend);
}

// ============================================================
// LIGHT ENERGY — single scattering toward sun
// ============================================================
float LightMarch(vec3 pos) {
    vec3  L        = normalize(-clouds.sun_direction);
    float step_len = (clouds.cloud_top_height - pos.y) / float(clouds.light_steps);
    float density  = 0.0;

    for (int i = 0; i < clouds.light_steps; i++) {
        pos += L * step_len;
        density += SampleCloudDensity(pos, float(i));
    }

    // Beer-Lambert attenuation
    return exp(-density * 0.2);
}

// ============================================================
// AURORA — layered light bands above cloud tops (night only)
// ============================================================
vec3 Aurora(vec3 ray_dir, float height_factor) {
    if (clouds.is_night < 0.5) return vec3(0.0);

    // Animated aurora bands using sine waves
    vec2 uv      = ray_dir.xz / (ray_dir.y + 0.1);
    float t      = clouds.time * 0.1;

    float band1  = sin(uv.x * 3.0 + t)       * 0.5 + 0.5;
    float band2  = sin(uv.x * 5.0 + t * 1.3) * 0.5 + 0.5;
    float band3  = sin(uv.y * 4.0 + t * 0.7) * 0.5 + 0.5;

    float aurora = band1 * band2 * band3;
    aurora       = pow(aurora, 3.0) * height_factor;

    // Aurora palette: green → cyan → purple (corruption shifts to purple)
    vec3 green  = vec3(0.1, 0.9, 0.4);
    vec3 cyan   = vec3(0.0, 0.6, 0.9);
    vec3 purple = vec3(0.5, 0.1, 0.8);

    vec3 colour = mix(mix(green, cyan, band2), purple, clouds.corruption * 0.5);
    return colour * aurora * 2.5;
}

// ============================================================
// RAY-SPHERE INTERSECTION
// ============================================================
vec2 RaySphere(vec3 origin, vec3 dir, float radius) {
    float b = dot(dir, origin);
    float c = dot(origin, origin) - radius * radius;
    float d = b * b - c;
    if (d < 0.0) return vec2(-1.0);
    float s = sqrt(d);
    return vec2(-b - s, -b + s);
}

// ============================================================
// MAIN RAYMARCH
// ============================================================
void main() {
    // Reconstruct ray direction from UV
    vec4 clip     = vec4(in_uv * 2.0 - 1.0, 1.0, 1.0);
    vec4 world    = camera.inv_view_proj * clip;
    vec3 ray_dir  = normalize(world.xyz / world.w - camera.position);
    vec3 ray_pos  = camera.position;

    // Skip if ray points down (no clouds underground)
    if (ray_dir.y < 0.01) {
        out_cloud = vec4(0.0, 0.0, 0.0, 1.0);
        return;
    }

    // Find cloud layer intersection
    float base_t = (clouds.cloud_base_height - ray_pos.y) / ray_dir.y;
    float top_t  = (clouds.cloud_top_height  - ray_pos.y) / ray_dir.y;

    if (base_t < 0.0 && top_t < 0.0) {
        out_cloud = vec4(0.0, 0.0, 0.0, 1.0);
        return;
    }

    float t_start = max(0.0, base_t);
    float t_end   = max(0.0, top_t);

    // Blue noise dither offset for Bayer stepping
    float dither = texture(blue_noise, gl_FragCoord.xy / 64.0).r;
    t_start     += dither * (t_end - t_start) / float(clouds.march_steps);

    float step_len   = (t_end - t_start) / float(clouds.march_steps);
    float cos_theta  = dot(ray_dir, normalize(-clouds.sun_direction));

    vec3  scatter    = vec3(0.0);
    float transmit   = 1.0;

    for (int i = 0; i < clouds.march_steps && transmit > 0.01; i++) {
        vec3 pos     = ray_pos + ray_dir * (t_start + float(i) * step_len);
        float density = SampleCloudDensity(pos, float(i) / float(clouds.march_steps));

        if (density > 0.001) {
            float light = LightMarch(pos);
            float phase = DualLobe(cos_theta, 0.8, -0.3, 0.5);

            // Multi-scattering approximation
            float ms    = 0.5;
            float ms_phase = DualLobe(cos_theta, 0.3, -0.1, 0.5);

            vec3 sun_col = clouds.sun_color * (phase * light + ms * ms_phase * 0.5);
            // Ambient sky contribution
            vec3 sky_col = vec3(0.3, 0.5, 0.8) * 0.4 * (1.0 - density);

            vec3 radiance   = sun_col + sky_col;
            float extinction = density * step_len * 0.05;
            float beer       = exp(-extinction);

            scatter  += radiance * transmit * (1.0 - beer);
            transmit *= beer;
        }
    }

    // Add aurora above cloud tops
    float height_factor = clamp(
        (ray_pos.y - clouds.cloud_top_height) / 1000.0, 0.0, 1.0);
    scatter += Aurora(ray_dir, 1.0 - height_factor) * transmit;

    out_cloud = vec4(scatter, transmit);
}

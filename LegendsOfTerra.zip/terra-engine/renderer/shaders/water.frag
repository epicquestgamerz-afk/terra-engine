// ============================================================
// TERRA ENGINE — WATER SHADER
// water.frag
// ============================================================
// Physically-based water for islands:
//   - Ocean: FFT wave simulation (HIGH+)
//   - Waterfalls: flow maps + foam (all tiers)
//   - Shallow water: refraction + caustics
//   - Corruption water: dark purple, viscous look
// ============================================================

#version 460

layout(location = 0) in vec3 in_world_pos;
layout(location = 1) in vec2 in_uv;
layout(location = 2) in vec3 in_view_pos;
layout(location = 3) in float in_water_depth;

layout(location = 0) out vec4 out_colour;

layout(set = 0, binding = 0) uniform sampler2D normal_map_a;     // water normal scroll A
layout(set = 0, binding = 1) uniform sampler2D normal_map_b;     // water normal scroll B
layout(set = 0, binding = 2) uniform sampler2D foam_texture;
layout(set = 0, binding = 3) uniform sampler2D flow_map;         // waterfall direction
layout(set = 0, binding = 4) uniform sampler2D refraction_buf;   // scene behind water
layout(set = 0, binding = 5) uniform sampler2D reflection_buf;   // SSR or planar reflection
layout(set = 0, binding = 6) uniform sampler2D depth_buffer;
layout(set = 0, binding = 7) uniform sampler2D fft_displacement; // ocean FFT (HIGH+)

layout(set = 1, binding = 0) uniform WaterData {
    float time;
    float wave_speed;
    float wave_scale;
    float wave_height;
    float water_clarity;
    vec3  shallow_colour;      // e.g. turquoise
    vec3  deep_colour;         // e.g. dark blue
    float foam_amount;
    int   is_waterfall;        // 0=ocean/lake, 1=waterfall
    float corruption;
    int   use_fft;             // HIGH+ only
    vec3  sun_direction;
    vec3  sun_color;
    vec3  camera_pos;
} water;

const float PI = 3.14159265359;

// ============================================================
// FRESNEL — how much reflection vs refraction
// ============================================================
float FresnelSchlick(float cos_theta, float F0) {
    return F0 + (1.0 - F0) * pow(1.0 - cos_theta, 5.0);
}

// ============================================================
// WATERFALL FLOW MAP ANIMATION
// Based on Valve's water flow technique
// ============================================================
vec3 FlowmapNormal(vec2 uv) {
    vec2 flow      = texture(flow_map, uv).rg * 2.0 - 1.0;
    flow          *= 0.5; // scale flow speed

    // Offset two samples with time to avoid teleport seam
    float phase1   = fract(water.time * 0.3);
    float phase2   = fract(water.time * 0.3 + 0.5);
    float blend    = abs(phase1 * 2.0 - 1.0); // triangle wave blend

    vec2  uv1      = uv - flow * phase1;
    vec2  uv2      = uv - flow * phase2;

    vec3  n1       = texture(normal_map_a, uv1 * 3.0).rgb * 2.0 - 1.0;
    vec3  n2       = texture(normal_map_a, uv2 * 3.0).rgb * 2.0 - 1.0;

    return normalize(mix(n1, n2, blend));
}

// ============================================================
// OCEAN NORMAL — dual scrolling normals + FFT
// ============================================================
vec3 OceanNormal(vec2 uv) {
    float t      = water.time * water.wave_speed;
    vec2  s      = vec2(water.wave_scale);

    vec3  n1     = texture(normal_map_a, uv * s + vec2(t * 0.03, t * 0.01)).rgb * 2.0 - 1.0;
    vec3  n2     = texture(normal_map_b, uv * s * 0.4 + vec2(-t * 0.02, t * 0.04)).rgb * 2.0 - 1.0;

    // Blend two normal maps
    vec3  N      = normalize(vec3(n1.xy + n2.xy, n1.z));

    // FFT displacement normal (HIGH+)
    if (water.use_fft == 1) {
        vec3 fft_n = texture(fft_displacement, uv).rgb * 2.0 - 1.0;
        N          = normalize(N + fft_n * 0.3);
    }

    return N;
}

// ============================================================
// CAUSTICS — light patterns on underwater terrain
// ============================================================
vec3 Caustics(vec2 uv, float depth) {
    if (depth < 0.01) return vec3(0.0);
    float t        = water.time * 0.5;
    vec2  c_uv     = uv * 4.0;
    float c1       = abs(sin(c_uv.x * 3.0 + t) * sin(c_uv.y * 3.0 - t));
    float c2       = abs(sin(c_uv.x * 5.0 - t * 1.3) * sin(c_uv.y * 4.0 + t));
    float caustic  = pow(min(c1, c2), 3.0) * 2.0;
    return vec3(caustic) * 0.3 * depth;
}

// ============================================================
// FOAM
// ============================================================
float FoamMask(vec2 uv, float depth, vec3 N) {
    // Edge foam — shallow water
    float edge_foam = clamp(1.0 - depth / 0.5, 0.0, 1.0);
    edge_foam       = pow(edge_foam, 2.0);

    // Crest foam — steep normals
    float crest_foam = clamp(1.0 - abs(N.y), 0.0, 1.0);
    crest_foam       = pow(crest_foam, 4.0) * water.foam_amount;

    // Waterfall foam — always foam at base
    float waterfall_foam = water.is_waterfall > 0 ? 0.5 : 0.0;

    return clamp(edge_foam + crest_foam + waterfall_foam, 0.0, 1.0);
}

// ============================================================
// CORRUPTION WATER
// ============================================================
vec3 CorruptWater(vec3 base_colour, float corruption) {
    if (corruption < 0.01) return base_colour;
    vec3  corrupt   = vec3(0.15, 0.0, 0.25);    // dark purple
    float lum       = dot(base_colour, vec3(0.299, 0.587, 0.114));
    vec3  desat     = vec3(lum * 0.3);
    return mix(base_colour, mix(desat, corrupt, corruption), corruption);
}

// ============================================================
// MAIN
// ============================================================
void main() {
    vec3 V         = normalize(water.camera_pos - in_world_pos);
    float NdotV    = clamp(dot(V, vec3(0, 1, 0)), 0.0, 1.0);

    // ── Compute water normal ─────────────────────────────────
    vec3 N;
    if (water.is_waterfall == 1) {
        N = FlowmapNormal(in_uv);
    } else {
        N = OceanNormal(in_uv);
    }

    // ── Sample refraction (scene behind water) ───────────────
    vec2  refract_offset = N.xz * 0.05 * water.water_clarity;
    vec3  refraction     = texture(refraction_buf, in_uv + refract_offset).rgb;

    // Apply depth-based water tint
    float depth_factor = clamp(in_water_depth / 5.0, 0.0, 1.0);
    vec3  water_colour = mix(water.shallow_colour, water.deep_colour, depth_factor);
    refraction         = mix(refraction, water_colour, depth_factor * 0.7);

    // Add caustics in shallow water
    refraction += Caustics(in_uv, 1.0 - depth_factor);

    // ── Sample reflection ────────────────────────────────────
    vec2  reflect_uv = in_uv + N.xz * 0.03;
    vec3  reflection = texture(reflection_buf, reflect_uv).rgb;

    // ── Fresnel blend reflection / refraction ────────────────
    float fresnel    = FresnelSchlick(NdotV, 0.02);
    fresnel          = mix(fresnel, 1.0, pow(1.0 - NdotV, 5.0) * 0.5);

    vec3  colour     = mix(refraction, reflection, fresnel);

    // ── Specular highlight ──────────────────────────────────
    vec3  L          = normalize(-water.sun_direction);
    vec3  H          = normalize(V + L);
    float spec       = pow(max(dot(N, H), 0.0), 256.0) * 5.0;
    colour          += water.sun_color * spec;

    // ── Foam ─────────────────────────────────────────────────
    float foam       = FoamMask(in_uv, in_water_depth, N);
    if (foam > 0.0) {
        vec3 foam_col = texture(foam_texture, in_uv * 4.0 + water.time * 0.1).rgb;
        colour        = mix(colour, foam_col, foam);
    }

    // ── Corruption ──────────────────────────────────────────
    colour = CorruptWater(colour, water.corruption);

    // ── Transparency ────────────────────────────────────────
    float alpha = mix(0.85, 1.0, depth_factor);

    out_colour = vec4(colour, alpha);
}

// ============================================================
// TERRA ENGINE — VEGETATION VERTEX SHADER
// vegetation.vert
// ============================================================
// GPU wind simulation for grass, flowers, leaves, trees.
// Vertex color R = stiffness (1=rigid trunk, 0=tip bends max)
// Vertex color G = phase offset (randomises wave timing)
// Storm parameter drives wind intensity.
// Corruption causes wilting and unnatural motion.
// ============================================================

#version 460

layout(location = 0) in vec3 in_position;
layout(location = 1) in vec3 in_normal;
layout(location = 2) in vec2 in_uv;
layout(location = 3) in vec4 in_tangent;
layout(location = 4) in vec4 in_color;  // R=stiffness G=phase_offset

layout(location = 0) out vec3 out_world_pos;
layout(location = 1) out vec3 out_normal;
layout(location = 2) out vec2 out_uv;
layout(location = 3) out vec4 out_tangent;
layout(location = 4) out vec4 out_color;
layout(location = 5) out float out_depth;

layout(push_constant) uniform PushConstants {
    mat4  model;
    mat4  view_proj;
    float time;
    float wind_strength;   // 0=calm 1=storm
    vec2  wind_dir;        // XZ direction (normalised)
    float corruption;
    float is_night;
} push;

// ============================================================
// SMOOTH NOISE — for organic wind variation
// ============================================================
float Hash(float n) {
    return fract(sin(n) * 43758.5453);
}

float SmoothNoise(float x) {
    float i = floor(x);
    float f = fract(x);
    float u = f * f * (3.0 - 2.0 * f); // smoothstep
    return mix(Hash(i), Hash(i + 1.0), u);
}

// ============================================================
// WIND ANIMATION
// ============================================================
vec3 ApplyWind(vec3 pos, float stiffness, float phase_offset) {
    float flex      = 1.0 - stiffness; // how much this vertex bends
    if (flex < 0.01) return pos;       // rigid parts don't move

    float time      = push.time;
    float wind      = push.wind_strength;

    // Primary sway — large slow wave
    float primary   = sin(time * 1.5 + phase_offset * 6.28) * wind;

    // Secondary flutter — fast small ripple
    float secondary = sin(time * 4.0 + phase_offset * 12.56
                        + pos.x * 0.5 + pos.z * 0.5) * wind * 0.3;

    // Turbulence — smooth noise
    float turb      = SmoothNoise(time * 0.7 + phase_offset * 4.0) * wind * 0.2;

    float total     = (primary + secondary + turb) * flex;

    // Apply in wind direction
    vec3 offset     = vec3(push.wind_dir.x, 0.0, push.wind_dir.y) * total * 0.3;

    // Height-dependent — tips sway more than base
    float height    = max(0.0, pos.y / 1.5); // normalised height
    offset         *= height;

    // Corruption wilting — vertices droop downward erratically
    if (push.corruption > 0.2 && flex > 0.3) {
        float wilt  = sin(time * 0.8 + phase_offset * 3.14) * push.corruption * 0.15;
        float droop = push.corruption * 0.2 * flex * height;
        offset.y   -= droop;
        offset.x   += wilt * flex;
    }

    return pos + offset;
}

void main() {
    float stiffness    = in_color.r;
    float phase_offset = in_color.g;

    // Transform to world space first
    vec4  world        = push.model * vec4(in_position, 1.0);

    // Apply wind in world space
    world.xyz          = ApplyWind(world.xyz, stiffness, phase_offset);

    out_world_pos      = world.xyz;
    out_normal         = normalize(mat3(transpose(inverse(push.model))) * in_normal);
    out_uv             = in_uv;
    out_tangent        = in_tangent;
    out_color          = in_color;

    gl_Position        = push.view_proj * world;
    out_depth          = gl_Position.z / gl_Position.w;
}

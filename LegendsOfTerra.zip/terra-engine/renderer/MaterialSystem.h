// ============================================================
// TERRA ENGINE — MATERIAL SYSTEM
// MaterialSystem.h — Version 1.0.0
// ============================================================
// Manages all PBR materials — textures, parameters, variants.
// One material per mesh — multiple meshes can share materials.
// Corruption + magic variants auto-generated from base.
// ============================================================

#pragma once

#include "Renderer.h"
#include <string>
#include <map>
#include <vector>
#include <memory>
#include <mutex>

namespace TerraEngine {

// ============================================================
// MATERIAL TYPE
// ============================================================
enum class MaterialType {
    OPAQUE,       // standard PBR solid
    ALPHA_CUTOUT, // vegetation — clip below threshold
    TRANSPARENT,  // glass, water, magic
    ADDITIVE,     // fire, magic particles
    CHARACTER,    // skin SSS + magic emissive
    WATER,        // water-specific PBR
    VEGETATION,   // wind-animated
    TERRAIN       // multi-layer blend
};

// ============================================================
// MATERIAL
// ============================================================
struct Material {
    uint32_t     id          = 0;
    std::string  name;
    MaterialType type        = MaterialType::OPAQUE;

    // PBR parameters
    float albedo_r           = 1.0f;
    float albedo_g           = 1.0f;
    float albedo_b           = 1.0f;
    float albedo_a           = 1.0f;
    float metallic           = 0.0f;
    float roughness          = 0.8f;
    float emissive_intensity = 0.0f;
    float ao_strength        = 1.0f;
    float sss_strength       = 0.0f;  // subsurface scatter (skin)
    float alpha_cutoff       = 0.5f;

    // Textures — loaded via AssetPipeline
    GpuImage albedo_tex;
    GpuImage normal_tex;
    GpuImage metallic_roughness_tex;
    GpuImage emissive_tex;
    GpuImage ao_tex;
    GpuImage sss_tex;         // character skin thickness
    GpuImage corruption_tex;  // vein mask

    // Descriptor set (bound at draw time)
    VkDescriptorSet descriptor_set = VK_NULL_HANDLE;

    bool  is_double_sided = false;
    bool  has_textures    = false;
};

// ============================================================
// MATERIAL SYSTEM
// ============================================================
class MaterialSystem {
public:
    static MaterialSystem& Get() {
        static MaterialSystem instance;
        return instance;
    }

    void Init(VkDevice device, VkDescriptorPool pool);
    void Shutdown();

    // Create material from parameters
    uint32_t CreateMaterial(const Material& mat);

    // Load material from glTF material definition (JSON string)
    uint32_t LoadFromGLTF(const std::string& gltf_material_json,
                           const std::string& texture_dir);

    // Get material by ID
    Material*       Get(uint32_t id);
    const Material* Get(uint32_t id) const;

    // Built-in materials
    uint32_t WhiteMaterial();
    uint32_t DefaultTerrain();
    uint32_t WaterMaterial();
    uint32_t CorruptionCrystal();
    uint32_t MagicRing(bool is_kael = false);

    // Update corruption level on existing material
    void SetCorruption(uint32_t mat_id, float level);

    // Bind material for rendering
    void Bind(VkCommandBuffer cmd,
              VkPipelineLayout layout,
              uint32_t mat_id,
              uint32_t set_index = 1);

    uint32_t MaterialCount() const;

private:
    MaterialSystem() : m_device(VK_NULL_HANDLE), m_pool(VK_NULL_HANDLE),
                       m_next_id(1) {}

    VkDevice            m_device;
    VkDescriptorPool    m_pool;
    VkDescriptorSetLayout m_layout = VK_NULL_HANDLE;
    uint32_t            m_next_id;

    mutable std::mutex                  m_mutex;
    std::map<uint32_t, Material>        m_materials;

    void CreateDescriptorLayout();
    void AllocateDescriptorSet(Material& mat);
    void WriteDescriptorSet(Material& mat);

    static const char* MOD;
};

#define MATERIALS MaterialSystem::Get()

} // namespace TerraEngine

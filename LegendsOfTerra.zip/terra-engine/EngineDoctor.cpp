// ============================================================
// TERRA ENGINE — ENGINE DOCTOR IMPLEMENTATION
// EngineDoctor.cpp — Version 1.0.0
// ============================================================
#include "EngineDoctor.h"
#include "TerraCore.h"
#include "AudioSystem.h"
#include "PhysicsWorld.h"
#include "renderer/Renderer.h"
#include "SaveManager.h"
#include "Config.h"
#include "AssetLoader.h"
#include "AgentBus.h"
#include <cmath>
#include <fstream>
#include <filesystem>

namespace TerraEngine {

const char* EngineDoctor::MOD = "EngineDoctor";

// ============================================================
// INIT — register all standard checks
// ============================================================
void EngineDoctor::Init() {
    RegisterEngineChecks();
    RegisterRendererChecks();
    RegisterPhysicsChecks();
    RegisterAudioChecks();
    RegisterSaveChecks();
    RegisterAIChecks();
    RegisterMemoryChecks();
    TLOG_INFO(MOD, "EngineDoctor online — "
              + std::to_string(m_checks.size()) + " checks registered");
}

// ============================================================
// STARTUP SCAN — run everything once immediately
// ============================================================
void EngineDoctor::StartupScan() {
    TLOG_INFO(MOD, "=== STARTUP HEALTH SCAN ===");
    std::lock_guard<std::mutex> lock(m_mutex);
    for (auto& check : m_checks) {
        bool healthy = false;
        try { healthy = check.check(); }
        catch (...) { healthy = false; }

        if (!healthy) {
            m_issue_count.fetch_add(1);
            try {
                if (check.fix) {
                    check.fix();
                    m_fix_count.fetch_add(1);
                    Report(DoctorSeverity::FIXED, check.system,
                           check.name + " failed at startup",
                           "Auto-fixed", true);
                } else {
                    Report(DoctorSeverity::WARN, check.system,
                           check.name + " failed at startup",
                           "No auto-fix available", false);
                }
            } catch (...) {}
        }
    }
    TLOG_INFO(MOD, "Startup scan complete — fixed: "
              + std::to_string(m_fix_count.load())
              + " issues: " + std::to_string(m_issue_count.load()));
}

// ============================================================
// TICK — run due checks
// ============================================================
void EngineDoctor::Tick(int frame) {
    if (!m_enabled.load()) return;
    std::lock_guard<std::mutex> lock(m_mutex);
    for (auto& check : m_checks) {
        RunCheck(check, frame);
    }
}

void EngineDoctor::RunCheck(HealthCheck& check, int frame) {
    check.frame_counter++;
    if (check.frame_counter < check.interval_frames) return;
    check.frame_counter = 0;

    if (check.fail_count >= check.max_fails) return; // disabled

    bool healthy = true;
    try { healthy = check.check(); }
    catch (const std::exception& e) {
        healthy = false;
        Report(DoctorSeverity::WARN, check.system,
               check.name + " threw: " + e.what(), "Check exception", false);
    } catch (...) { healthy = false; }

    if (healthy) {
        check.fail_count = 0; // reset on success
        return;
    }

    check.fail_count++;
    m_issue_count.fetch_add(1);

    if (check.fix) {
        try {
            check.fix();
            m_fix_count.fetch_add(1);
            Report(DoctorSeverity::FIXED, check.system,
                   check.name, "Auto-fixed (" +
                   std::to_string(check.fail_count) + " times)", true);
        } catch (const std::exception& e) {
            Report(DoctorSeverity::CRITICAL, check.system,
                   check.name, "Fix threw: " + std::string(e.what()), false);
        }
    } else {
        Report(DoctorSeverity::WARN, check.system,
               check.name, "No auto-fix — manual intervention needed", false);
    }

    if (check.fail_count >= check.max_fails) {
        TLOG_WARN(MOD, "Check disabled after " +
                  std::to_string(check.max_fails) + " failures: " + check.name);
    }
}

// ============================================================
// ENGINE CORE CHECKS
// ============================================================
void EngineDoctor::RegisterEngineChecks() {
    // Config: all critical keys present
    RegisterCheck({
        "Config keys present", "Config",
        []() {
            return !TCONFIG.ShaderDir().empty() &&
                   !TCONFIG.AssetDir().empty()  &&
                   !TCONFIG.SaveDir().empty();
        },
        []() {
            TCONFIG.SetDefaults();
            TCONFIG.Save();
            TLOG_INFO("EngineDoctor", "Config: restored defaults + saved");
        },
        300 // check every 5s at 60fps
    });

    // Save directory exists
    RegisterCheck({
        "Save directory exists", "SaveSystem",
        []() {
            std::string dir = TCONFIG.SaveDir();
            return std::filesystem::exists(dir) ||
                   std::filesystem::create_directories(dir);
        },
        []() {
            std::filesystem::create_directories(TCONFIG.SaveDir());
            TLOG_INFO("EngineDoctor", "Save dir created: " + TCONFIG.SaveDir());
        },
        600
    });

    // Terra engine running
    RegisterCheck({
        "TerraCore running", "TerraCore",
        []() { return TERRA.IsRunning(); },
        nullptr, // cannot auto-restart TerraCore
        60, 0, 1 // only fail once — CRITICAL
    });

    // .env file exists
    RegisterCheck({
        ".env file exists", "Config",
        []() {
            std::ifstream f(TCONFIG.EnvFile());
            return f.good();
        },
        []() {
            // Create minimal .env so engine doesn't crash without keys
            std::ofstream f(TCONFIG.EnvFile());
            f << "# Terra Engine — fill in your API keys\n";
            f << "MAX_RETRIES=3\n";
            f << "TIMEOUT_SECONDS=30\n";
            TLOG_WARN("EngineDoctor", ".env missing — created placeholder");
        },
        1800 // check every 30s
    });
}

// ============================================================
// RENDERER CHECKS
// ============================================================
void EngineDoctor::RegisterRendererChecks() {
    // Renderer ready
    RegisterCheck({
        "Renderer ready", "Renderer",
        []() { return RENDERER.IsReady(); },
        nullptr, // can't auto-restart renderer
        120, 0, 1
    });

    // FPS not collapsed (< 5fps = something is very wrong)
    RegisterCheck({
        "FPS above minimum", "Renderer",
        []() {
            int fps = RENDERER.GetStats().fps;
            return fps == 0 || fps >= 5; // 0 = not measured yet
        },
        []() {
            // Drop to MEDIUM quality to recover frame rate
            if (RENDERER.GetQuality() != QualityTier::MEDIUM) {
                RENDERER.SetQuality(QualityTier::MEDIUM);
                TLOG_WARN("EngineDoctor",
                    "FPS collapsed — dropped to MEDIUM quality automatically");
            }
        },
        180 // check every 3s
    });

    // Draw calls not zero (if renderer up, should be drawing something)
    RegisterCheck({
        "Draw calls non-zero", "Renderer",
        []() {
            return !RENDERER.IsReady() ||
                   RENDERER.GetStats().draw_calls >= 0; // always true — placeholder
        },
        nullptr, 300, 0, 2
    });
}

// ============================================================
// PHYSICS CHECKS
// ============================================================
void EngineDoctor::RegisterPhysicsChecks() {
    // No NaN positions in physics bodies
    RegisterCheck({
        "No NaN physics positions", "Physics",
        []() {
            // Sample check — full scan would iterate all bodies
            // PhysicsWorld exposes no body iterator yet — check is structural
            return true;
        },
        nullptr, 120
    });
}

// ============================================================
// AUDIO CHECKS
// ============================================================
void EngineDoctor::RegisterAudioChecks() {
    // Audio system alive
    RegisterCheck({
        "Audio system ready", "Audio",
        []() { return AUDIO.IsReady(); },
        []() {
            AUDIO.Shutdown();
            AUDIO.Init();
            TLOG_INFO("EngineDoctor", "Audio system restarted");
        },
        300, 0, 2
    });

    // Master volume not accidentally zero
    RegisterCheck({
        "Master volume not zero", "Audio",
        []() { return AUDIO.GetBusVolume(AudioBus::MASTER) > 0.0f; },
        []() {
            AUDIO.SetBusVolume(AudioBus::MASTER, TCONFIG.MasterVolume());
            TLOG_WARN("EngineDoctor", "Master volume was 0 — restored from config");
        },
        300
    });
}

// ============================================================
// SAVE CHECKS
// ============================================================
void EngineDoctor::RegisterSaveChecks() {
    // Backup save exists if main save exists
    RegisterCheck({
        "Save backup integrity", "SaveSystem",
        []() {
            // Check slot 0 — if main exists, backup should too
            std::string main   = TCONFIG.SaveDir() + "save_0.terra";
            std::string backup = main + ".bak";
            if (!std::filesystem::exists(main)) return true; // no save = OK
            return std::filesystem::exists(backup);
        },
        []() {
            std::string main   = TCONFIG.SaveDir() + "save_0.terra";
            std::string backup = main + ".bak";
            if (std::filesystem::exists(main)) {
                std::filesystem::copy_file(main, backup,
                    std::filesystem::copy_options::overwrite_existing);
                TLOG_INFO("EngineDoctor", "Save backup recreated");
            }
        },
        600
    });

    // Save file not corrupted (magic bytes check)
    RegisterCheck({
        "Save file not corrupted", "SaveSystem",
        []() {
            std::string path = TCONFIG.SaveDir() + "save_0.terra";
            if (!std::filesystem::exists(path)) return true;
            std::ifstream f(path, std::ios::binary);
            if (!f.is_open()) return false;
            uint32_t magic = 0;
            f.read(reinterpret_cast<char*>(&magic), sizeof(magic));
            return magic == 0x53415645; // "SAVE"
        },
        []() {
            // Restore from backup
            std::string main   = TCONFIG.SaveDir() + "save_0.terra";
            std::string backup = main + ".bak";
            if (std::filesystem::exists(backup)) {
                std::filesystem::copy_file(backup, main,
                    std::filesystem::copy_options::overwrite_existing);
                TLOG_WARN("EngineDoctor",
                    "Save file corrupted — restored from backup");
            } else {
                TLOG_ERR("EngineDoctor",
                    "Save file corrupted AND no backup — player must start over");
            }
        },
        600
    });
}

// ============================================================
// AI AGENT CHECKS
// ============================================================
void EngineDoctor::RegisterAIChecks() {
    // AgentBus healthy
    RegisterCheck({
        "AgentBus registered agents", "AgentBus",
        []() {
            return BUS.GetAgentCount() >= 6; // all 6 agents must be registered
        },
        nullptr, // can't auto-register agents
        600, 0, 1
    });
}

// ============================================================
// MEMORY CHECKS
// ============================================================
void EngineDoctor::RegisterMemoryChecks() {
    // Asset cache not bloated (> 512MB = evict)
    RegisterCheck({
        "Asset cache size", "AssetLoader",
        []() {
            return ASSETS.CacheSize() < 512 * 1024 * 1024; // 512MB
        },
        []() {
            ASSETS.EvictAll();
            TLOG_WARN("EngineDoctor",
                "Asset cache exceeded 512MB — evicted all. Will reload on demand.");
        },
        600
    });
}

// ============================================================
// REGISTER / REPORT
// ============================================================
void EngineDoctor::RegisterCheck(const HealthCheck& check) {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_checks.push_back(check);
}

void EngineDoctor::Report(DoctorSeverity sev, const std::string& sys,
                           const std::string& issue, const std::string& action,
                           bool fixed)
{
    DoctorReport r;
    r.severity    = sev;
    r.system      = sys;
    r.issue       = issue;
    r.action      = action;
    r.auto_fixed  = fixed;
    r.timestamp_ms= NowMs();
    m_reports.push_back(r);

    const char* prefix =
        sev == DoctorSeverity::FIXED    ? "[FIXED]   " :
        sev == DoctorSeverity::WARN     ? "[WARN]    " :
        sev == DoctorSeverity::CRITICAL ? "[CRITICAL]" : "[INFO]    ";

    std::string msg = std::string(prefix) + " [" + sys + "] " + issue;
    if (!action.empty()) msg += " → " + action;
    TLOG_INFO(MOD, msg);
}

std::vector<DoctorReport> EngineDoctor::GetReports() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    return m_reports;
}

void EngineDoctor::ClearReports() {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_reports.clear();
}

void EngineDoctor::PrintReport() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    TLOG_INFO(MOD, "=== ENGINE HEALTH REPORT ===");
    TLOG_INFO(MOD, "Checks registered: " + std::to_string(m_checks.size()));
    TLOG_INFO(MOD, "Issues detected:   " + std::to_string(m_issue_count.load()));
    TLOG_INFO(MOD, "Auto-fixed:        " + std::to_string(m_fix_count.load()));

    for (const auto& r : m_reports) {
        std::string line = r.system + " — " + r.issue;
        if (r.auto_fixed) line += " [FIXED: " + r.action + "]";
        TLOG_INFO(MOD, "  " + line);
    }
    TLOG_INFO(MOD, "============================");
}

} // namespace TerraEngine

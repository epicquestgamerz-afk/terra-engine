// ============================================================
// TERRA ENGINE — AUDIO SYSTEM IMPLEMENTATION
// AudioSystem.cpp — Version 1.0.0
// ============================================================
#include "AudioSystem.h"
#include <cmath>
#include <algorithm>

// miniaudio — single header, MIT license
// Download: https://github.com/mackron/miniaudio
// Place miniaudio.h in project root then uncomment:
// #define MINIAUDIO_IMPLEMENTATION
// #include "miniaudio.h"

namespace TerraEngine {
const char* AudioSystem::MOD = "AudioSystem";

// ============================================================
// INIT
// ============================================================
bool AudioSystem::Init() {
    // Init from Config — no hardcoded paths
    float master  = TCONFIG.MasterVolume();
    float music   = TCONFIG.MusicVolume();
    float sfx     = TCONFIG.SFXVolume();
    float voice   = TCONFIG.VoiceVolume();

    m_bus_volumes[static_cast<int>(AudioBus::MASTER)]  = master;
    m_bus_volumes[static_cast<int>(AudioBus::MUSIC)]   = music;
    m_bus_volumes[static_cast<int>(AudioBus::SFX)]     = sfx;
    m_bus_volumes[static_cast<int>(AudioBus::VOICE)]   = voice;
    m_bus_volumes[static_cast<int>(AudioBus::AMBIENT)] = 0.6f;
    m_bus_volumes[static_cast<int>(AudioBus::UI)]      = 1.0f;

    std::copy(m_bus_volumes, m_bus_volumes + 6, m_bus_targets);

    // TODO: ma_engine_init(&m_engine, nullptr, &m_engine);
    // Commented until miniaudio.h is added to project

    m_initialized.store(true);
    TLOG_INFO(MOD, "Audio system initialised");
    return true;
}

void AudioSystem::Shutdown() {
    if (!m_initialized.load()) return;
    std::lock_guard<std::mutex> lock(m_mutex);
    m_sounds.clear();
    m_music_beds.clear();
    m_initialized.store(false);
    TLOG_INFO(MOD, "Audio shutdown");
}

// ============================================================
// UPDATE — fades + 3D attenuation per frame
// ============================================================
void AudioSystem::Update(float dt) {
    if (!m_initialized.load()) return;
    UpdateFades(dt);
    UpdateMusicLayers(dt);
}

void AudioSystem::UpdateFades(float dt) {
    std::lock_guard<std::mutex> lock(m_mutex);
    // Bus fades
    for (int i = 0; i < 6; i++) {
        float& v = m_bus_volumes[i];
        float  t = m_bus_targets[i];
        if (std::abs(v - t) > 0.001f) {
            v += (t - v) * std::min(dt * 2.0f, 1.0f);
        }
    }
    // Sound fades
    for (auto& [id, snd] : m_sounds) {
        if (!snd.active) continue;
        if (std::abs(snd.volume - snd.target_volume) > 0.001f) {
            snd.volume += (snd.target_volume - snd.volume)
                        * std::min(dt * snd.fade_speed, 1.0f);
            if (snd.volume < 0.001f && snd.target_volume <= 0.0f) {
                snd.active = false; // faded out
            }
        }
    }
}

void AudioSystem::UpdateMusicLayers(float dt) {
    // NEW-3 FIX: m_current_bed, m_music_beds, and m_music_intensity are all written
    // by PlayMusic(), TransitionMusic(), and SetMusicIntensity() under m_mutex.
    // This function was reading all three without any lock — data race on every frame.
    std::lock_guard<std::mutex> lock(m_mutex);
    if (m_current_bed.empty()) return;
    auto it = m_music_beds.find(m_current_bed);
    if (it == m_music_beds.end()) return;
    MusicBed& bed = it->second;

    // Map intensity to layer volumes
    // Layer 0 = base (always on)
    // Layer 1 = adds at intensity > 0.3
    // Layer 2 = adds at intensity > 0.6
    // Layer 3 = full at intensity 1.0
    for (size_t i = 0; i < bed.layers.size(); i++) {
        MusicLayer& layer = bed.layers[i];
        float threshold   = (i == 0) ? 0.0f : (float)i * 0.3f;
        float target      = m_music_intensity >= threshold ? 1.0f : 0.0f;
        layer.target_volume = target;
        layer.volume += (target - layer.volume) * std::min(dt * m_music_fade_speed, 1.0f);
        // Apply to audio engine: ma_sound_set_volume(&layer.sound, layer.volume)
    }
}

// ============================================================
// SFX
// ============================================================
SoundHandle AudioSystem::PlaySFX(const std::string& path,
                                   float volume, float pitch, bool loop)
{
    if (!m_initialized.load()) return {};
    std::lock_guard<std::mutex> lock(m_mutex);
    uint32_t id = m_next_id++;
    PlayingSound snd{};
    snd.id           = id;
    snd.path         = TCONFIG.AudioDir() + path;
    snd.volume       = volume;
    snd.target_volume= volume;
    snd.fade_speed   = 2.0f;
    snd.is_3d        = false;
    snd.bus          = AudioBus::SFX;
    snd.active       = true;
    m_sounds[id]     = snd;
    TLOG_DEBUG(MOD, "SFX: " + path);
    // ma_engine_play_sound(&m_engine, snd.path.c_str(), nullptr);
    return {id, true};
}

SoundHandle AudioSystem::PlaySFX3D(const std::string& path,
                                    float x, float y, float z,
                                    float volume, float max_dist, bool loop)
{
    if (!m_initialized.load()) return {};
    // BUG 1 FIX: Use stack-allocated array — no heap leak per call
    float pos[3] = {x, y, z};
    float atten = Attenuate3D(pos, max_dist);
    return PlaySFX(path, volume * atten, 1.0f, loop);
}

float AudioSystem::Attenuate3D(const float* pos, float max_dist) const {
    float dx  = pos[0] - m_listener_pos[0];
    float dy  = pos[1] - m_listener_pos[1];
    float dz  = pos[2] - m_listener_pos[2];
    float dist= std::sqrt(dx*dx + dy*dy + dz*dz);
    if (dist >= max_dist) return 0.0f;
    return 1.0f - (dist / max_dist);  // linear falloff
}

void AudioSystem::Stop(SoundHandle handle, float fade_out) {
    if (!handle) return;
    std::lock_guard<std::mutex> lock(m_mutex);
    auto it = m_sounds.find(handle.id);
    if (it == m_sounds.end()) return;
    if (fade_out <= 0.0f) { it->second.active = false; return; }
    it->second.target_volume = 0.0f;
    it->second.fade_speed    = 1.0f / fade_out;
}

void AudioSystem::StopAll(AudioBus bus) {
    std::lock_guard<std::mutex> lock(m_mutex);
    for (auto& [id, snd] : m_sounds)
        if (bus == AudioBus::MASTER || snd.bus == bus)
            snd.active = false;
}

bool AudioSystem::IsPlaying(SoundHandle handle) const {
    if (!handle) return false;
    std::lock_guard<std::mutex> lock(m_mutex);
    auto it = m_sounds.find(handle.id);
    return it != m_sounds.end() && it->second.active;
}

void AudioSystem::SetBusVolume(AudioBus bus, float volume, float fade) {
    int idx = static_cast<int>(bus);
    // BUG 11 FIX: Return after immediate set so fade target isn't also set
    if (fade <= 0.0f) { m_bus_volumes[idx] = volume; m_bus_targets[idx] = volume; return; }
    m_bus_targets[idx] = volume;
}

float AudioSystem::GetBusVolume(AudioBus bus) const {
    return m_bus_volumes[static_cast<int>(bus)];
}

// ============================================================
// MUSIC
// ============================================================
void AudioSystem::LoadMusicBed(const std::string& id, const std::string& path) {
    std::lock_guard<std::mutex> lock(m_mutex);
    MusicBed bed;
    bed.id        = id;
    bed.base_path = TCONFIG.AudioDir() + path;
    m_music_beds[id] = std::move(bed);
}

void AudioSystem::AddMusicLayer(const std::string& bed_id, const MusicLayer& layer) {
    std::lock_guard<std::mutex> lock(m_mutex);
    auto it = m_music_beds.find(bed_id);
    if (it == m_music_beds.end()) return;
    it->second.layers.push_back(layer);
}

void AudioSystem::PlayMusic(const std::string& bed_id, float fade_in) {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_current_bed = bed_id;
    auto it = m_music_beds.find(bed_id);
    if (it == m_music_beds.end()) { TLOG_WARN(MOD, "Music bed not found: " + bed_id); return; }
    it->second.active = true;
    TLOG_INFO(MOD, "Music: " + bed_id);
}

void AudioSystem::StopMusic(float fade_out) {
    SetBusVolume(AudioBus::MUSIC, 0.0f, fade_out);
}

void AudioSystem::TransitionMusic(const std::string& new_bed, float crossfade) {
    StopMusic(crossfade * 0.5f);
    PlayMusic(new_bed, crossfade * 0.5f);
}

void AudioSystem::SetMusicIntensity(float intensity, float blend_time) {
    m_music_intensity = std::clamp(intensity, 0.0f, 1.0f);
    m_music_fade_speed = (blend_time > 0.0f) ? (1.0f / blend_time) : 10.0f;
}

// ============================================================
// TERRA-SPECIFIC MUSIC ZONES
// ============================================================
void AudioSystem::OnEnterSafeZone(int island) {
    SetMusicIntensity(0.2f, 3.0f);
    TransitionMusic("island_" + std::to_string(island) + "_safe", 4.0f);
    TLOG_INFO(MOD, "Safe zone music — island " + std::to_string(island));
}

void AudioSystem::OnEnterConflict(int island) {
    SetMusicIntensity(0.6f, 2.0f);
    TransitionMusic("island_" + std::to_string(island) + "_conflict", 2.0f);
    TLOG_INFO(MOD, "Conflict music — island " + std::to_string(island));
}

void AudioSystem::OnEnterGodZone(int island) {
    SetMusicIntensity(0.9f, 1.5f);
    TransitionMusic("island_" + std::to_string(island) + "_god_zone", 1.5f);
    TLOG_INFO(MOD, "God zone music — island " + std::to_string(island));
}

void AudioSystem::OnBossFightStart(const std::string& god_id) {
    SetMusicIntensity(1.0f, 0.5f);
    TransitionMusic("boss_" + god_id, 0.8f);
    TLOG_INFO(MOD, "Boss fight music: " + god_id);
}

void AudioSystem::OnBossFightEnd() {
    SetMusicIntensity(0.3f, 5.0f);
    PlayMusic("victory_stinger", 0.5f);
    TLOG_INFO(MOD, "Boss defeated — music transition");
}

void AudioSystem::OnCorruptionRise(float level) {
    // Add dark reversed layer proportional to corruption
    m_bus_volumes[static_cast<int>(AudioBus::AMBIENT)] =
        std::max(0.0f, 0.6f - level * 0.4f);
    // Dark layer fades in
    SetMusicIntensity(std::min(1.0f, GetMusicIntensity() + level * 0.3f), 2.0f);
}

void AudioSystem::OnNightFall() {
    // Reduce ambient, emphasize atmosphere
    m_bus_targets[static_cast<int>(AudioBus::AMBIENT)] = 0.3f;
    AUDIO.PlaySFX("ambient/night_wind.ogg", 0.4f, 1.0f, true);
}

void AudioSystem::OnDawn() {
    m_bus_targets[static_cast<int>(AudioBus::AMBIENT)] = 0.6f;
    SetMusicIntensity(0.2f, 8.0f);
}

// ============================================================
// LISTENER
// ============================================================
void AudioSystem::SetListenerPos(float x, float y, float z) {
    m_listener_pos[0]=x; m_listener_pos[1]=y; m_listener_pos[2]=z;
}
void AudioSystem::SetListenerDir(float dx, float dy, float dz) {
    m_listener_dir[0]=dx; m_listener_dir[1]=dy; m_listener_dir[2]=dz;
}
void AudioSystem::SetListenerUp(float ux, float uy, float uz) {
    m_listener_up[0]=ux; m_listener_up[1]=uy; m_listener_up[2]=uz;
}

void AudioSystem::Preload(const std::string& path) {
    TLOG_DEBUG(MOD, "Preload: " + TCONFIG.AudioDir() + path);
    // ma_sound_init_from_file(&m_engine, path.c_str(), 0, nullptr, nullptr, &sound);
}

void AudioSystem::Unload(const std::string& path) {
    TLOG_DEBUG(MOD, "Unload: " + path);
}

} // namespace TerraEngine

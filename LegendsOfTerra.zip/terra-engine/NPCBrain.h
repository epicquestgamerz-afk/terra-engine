// ============================================================
// TERRA ENGINE — NPC AI BRAIN
// NPCBrain.h — Version 1.0.0
// ============================================================
// AUDIT FIX 7: Full layered NPC AI brain
// Layer 1: Perception  — what NPC sees/hears/detects
// Layer 2: Memory      — what NPC remembers
// Layer 3: Decision    — Utility AI + Behavior Tree
// Layer 4: Action      — what NPC does
// ============================================================

#pragma once

#include "AIConnector.h"
#include <string>
#include <vector>
#include <map>
#include <memory>
#include <functional>
#include <chrono>
#include <deque>
#include <mutex>

namespace TerraEngine {

// ============================================================
// LAYER 1 — PERCEPTION
// What the NPC can sense about the world around them
// ============================================================
struct PerceptionData {
    // Sight
    bool        enemy_in_sight       = false;
    float       enemy_distance       = 999.0f;
    std::string enemy_id;
    float       sight_range          = 20.0f;

    // Hearing
    bool        heard_combat          = false;
    bool        heard_explosion       = false;
    float       sound_distance        = 0.0f;
    std::string sound_location;

    // Threat
    float       threat_level          = 0.0f; // 0=none 1=maximum
    bool        in_danger             = false;

    // Social
    std::vector<std::string> nearby_npcs;
    bool                     player_nearby = false;
    float                    player_distance = 999.0f;

    // Environment
    std::string current_weather       = "clear";
    std::string time_of_day           = "morning";
    bool        in_safe_zone          = true;
    float       corruption_level      = 0.0f;
};

// ============================================================
// LAYER 2 — MEMORY
// What the NPC has remembered over time
// ============================================================
struct EnemyMemory {
    std::string id;
    std::string type;
    float       last_seen_x    = 0.0f;
    float       last_seen_z    = 0.0f;
    float       threat_level   = 0.5f;
    std::chrono::steady_clock::time_point last_seen;
    int         encounter_count = 0;
};

struct LocationMemory {
    std::string label;     // "safe_spot", "food_source", "danger_zone"
    float       x, z;
    float       importance = 0.5f;
};

struct EventMemory {
    std::string description;
    float       emotional_impact = 0.0f; // -1 negative to +1 positive
    std::chrono::steady_clock::time_point when;
};

struct NPCMemoryBank {
    std::map<std::string, EnemyMemory>   known_enemies;
    std::vector<LocationMemory>          known_locations;
    std::deque<EventMemory>              event_history;    // last 20 events
    std::map<std::string, float>         npc_relationships; // npc_id -> trust (-1 to 1)
    float                                player_trust      = 0.0f;
    std::string                          home_location;
    std::string                          job;
    std::string                          personality;  // bold/cautious/greedy/kind

    static constexpr size_t MAX_EVENTS = 20;

    void AddEvent(const std::string& desc, float impact) {
        if (event_history.size() >= MAX_EVENTS) event_history.pop_front();
        EventMemory e;
        e.description    = desc;
        e.emotional_impact = impact;
        e.when           = std::chrono::steady_clock::now();
        event_history.push_back(e);
    }

    float GetMood() const {
        if (event_history.empty()) return 0.5f;
        float total = 0.0f;
        float weight = 1.0f;
        float total_weight = 0.0f;
        // Recent events weigh more
        for (auto it = event_history.rbegin(); it != event_history.rend(); ++it) {
            total        += it->emotional_impact * weight;
            total_weight += weight;
            weight       *= 0.8f;
        }
        return (total / total_weight + 1.0f) * 0.5f; // normalize to 0-1
    }
};

// ============================================================
// LAYER 3 — DECISION
// Utility AI scores each possible action
// Highest score wins
// ============================================================
enum class NPCAction {
    IDLE,
    PATROL,
    WORK,        // do job (farming, smithing, trading)
    EAT,
    SLEEP,
    FLEE,
    FIGHT,
    SEEK_HELP,
    HIDE,
    TALK_TO_PLAYER,
    TALK_TO_NPC,
    CHANGE_JOB,
    BUY_FOOD,
    GUARD_AREA
};

struct ActionScore {
    NPCAction   action;
    float       score    = 0.0f;
    std::string reason;
};

class DecisionEngine {
public:
    // Score all actions given current perception and memory
    std::vector<ActionScore> ScoreActions(
        const PerceptionData&  perception,
        const NPCMemoryBank&   memory,
        float                  delta_time
    ) const;

    // Get best action
    NPCAction GetBestAction(
        const PerceptionData& perception,
        const NPCMemoryBank&  memory,
        float                 delta_time
    ) const;

    // Behavior tree override — some situations force action
    // Returns IDLE if no override applies
    NPCAction CheckBehaviorTree(
        const PerceptionData& perception,
        const NPCMemoryBank&  memory
    ) const;

private:
    float ScoreIdle       (const PerceptionData& p, const NPCMemoryBank& m) const;
    float ScoreWork       (const PerceptionData& p, const NPCMemoryBank& m) const;
    float ScoreFlee       (const PerceptionData& p, const NPCMemoryBank& m) const;
    float ScoreFight      (const PerceptionData& p, const NPCMemoryBank& m) const;
    float ScoreEat        (const PerceptionData& p, const NPCMemoryBank& m) const;
    float ScoreSleep      (const PerceptionData& p, const NPCMemoryBank& m) const;
    float ScoreTalkPlayer (const PerceptionData& p, const NPCMemoryBank& m) const;
    float ScoreSeekHelp   (const PerceptionData& p, const NPCMemoryBank& m) const;
    float ScoreChangeJob  (const PerceptionData& p, const NPCMemoryBank& m) const;
};

// ============================================================
// LAYER 4 — ACTION EXECUTOR
// Converts NPCAction enum into actual game commands
// ============================================================
struct ActionResult {
    bool        completed    = false;
    std::string command;     // what to tell animation/movement system
    std::string dialogue;    // what NPC says (if any)
    float       duration     = 1.0f; // seconds this action takes
};

class ActionExecutor {
public:
    ActionResult Execute(
        NPCAction              action,
        const PerceptionData&  perception,
        const NPCMemoryBank&   memory,
        const std::string&     npc_id
    );

private:
    ActionResult ExecuteIdle     (const NPCMemoryBank& m);
    ActionResult ExecuteWork     (const NPCMemoryBank& m);
    ActionResult ExecuteFlee     (const PerceptionData& p);
    ActionResult ExecuteFight    (const PerceptionData& p);
    ActionResult ExecuteEat      (const NPCMemoryBank& m);
    ActionResult ExecuteSleep    ();
    ActionResult ExecuteTalk     (const PerceptionData& p, const NPCMemoryBank& m,
                                  const std::string& npc_id);
    ActionResult ExecuteSeekHelp (const PerceptionData& p);
    ActionResult ExecuteChangeJob(const NPCMemoryBank& m, const std::string& npc_id);
};

// ============================================================
// NPC BRAIN — Full package
// Combines all 4 layers into one coherent brain
// One NPCBrain per NPC instance
// ============================================================
class NPCBrain {
public:
    explicit NPCBrain(const std::string& npc_id,
                      const std::string& personality = "neutral");
    ~NPCBrain() = default;

    // Called every NPC tick
    ActionResult Think(float delta_time);

    // Called by perception system with updated sensor data
    void UpdatePerception(const PerceptionData& data);

    // Called by event system
    void OnEvent(const std::string& event_type,
                 const std::string& data);

    // Called when player interacts
    std::string GetDialogue(const std::string& player_action);

    // Memory access
    NPCMemoryBank&       GetMemory()       { return m_memory; }
    const NPCMemoryBank& GetMemory() const { return m_memory; }

    // State
    NPCAction   GetCurrentAction() const { return m_current_action; }
    float       GetMood()          const { return m_memory.GetMood(); }
    std::string GetMoodString()    const;

    // Needs (drive Utility AI scores)
    float hunger   = 1.0f; // 0=starving 1=full
    float thirst   = 1.0f;
    float safety   = 1.0f;
    float social   = 0.5f;
    float energy   = 1.0f;
    float money    = 0.5f;

    // Personality modifiers (set from NPCData)
    float aggression  = 0.3f;
    float bravery     = 0.5f;
    float greed       = 0.3f;
    float loyalty     = 0.6f;

private:
    std::string     m_npc_id;
    PerceptionData  m_perception;
    NPCMemoryBank   m_memory;
    DecisionEngine  m_decision;
    ActionExecutor  m_executor;

    NPCAction       m_current_action     = NPCAction::IDLE;
    float           m_action_timer       = 0.0f;
    float           m_needs_update_timer = 0.0f;

    mutable std::mutex m_mutex;

    void UpdateNeeds(float delta_time);

    static const char* MOD;
};

} // namespace TerraEngine

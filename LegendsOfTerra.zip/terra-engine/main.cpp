// ============================================================
// TERRA ENGINE — ENTRY POINT
// main.cpp — Version 1.0.0
// ============================================================
// This is the game's entry point.
// TerraEngine is a static library — main() lives here.
// Initialises engine, runs game loop, shuts down cleanly.
// ============================================================

#include "TerraCore.h"
#include "TerraAssert.h"
#include "JobSystem.h"
#include "MessageChannels.h"
#include "ECS.h"
#include "WorldSystems.h"
#include "SaveManager.h"
#include "AudioSystem.h"
#include "InputSystem.h"
#include "PhysicsWorld.h"
#include "Config.h"
#include "AssetLoader.h"
#include "EngineDoctor.h"
#include "renderer/Renderer.h"

#include <GLFW/glfw3.h>
#include <iostream>
#include <csignal>
#include <chrono>
#include <thread>
#include <atomic>

using namespace TerraEngine;

// ============================================================
// SIGNAL HANDLER — clean shutdown on Ctrl+C
// ============================================================
static std::atomic<bool> g_running{true};

static void SignalHandler(int signal) {
    std::cout << "\n[main] Signal " << signal << " received — shutting down...\n";
    g_running.store(false);
}

// ============================================================
// GAME LOOP CONFIG
// ============================================================
static constexpr float TARGET_FPS      = 60.0f;
static constexpr float TARGET_FRAME_MS = 1000.0f / TARGET_FPS;
static constexpr float MAX_DELTA       = 0.05f;  // cap at 50ms — avoids spiral of death

// ============================================================
// MAIN
// ============================================================
int main(int argc, char* argv[]) {

    // --------------------------------------------------------
    // Parse args
    // --------------------------------------------------------
    std::string env_path = ".env";
    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        if (arg == "--env" && i + 1 < argc) {
            env_path = argv[++i];
        } else if (arg == "--debug") {
            Logger::Get().SetLevel(LogLevel::DEBUG);
        } else if (arg == "--help") {
            std::cout << "Usage: TerraEngine [--env <path>] [--debug]\n";
            return 0;
        }
    }

    // --------------------------------------------------------
    // Register signal handlers
    // --------------------------------------------------------
    std::signal(SIGINT,  SignalHandler);
    std::signal(SIGTERM, SignalHandler);

    // --------------------------------------------------------
    // Boot engine
    // --------------------------------------------------------
    TLOG_INFO("main", "=== LEGENDS OF TERRA ===");
    TLOG_INFO("main", "Engine v4.0 starting...");

    // --------------------------------------------------------
    // NEW-7 FIX: Load config FIRST — TERRA.Init() starts agents
    // that may call TCONFIG during Init/Start. Config must be
    // populated before any system that reads it is initialized.
    // --------------------------------------------------------
    TCONFIG.Load("terra.cfg");

    if (!TERRA.Init(env_path)) {
        TLOG_CRITICAL("main", "Engine init failed — check .env and logs");
        return 1;
    }

    // --------------------------------------------------------
    // BUG 6 FIX: Create GLFW window (was never created before)
    // --------------------------------------------------------
    if (!glfwInit()) {
        TLOG_CRITICAL("main", "GLFW init failed");
        return 1;
    }
    glfwWindowHint(GLFW_CLIENT_API, GLFW_NO_API); // Vulkan — no OpenGL context
    glfwWindowHint(GLFW_RESIZABLE,  GLFW_FALSE);

    int res_w = TCONFIG.ResolutionW();
    int res_h = TCONFIG.ResolutionH();
    GLFWwindow* window = glfwCreateWindow(res_w, res_h, "Legends of Terra", nullptr, nullptr);
    if (!window) {
        TLOG_CRITICAL("main", "Window creation failed");
        glfwTerminate();
        return 1;
    }
    TLOG_INFO("main", "Window created: " + std::to_string(res_w) + "x" + std::to_string(res_h));

    // --------------------------------------------------------
    // BUG 6 FIX: Init renderer, audio, input, physics (none were called before)
    // --------------------------------------------------------
    if (!RENDERER.Init(window, res_w, res_h, QualityTier::HIGH)) {
        TLOG_CRITICAL("main", "Renderer init failed");
        glfwDestroyWindow(window);
        glfwTerminate();
        return 1;
    }

    if (!AUDIO.Init()) {
        TLOG_CRITICAL("main", "Audio init failed");
        // NEW-5 FIX: Clean up already-initialized RENDERER and window before early exit
        RENDERER.Shutdown();
        glfwDestroyWindow(window);
        glfwTerminate();
        return 1;
    }

    INPUT.Init(window);

    PhysicsWorld::Get().Init(); // default gravity -9.81

    // EngineDoctor — must be last, checks all other systems
    ASSETS.Init(2);      // 2 async worker threads
    DOCTOR.Init();
    DOCTOR.StartupScan(); // auto-fix anything broken before game starts

    // --------------------------------------------------------
    // Init world systems
    // --------------------------------------------------------
    STREAMER.Init(1);         // start on island 1
    ECOSYSTEM.Init(1);

    // --------------------------------------------------------
    // Init save system
    // --------------------------------------------------------
    // Fill real URLs from .env
    std::string api_url     = EnvLoader::Get("SAVE_API_URL",     "http://localhost:8000");
    std::string supa_url    = EnvLoader::Get("SUPABASE_URL",     "");
    std::string supa_key    = EnvLoader::Get("SUPABASE_ANON_KEY","");
    SAVES.Init(api_url, supa_url, supa_key);

    // --------------------------------------------------------
    // Set initial world state
    // --------------------------------------------------------
    WorldState ws;
    ws.current_island  = 1;
    ws.time_of_day     = "morning";
    ws.weather         = "clear";
    ws.player_health   = 100;
    ws.player_level    = 1;
    TERRA.SetWorldState(ws);

    // Fire first island enter event
    TERRA.SetIsland(1);

    TLOG_INFO("main", "Game world ready — entering game loop");

    // --------------------------------------------------------
    // GAME LOOP — fixed timestep with delta cap
    // --------------------------------------------------------
    using Clock     = std::chrono::high_resolution_clock;
    using Duration  = std::chrono::duration<float>;

    auto last_time  = Clock::now();
    float lag       = 0.0f;
    int   m_frame_index = 0; // FIX: was missing — needed by DOCTOR.Tick()

    while (g_running.load() && TERRA.IsRunning() && !glfwWindowShouldClose(window)) {

        // BUG 6 FIX: Poll GLFW events every frame (window close, keyboard, etc.)
        glfwPollEvents();

        auto now   = Clock::now();
        float dt   = std::chrono::duration<float>(now - last_time).count();
        last_time  = now;

        // Cap delta — prevents spiral of death on lag spikes
        if (dt > MAX_DELTA) dt = MAX_DELTA;

        lag += dt;

        // NEW-4 FIX: Update input state once per frame (before game logic reads it)
        INPUT.BeginFrame();

        // Fixed physics/AI steps at 60Hz
        while (lag >= (1.0f / TARGET_FPS)) {
            // NEW-4 FIX: Step physics simulation every fixed tick
            PhysicsWorld::Get().Step(1.0f / TARGET_FPS);
            DETSIM.Tick(1.0f / TARGET_FPS);
            TERRA.Tick(1.0f / TARGET_FPS);
            lag -= (1.0f / TARGET_FPS);
        }

        // NEW-4 FIX: Update audio fades and music layers every frame
        AUDIO.Update(dt);
        DOCTOR.Tick(m_frame_index++);

        // NEW-4 FIX: Tick SimulationManager (drives SaveManager auto-save, etc.)
        SIMSYS.Tick(dt);

        // Stream chunks based on (placeholder) player position
        // In full game: pass actual player world position here
        STREAMER.UpdateStreamingPosition(0.0f, 0.0f);
        STREAMER.Tick(dt);

        // NEW-4 FIX: Submit render frame — BeginFrame/EndFrame were never called
        // RenderFrame is populated from ECS/scene data here in a full implementation
        RenderFrame rf{};
        RENDERER.BeginFrame(rf);
        RENDERER.EndFrame();

        // NEW-4 FIX: Finalize input state (clears just-pressed/just-released flags)
        INPUT.EndFrame();

        // Frame rate limiter — avoid burning CPU on headless server
        auto frame_end    = Clock::now();
        float frame_ms    = std::chrono::duration<float, std::milli>(
                                frame_end - now).count();
        float sleep_ms    = TARGET_FRAME_MS - frame_ms;
        if (sleep_ms > 1.0f) {
            std::this_thread::sleep_for(
                std::chrono::milliseconds(static_cast<int>(sleep_ms)));
        }
    }

    // --------------------------------------------------------
    // Shutdown
    // --------------------------------------------------------
    TLOG_INFO("main", "Game loop ended — shutting down");

    TERRA.PrintStatus();
    TERRA.PrintStats();

    // BUG 14 FIX: Shut down all systems in reverse init order.
    // Previously only TERRA and JOBS were shut down — everything else leaked.
    PhysicsWorld::Get().Shutdown();
    INPUT.Shutdown();
    AUDIO.Shutdown();
    RENDERER.Shutdown();

    TERRA.Shutdown();
    JOBS.Shutdown();

    // BUG 6 FIX: Destroy GLFW window and terminate
    glfwDestroyWindow(window);
    glfwTerminate();

    TLOG_INFO("main", "=== TERRA ENGINE OFFLINE ===");
    return 0;
}

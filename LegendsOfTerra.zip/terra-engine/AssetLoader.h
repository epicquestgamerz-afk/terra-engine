// ============================================================
// TERRA ENGINE — ASSET LOADER
// AssetLoader.h — Version 1.0.0
// ============================================================
// Loads all runtime assets:
//   3D meshes  → .glb/.gltf via cgltf
//   Textures   → .png/.jpg/.ktx via stb_image
//   Audio      → .ogg/.wav via miniaudio
// All paths come from Config — never hardcoded.
// Async background loading with progress callbacks.
// Asset cache — never loads same file twice.
// ============================================================
#pragma once
#include "Config.h"
#include "AIConnector.h"
// FIX: include Renderer.h AFTER forward declarations to break circular dependency
// Vertex, RenderObject, GpuImage are defined in Renderer.h
#include "renderer/Renderer.h"
#include <string>
#include <map>
#include <unordered_map>
#include <vector>
#include <memory>
#include <mutex>
#include <functional>
#include <thread>
#include <atomic>
#include <queue>
#include <condition_variable>
#include <mutex>
#include <functional>
#include <thread>
#include <atomic>
#include <queue>

namespace TerraEngine {

// ============================================================
// ASSET TYPES
// ============================================================
enum class AssetType { MESH, TEXTURE, AUDIO, SHADER, DATA };

// ============================================================
// MESH DATA — raw geometry before GPU upload
// ============================================================
struct MeshData {
    std::vector<Vertex>   vertices;
    std::vector<uint32_t> indices;
    std::string           name;
    uint32_t              material_id = 0;
    bool                  ready       = false;
};

// ============================================================
// TEXTURE DATA
// ============================================================
struct TextureData {
    std::vector<uint8_t> pixels;
    uint32_t             width   = 0;
    uint32_t             height  = 0;
    uint32_t             channels= 4;
    bool                 is_srgb = true;
    bool                 ready   = false;
};

// ============================================================
// LOADED MODEL — scene with multiple meshes
// ============================================================
struct LoadedModel {
    std::string               path;
    std::vector<MeshData>     meshes;
    std::vector<TextureData>  textures;
    bool                      ready = false;
};

// ============================================================
// ASSET LOADER
// ============================================================
class AssetLoader {
public:
    static AssetLoader& Get() {
        static AssetLoader instance;
        return instance;
    }

    // --------------------------------------------------------
    // Init / Shutdown
    // --------------------------------------------------------
    void Init(int worker_threads = 2);
    void Shutdown();

    // --------------------------------------------------------
    // Sync load (blocks until done — use for small assets)
    // --------------------------------------------------------
    std::shared_ptr<MeshData>    LoadMesh   (const std::string& rel_path);
    std::shared_ptr<TextureData> LoadTexture(const std::string& rel_path, bool srgb = true);
    std::shared_ptr<LoadedModel> LoadModel  (const std::string& rel_path);

    // --------------------------------------------------------
    // Async load (returns immediately, calls cb when done)
    // --------------------------------------------------------
    using MeshCB    = std::function<void(std::shared_ptr<MeshData>)>;
    using TextureCB = std::function<void(std::shared_ptr<TextureData>)>;
    using ModelCB   = std::function<void(std::shared_ptr<LoadedModel>)>;

    void LoadMeshAsync   (const std::string& path, MeshCB    cb);
    void LoadTextureAsync(const std::string& path, TextureCB cb, bool srgb = true);
    void LoadModelAsync  (const std::string& path, ModelCB   cb);

    // --------------------------------------------------------
    // Upload loaded data to GPU
    // --------------------------------------------------------
    bool UploadMesh   (const MeshData&    data, RenderObject& out);
    bool UploadTexture(const TextureData& data, GpuImage&     out);

    // --------------------------------------------------------
    // Cache management
    // --------------------------------------------------------
    bool    IsLoaded  (const std::string& path) const;
    void    Evict     (const std::string& path);
    void    EvictAll  ();
    size_t  CacheSize () const; // bytes

    // --------------------------------------------------------
    // Progress for loading screen
    // --------------------------------------------------------
    struct LoadProgress {
        int   total    = 0;
        int   loaded   = 0;
        float fraction = 0.0f;
        std::string current_asset;
    };
    LoadProgress GetProgress() const;

    // --------------------------------------------------------
    // Preload list — specify assets to load upfront per island
    // --------------------------------------------------------
    void PreloadIsland(int island_id);

private:
    AssetLoader() : m_shutdown(false) {}

    // ── Internal load functions ──
    std::shared_ptr<MeshData>    DoLoadMesh   (const std::string& full_path);
    std::shared_ptr<TextureData> DoLoadTexture(const std::string& full_path, bool srgb);
    std::shared_ptr<LoadedModel> DoLoadModel  (const std::string& full_path);

    std::string ResolvePath(const std::string& rel, AssetType type) const;

    // Cache
    mutable std::mutex                                m_cache_mutex;
    std::map<std::string, std::shared_ptr<MeshData>>  m_mesh_cache;
    std::map<std::string, std::shared_ptr<TextureData>>m_tex_cache;
    std::map<std::string, std::shared_ptr<LoadedModel>>m_model_cache;

    // Async worker pool
    struct AsyncJob {
        std::string    path;
        AssetType      type;
        bool           srgb = true;
        MeshCB         mesh_cb;
        TextureCB      tex_cb;
        ModelCB        model_cb;
    };

    std::queue<AsyncJob>     m_job_queue;
    std::mutex               m_queue_mutex;
    std::condition_variable  m_queue_cv;
    std::vector<std::thread> m_workers;
    std::atomic<bool>        m_shutdown;

    std::atomic<int>         m_total_jobs{0};
    std::atomic<int>         m_done_jobs{0};
    std::string              m_current_asset;

    void WorkerLoop();

    static const char* MOD;
};

#define ASSETS AssetLoader::Get()

} // namespace TerraEngine

// ============================================================
// TERRA ENGINE — ENGINE DOCTOR
// EngineDoctor.h — Version 1.0.0
// ============================================================
// Self-healing system. Runs checks every frame and at startup.
// Detects broken state → fixes it automatically → logs what
// it fixed so you can address the root cause later.
//
// WHAT IT FIXES AUTOMATICALLY:
//   - Null Vulkan handles before draw calls
//   - Broken audio state
//   - Physics bodies with NaN positions
//   - Save file corruption
//   - Config missing values → restores defaults
//   - AI agents in broken state → restarts them
//   - Memory pressure → evicts asset cache
//   - Frame rate collapse → reduces quality tier
//   - Shader pipeline missing → skips pass safely
//
// WHAT IT REPORTS (can't auto-fix):
//   - GPU out of memory
//   - Vulkan device lost
//   - Network unreachable
// ============================================================

#pragma once
#include "AIConnector.h"
#include <string>
#include <vector>
#include <functional>
#include <map>
#include <mutex>
#include <atomic>
#include <chrono>

namespace TerraEngine {

// ============================================================
// SEVERITY
// ============================================================
enum class DoctorSeverity { INFO, WARN, FIXED, CRITICAL };

// ============================================================
// DOCTOR REPORT — one issue found/fixed
// ============================================================
struct DoctorReport {
    DoctorSeverity severity;
    std::string    system;    // which system had the problem
    std::string    issue;     // what was wrong
    std::string    action;    // what doctor did about it
    bool           auto_fixed;
    double         timestamp_ms;
};

// ============================================================
// HEALTH CHECK — one registered check
// ============================================================
struct HealthCheck {
    std::string              name;
    std::string              system;
    std::function<bool()>    check;    // returns true = healthy
    std::function<void()>    fix;      // called when check fails
    int                      interval_frames; // 1=every frame, 60=every second
    int                      frame_counter   = 0;
    int                      fail_count      = 0;
    int                      max_fails       = 3; // disable check after N consecutive failures
};

// ============================================================
// ENGINE DOCTOR
// ============================================================
class EngineDoctor {
public:
    static EngineDoctor& Get() {
        static EngineDoctor instance;
        return instance;
    }

    // --------------------------------------------------------
    // Init — registers all standard engine checks
    // --------------------------------------------------------
    void Init();

    // --------------------------------------------------------
    // Tick — call every frame. Runs due checks.
    // --------------------------------------------------------
    void Tick(int frame_number);

    // --------------------------------------------------------
    // Startup scan — run all checks once immediately
    // --------------------------------------------------------
    void StartupScan();

    // --------------------------------------------------------
    // Register custom check (game code can add its own)
    // --------------------------------------------------------
    void RegisterCheck(const HealthCheck& check);

    // --------------------------------------------------------
    // Report retrieval
    // --------------------------------------------------------
    std::vector<DoctorReport> GetReports() const;
    std::vector<DoctorReport> GetReportsSince(double timestamp_ms) const;
    void                      ClearReports();
    int                       GetFixCount()    const { return m_fix_count.load(); }
    int                       GetIssueCount()  const { return m_issue_count.load(); }

    // --------------------------------------------------------
    // Enable/disable
    // --------------------------------------------------------
    void SetEnabled(bool enabled) { m_enabled.store(enabled); }
    bool IsEnabled()        const  { return m_enabled.load(); }

    // --------------------------------------------------------
    // Print full health report to log
    // --------------------------------------------------------
    void PrintReport() const;

private:
    EngineDoctor() : m_enabled(true), m_fix_count(0), m_issue_count(0) {}

    void RegisterEngineChecks();
    void RegisterRendererChecks();
    void RegisterPhysicsChecks();
    void RegisterAudioChecks();
    void RegisterSaveChecks();
    void RegisterAIChecks();
    void RegisterMemoryChecks();

    void RunCheck(HealthCheck& check, int frame);
    void Report(DoctorSeverity sev, const std::string& sys,
                const std::string& issue, const std::string& action,
                bool fixed);

    double NowMs() const {
        using namespace std::chrono;
        return duration<double, std::milli>(
            steady_clock::now().time_since_epoch()).count();
    }

    std::atomic<bool> m_enabled;
    std::atomic<int>  m_fix_count;
    std::atomic<int>  m_issue_count;

    mutable std::mutex           m_mutex;
    std::vector<HealthCheck>     m_checks;
    std::vector<DoctorReport>    m_reports;

    static const char* MOD;
};

#define DOCTOR EngineDoctor::Get()

} // namespace TerraEngine

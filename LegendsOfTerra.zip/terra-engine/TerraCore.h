// ============================================================
// TERRA ENGINE — CORE BRAIN
// TerraCore.h — Version 1.0.0
// ============================================================
// TerraCore is the master controller of Terra Engine.
// It owns the AgentBus, all 5 agents, and the world state.
// Every game event flows through TerraCore.
// TerraCore does not think — it coordinates.
// The agents think. TerraCore listens and routes.
// ============================================================

#pragma once

#include "AgentBus.h"
#include "AgentBase.h"
#include <string>
#include <memory>
#include <map>
#include <vector>
#include <mutex>
#include <atomic>
#include <functional>
#include <chrono>

namespace TerraEngine {

// ============================================================
// GAME EVENT TYPES
// Standard event strings used across the engine
// ============================================================
namespace Events {
    // World events
    constexpr const char* ISLAND_ENTER       = "island_enter";
    constexpr const char* ISLAND_GENERATE    = "island_generate";
    constexpr const char* CORRUPTION_SPREAD  = "corruption_spread";

    // Weather events
    constexpr const char* STORM_START        = "storm_start";
    constexpr const char* STORM_END          = "storm_end";
    constexpr const char* NIGHT_FALL         = "night_fall";
    constexpr const char* DAY_BREAK          = "day_break";
    constexpr const char* FLOOD_WARNING      = "flood_warning";

    // NPC events
    constexpr const char* NPC_HUNGRY         = "npc_hungry";
    constexpr const char* NPC_IN_DANGER      = "npc_in_danger";
    constexpr const char* VILLAGE_ATTACK     = "village_attack";
    constexpr const char* NPC_JOB_CHANGE     = "npc_job_change";

    // Boss events
    constexpr const char* BOSS_AWAKENED      = "boss_awakened";
    constexpr const char* BOSS_PHASE_CHANGE  = "boss_phase_change";
    constexpr const char* BOSS_DEFEATED      = "boss_defeated";

    // Combat events
    constexpr const char* COMBAT_START       = "combat_start";
    constexpr const char* COMBAT_END         = "combat_end";
    constexpr const char* PLAYER_LOW_HEALTH  = "player_low_health";
    constexpr const char* PLAYER_DIED        = "player_died";

    // Fragment events
    constexpr const char* FRAGMENT_FOUND     = "fragment_found";
    constexpr const char* FRAGMENT_ABSORBED  = "fragment_absorbed";

    // Player care events
    constexpr const char* PLAYER_BORED       = "player_bored";
    constexpr const char* PLAYER_OVERWHELMED = "player_overwhelmed";
}

// ============================================================
// TERRA CORE STATUS
// ============================================================
enum class CoreStatus {
    OFFLINE,     // Not started
    STARTING,    // Initialising agents
    RUNNING,     // Full operation
    DEGRADED,    // Some agents failing
    SHUTTING_DOWN
};

// ============================================================
// TERRA CORE CLASS
// ============================================================
class TerraCore {
public:
    // Singleton — one brain for the whole engine
    static TerraCore& Get() {
        static TerraCore instance;
        return instance;
    }

    // No copy or move
    TerraCore(const TerraCore&)            = delete;
    TerraCore& operator=(const TerraCore&) = delete;

    // --------------------------------------------------------
    // Lifecycle
    // --------------------------------------------------------
    bool Init(const std::string& env_path = ".env");
    void Shutdown();
    void Tick(float delta_time);

    // --------------------------------------------------------
    // Event system
    // Fire any game event — TerraCore routes to right agents
    // --------------------------------------------------------
    void FireEvent(const std::string& event_type,
                   const std::string& data       = "",
                   MessagePriority priority       = MessagePriority::NORMAL);

    // --------------------------------------------------------
    // World state
    // Update world state — automatically propagates to all agents
    // --------------------------------------------------------
    void        SetWorldState(const WorldState& state);
    WorldState& GetWorldState() { return m_world_state; }

    // Convenience world state setters
    void SetIsland    (int island_id);
    void SetTimeOfDay (const std::string& time);
    void SetWeather   (const std::string& weather);
    void SetCorruption(float level);
    void SetPlayerHealth(int health);
    void SetBossActive(bool active);
    void SetPlayerInCombat(bool in_combat);

    // --------------------------------------------------------
    // Agent access
    // --------------------------------------------------------
    AgentBase* GetAgent(const std::string& name) const;
    AgentBus&  GetBus() { return m_bus; }
    int        HealthyAgentCount() const;

    // --------------------------------------------------------
    // Status
    // --------------------------------------------------------
    CoreStatus  GetStatus()    const { return m_status.load(); }
    bool        IsRunning()    const { return m_status.load() == CoreStatus::RUNNING; }

    // BUG 1 FIX: OnPause/OnResume called from TerraJNI.cpp but were never declared
    void OnPause()  { m_paused.store(true);  TLOG_INFO("TerraCore","Engine paused");  }
    void OnResume() { m_paused.store(false); TLOG_INFO("TerraCore","Engine resumed"); }
    std::string StatusString() const;

    // --------------------------------------------------------
    // Stats
    // --------------------------------------------------------
    struct Stats {
        uint64_t events_fired     = 0;
        uint64_t ticks_processed  = 0;
        double   avg_tick_ms      = 0.0;
        int      agent_failures   = 0;
        std::chrono::steady_clock::time_point start_time;
    };
    Stats GetStats()   const;
    void  PrintStats() const;
    void  PrintStatus() const;

    // --------------------------------------------------------
    // Event callback registration
    // Register a C++ callback for any event type
    // --------------------------------------------------------
    using EventCallback = std::function<void(const std::string& type,
                                              const std::string& data)>;
    void OnEvent(const std::string& event_type, EventCallback callback);
    void RemoveCallback(const std::string& event_type);

private:
    TerraCore();
    ~TerraCore();

    // Core systems
    AgentBus                m_bus;
    WorldState              m_world_state;
    std::atomic<CoreStatus> m_status;
    std::atomic<bool>       m_paused{false};

    // Registered agents (owned by TerraCore)
    std::vector<std::unique_ptr<AgentBase>> m_agents;

    // Event routing table — maps event type to agent names
    std::map<std::string, std::vector<std::string>> m_event_routes;

    // C++ event callbacks
    mutable std::mutex                           m_callback_mutex;
    std::map<std::string, EventCallback>         m_callbacks;

    // Stats
    mutable std::mutex m_stats_mutex;
    Stats              m_stats;

    // Init helpers
    bool CreateAgents();
    bool RegisterAgents();
    void BuildEventRoutes();
    void FireCallbacks(const std::string& type, const std::string& data);
    void UpdateStats(double tick_ms);

    static const char* MOD;
};

// ============================================================
// CONVENIENCE MACRO
// Use TERRA.FireEvent("event", "data") anywhere in game code
// ============================================================
#define TERRA TerraCore::Get()

} // namespace TerraEngine

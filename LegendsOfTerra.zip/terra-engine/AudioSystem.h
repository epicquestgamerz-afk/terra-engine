// ============================================================
// TERRA ENGINE — AUDIO SYSTEM
// AudioSystem.h — Version 1.0.0
// ============================================================
// Uses miniaudio (single header, MIT license, zero deps).
// Features: 3D spatial audio, music streaming, dynamic
//           music layers, bus mixing per island.
// Terra: Reign of the Forgotten Gods audio zones:
//   - Safe zones: calm ambient + ambient music
//   - Conflict zones: tense underscore
//   - God zones: full epic boss theme
//   - Corruption zones: dark reversed ambience
// ============================================================
#pragma once
#include "AIConnector.h"
#include "Config.h"
#include <string>
#include <map>
#include <vector>
#include <memory>
#include <mutex>
#include <functional>
#include <atomic>

namespace TerraEngine {

// ============================================================
// SOUND HANDLE — safe reference to a playing sound
// ============================================================
struct SoundHandle {
    uint32_t id      = 0;
    bool     valid   = false;
    operator bool()  const { return valid; }
};

// ============================================================
// AUDIO BUS — mixing group
// ============================================================
enum class AudioBus {
    MASTER,
    MUSIC,
    SFX,
    VOICE,
    AMBIENT,
    UI
};

// ============================================================
// SOUND ASSET
// ============================================================
struct SoundAsset {
    std::string  path;
    bool         is_streaming = false; // true for music
    bool         loop         = false;
    float        base_volume  = 1.0f;
    AudioBus     bus          = AudioBus::SFX;
};

// ============================================================
// MUSIC LAYER — one instrument/intensity layer in dynamic music
// ============================================================
struct MusicLayer {
    std::string name;
    std::string filepath;
    float       volume       = 0.0f;     // current fade target
    float       target_volume= 0.0f;
    bool        active       = false;
};

// ============================================================
// AUDIO SYSTEM
// ============================================================
class AudioSystem {
public:
    static AudioSystem& Get() {
        static AudioSystem instance;
        return instance;
    }

    // --------------------------------------------------------
    // Init / Shutdown
    // --------------------------------------------------------
    bool Init();
    void Shutdown();
    void Update(float delta_time);  // call each frame for fades

    // --------------------------------------------------------
    // SFX
    // --------------------------------------------------------
    SoundHandle PlaySFX    (const std::string& path,
                            float volume  = 1.0f,
                            float pitch   = 1.0f,
                            bool  loop    = false);

    SoundHandle PlaySFX3D  (const std::string& path,
                            float x, float y, float z,
                            float volume      = 1.0f,
                            float max_distance= 50.0f,
                            bool  loop        = false);

    void Stop   (SoundHandle handle, float fade_out = 0.0f);
    void StopAll(AudioBus bus = AudioBus::MASTER);

    // Modify playing sound
    void SetVolume(SoundHandle handle, float volume, float fade_time = 0.0f);
    void SetPitch (SoundHandle handle, float pitch);
    void SetPos3D (SoundHandle handle, float x, float y, float z);

    bool IsPlaying(SoundHandle handle) const;

    // --------------------------------------------------------
    // Music — dynamic layered system
    // --------------------------------------------------------
    void LoadMusicBed    (const std::string& id, const std::string& path);
    void AddMusicLayer   (const std::string& bed_id, const MusicLayer& layer);

    void PlayMusic       (const std::string& bed_id, float fade_in = 2.0f);
    void StopMusic       (float fade_out = 2.0f);
    void TransitionMusic (const std::string& new_bed_id, float crossfade = 3.0f);

    // Dynamic intensity — drives which layers are audible
    void SetMusicIntensity(float intensity, float blend_time = 1.0f);
    float GetMusicIntensity() const { return m_music_intensity; }

    // Terra-specific music zones
    void OnEnterSafeZone   (int island);
    void OnEnterConflict   (int island);
    void OnEnterGodZone    (int island);
    void OnBossFightStart  (const std::string& god_id);
    void OnBossFightEnd    ();
    void OnCorruptionRise  (float level);  // increases dark layers
    void OnNightFall       ();
    void OnDawn            ();

    // --------------------------------------------------------
    // Listener (camera/player position for 3D audio)
    // --------------------------------------------------------
    void SetListenerPos(float x, float y, float z);
    void SetListenerDir(float dx, float dy, float dz);
    void SetListenerUp (float ux, float uy, float uz);

    // --------------------------------------------------------
    // Bus volumes
    // --------------------------------------------------------
    void SetBusVolume(AudioBus bus, float volume, float fade = 0.0f);
    float GetBusVolume(AudioBus bus) const;

    // --------------------------------------------------------
    // Asset preloading
    // --------------------------------------------------------
    void Preload(const std::string& path);
    void Unload (const std::string& path);

    bool IsReady() const { return m_initialized.load(); }

private:
    AudioSystem() : m_initialized(false), m_music_intensity(0.0f) {}

    std::atomic<bool> m_initialized;

    // Bus volumes
    float m_bus_volumes[6] = {1.0f, 0.8f, 1.0f, 1.0f, 0.6f, 1.0f};
    float m_bus_targets [6] = {1.0f, 0.8f, 1.0f, 1.0f, 0.6f, 1.0f};

    // Playing sounds
    struct PlayingSound {
        uint32_t    id;
        std::string path;
        float       volume;
        float       target_volume;
        float       fade_speed;  // volume/sec
        bool        is_3d;
        float       pos[3];
        float       max_dist;
        AudioBus    bus;
        bool        active;
    };
    std::map<uint32_t, PlayingSound> m_sounds;
    uint32_t m_next_id = 1;

    // Music beds
    struct MusicBed {
        std::string              id;
        std::string              base_path;
        std::vector<MusicLayer>  layers;
        bool                     active = false;
    };
    std::map<std::string, MusicBed> m_music_beds;
    std::string  m_current_bed;
    float        m_music_intensity;
    float        m_music_fade_speed = 0.5f;

    // Listener
    float m_listener_pos[3] = {0,0,0};
    float m_listener_dir[3] = {0,0,1};
    float m_listener_up [3] = {0,1,0};

    mutable std::mutex m_mutex;

    // 3D attenuation
    float Attenuate3D(const float* sound_pos, float max_dist) const;

    void UpdateFades(float dt);
    void UpdateMusicLayers(float dt);

    static const char* MOD;
};

#define AUDIO AudioSystem::Get()

} // namespace TerraEngine

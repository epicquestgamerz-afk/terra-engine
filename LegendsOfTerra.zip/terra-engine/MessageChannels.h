// ============================================================
// TERRA ENGINE — MESSAGE CHANNELS
// MessageChannels.h — Version 1.0.0
// ============================================================
// AUDIT FIX 1: Replaces single AgentBus bottleneck
// with distributed lock-free message channels.
// Each domain has its own channel — zero global contention.
// ============================================================

#pragma once

#include "AgentBase.h"
#include <array>
#include <atomic>
#include <functional>
#include <string>
#include <vector>
#include <mutex>
#include <map>
#include <cstring>   // FIX: strncpy needs this

namespace TerraEngine {

// ============================================================
// CHANNEL TYPES — one per domain
// AUDIT FIX: replaces single AgentBus with domain channels
// ============================================================
enum class Channel {
    COMBAT,       // combat_start, combat_end, player_low_health
    AI,           // npc decisions, boss strategy, creature AI
    WEATHER,      // storm, rain, night_fall, day_break
    WORLD_STATE,  // island_enter, corruption_spread, fragment
    NPC,          // npc_hungry, village_attack, job_change
    PHYSICS,      // collision events, water flow, terrain change
    COUNT         // always last — used for array sizing
};

static constexpr int CHANNEL_COUNT = static_cast<int>(Channel::COUNT);

// ============================================================
// FRAME EVENT BUFFER
// AUDIT FIX 3: replaces unbounded priority_queue
// Double-buffered — current frame reads, next frame writes
// Zero unbounded growth. Zero lock contention between frames.
// ============================================================
template<typename T, size_t Capacity = 1024>
class FrameEventBuffer {
public:
    FrameEventBuffer() : m_write_idx(0), m_read_idx(0) {}

    // Write to next frame buffer — called by senders
    bool Push(const T& event) {
        size_t idx = m_write_idx.fetch_add(1, std::memory_order_relaxed);
        if (idx >= Capacity) {
            m_write_idx.store(Capacity, std::memory_order_relaxed);
            return false; // buffer full — backpressure applied
        }
        m_next[idx] = event;
        return true;
    }

    // Swap buffers — called once per frame by SimulationManager
    void Swap() {
        std::lock_guard<std::mutex> lock(m_swap_mutex);
        m_current     = m_next;
        m_read_count  = m_write_idx.load(std::memory_order_acquire);
        m_write_idx.store(0, std::memory_order_release);
        // Clear next buffer
        for (size_t i = 0; i < m_read_count; i++) m_next[i] = T{};
    }

    // Iterate current frame events — called by consumers
    void ForEach(std::function<void(const T&)> fn) const {
        for (size_t i = 0; i < m_read_count; i++) fn(m_current[i]);
    }

    size_t Count()     const { return m_read_count; }
    bool   IsEmpty()   const { return m_read_count == 0; }
    bool   IsFull()    const { return m_write_idx.load() >= Capacity; }

private:
    std::array<T, Capacity> m_current;
    std::array<T, Capacity> m_next;
    std::atomic<size_t>     m_write_idx;
    size_t                  m_read_count = 0;
    std::mutex              m_swap_mutex;
};

// ============================================================
// CHANNEL MESSAGE — lightweight, no heap allocation
// ============================================================
struct ChannelMessage {
    char        type[32]    = {};   // event type string
    char        data[128]   = {};   // payload
    char        from[32]    = {};   // sender
    int         priority    = 5;
    uint64_t    frame_id    = 0;
    float       timestamp   = 0.0f;

    ChannelMessage() = default;
    ChannelMessage(const char* t, const char* d,
                   const char* f, int p = 5) {
        strncpy(type,  t, 31);
        strncpy(data,  d, 127);
        strncpy(from,  f, 31);
        priority = p;
    }
};

// ============================================================
// MESSAGE ROUTER
// AUDIT FIX 1: Replaces monolithic AgentBus
// Routes messages to correct channel based on type
// Each channel processed independently — no global lock
// ============================================================
class MessageRouter {
public:
    static MessageRouter& Get() {
        static MessageRouter instance;
        return instance;
    }

    // Post a message to the correct channel
    bool Post(Channel channel, const ChannelMessage& msg);

    // Post by event type — auto-routes to correct channel
    bool Post(const std::string& event_type,
              const std::string& data,
              const std::string& from_agent,
              int priority = 5);

    // Subscribe to a channel
    using ChannelHandler = std::function<void(const ChannelMessage&)>;
    void Subscribe(Channel channel,
                   const std::string& subscriber_name,
                   ChannelHandler handler);

    void Unsubscribe(Channel channel,
                     const std::string& subscriber_name);

    // Called once per frame — swaps buffers and dispatches
    void Tick(uint64_t frame_id);

    // Direct route — bypasses buffer for CRITICAL messages
    void PostImmediate(Channel channel, const ChannelMessage& msg);

    // Stats
    struct Stats {
        uint64_t total_posted    = 0;
        uint64_t total_dropped   = 0;
        uint64_t total_delivered = 0;
        std::array<uint64_t, CHANNEL_COUNT> per_channel = {};
    };
    Stats GetStats() const;
    void  PrintStats() const;

private:
    MessageRouter();

    // One frame buffer per channel — no shared lock
    std::array<FrameEventBuffer<ChannelMessage, 512>, CHANNEL_COUNT> m_buffers;

    // Subscribers per channel
    struct Subscriber {
        std::string    name;
        ChannelHandler handler;
    };
    mutable std::mutex                               m_sub_mutex;
    std::array<std::vector<Subscriber>, CHANNEL_COUNT> m_subscribers;

    // Event type to channel mapping
    std::map<std::string, Channel> m_event_channel_map;

    mutable std::mutex m_stats_mutex;
    Stats              m_stats;

    void BuildEventChannelMap();
    void DispatchChannel(Channel ch, uint64_t frame_id);
    Channel GetChannelForEvent(const std::string& event_type) const;

    static const char* MOD;
};

// ============================================================
// SIMULATION TICK SYSTEM
// AUDIT FIX 5: deterministic tick order
// Replaces ad-hoc per-agent ticking
// ============================================================
class SimulationManager {
public:
    static SimulationManager& Get() {
        static SimulationManager instance;
        return instance;
    }

    // Register a system with its tick frequency
    struct SystemEntry {
        std::string                    name;
        std::function<void(float)>     tick_fn;
        float                          tick_rate_hz; // 0 = every frame
        float                          accumulator  = 0.0f;
        int                            priority     = 5; // lower = earlier
    };

    void RegisterSystem(const std::string& name,
                        std::function<void(float)> fn,
                        float tick_rate_hz = 0.0f,
                        int priority = 5);

    void UnregisterSystem(const std::string& name);

    // Call this once per frame with real delta time
    // Internally handles fixed-rate systems
    void Tick(float delta_time);

    uint64_t GetFrameId() const { return m_frame_id.load(); }
    float    GetSimTime() const { return m_sim_time; }

private:
    SimulationManager();

    std::vector<SystemEntry>       m_systems;
    mutable std::mutex             m_systems_mutex;
    std::atomic<uint64_t>          m_frame_id;
    float                          m_sim_time = 0.0f;

    static const char* MOD;
};

// ============================================================
// SPATIAL GRID
// AUDIT FIX 6: spatial partitioning
// Agents only interact with nearby agents — no global scan
// ============================================================
struct GridCell {
    int   x = 0;
    int   y = 0;
    float world_x = 0.0f;
    float world_z = 0.0f;
};

class SpatialGrid {
public:
    static constexpr int   CELL_SIZE  = 50;  // 50 world units per cell
    static constexpr int   GRID_WIDTH = 100; // 100x100 grid per island

    SpatialGrid();

    // Register an entity at a world position
    void Register  (const std::string& entity_id, float x, float z);
    void Unregister(const std::string& entity_id);
    void Move      (const std::string& entity_id, float x, float z);

    // Get all entities within radius
    std::vector<std::string> GetNearby(float x, float z, float radius) const;

    // Get cell for a position
    GridCell GetCell(float x, float z) const;

    // Check if two entities are in same or adjacent cell
    bool AreNearby(const std::string& a, const std::string& b) const;

private:
    struct EntityPos {
        float x = 0.0f;
        float z = 0.0f;
        int   cell_x = 0;
        int   cell_z = 0;
    };

    mutable std::mutex                              m_mutex;
    std::map<std::string, EntityPos>               m_entities;
    std::map<int, std::vector<std::string>>        m_cells; // cell_key -> entity_ids

    int  CellKey(int cx, int cz) const { return cx * 10000 + cz; }
    void RemoveFromCell(const std::string& id, int cx, int cz);
    void AddToCell    (const std::string& id, int cx, int cz);

    static const char* MOD;
};

// ============================================================
// WORLD SEED SYSTEM
// Answers the user's question:
// "How does AI make new world every time?"
// ANSWER: Islands are FIXED. Only content varies per seed.
// ============================================================
struct IslandTemplate {
    int         island_id   = 0;
    std::string name;
    std::string biome;
    float       size        = 1000.0f; // world units
    int         region_count = 4;
    int         boss_count  = 1;

    // Fixed layout anchors — never change
    struct Anchor {
        std::string type; // "village", "boss_arena", "bridge_north" etc
        float       x, z;
    };
    std::vector<Anchor> anchors;
};

class WorldSeedSystem {
public:
    static WorldSeedSystem& Get() {
        static WorldSeedSystem instance;
        return instance;
    }

    // Set seed for this playthrough
    void SetSeed(uint64_t seed);
    uint64_t GetSeed() const { return m_seed; }

    // Get island template — FIXED layout, never AI-generated
    const IslandTemplate& GetIslandTemplate(int island_id) const;

    // Generate CONTENT variation for island using seed
    // This is what AI generates — NPC names, quest variants, enemy types
    // NOT the island layout
    struct IslandContent {
        std::vector<std::string> npc_name_pool;
        std::vector<std::string> quest_variants;
        std::string              boss_variant;   // "frost" / "corrupted" / "ancient"
        std::string              weather_tendency; // "stormy" / "clear" / "foggy"
        float                    corruption_start = 0.0f;
        std::map<std::string, float> resource_multipliers;
    };

    IslandContent GenerateIslandContent(int island_id) const;

    // Save / load world state
    bool SaveWorldState(const std::string& filepath) const;
    bool LoadWorldState(const std::string& filepath);

    struct WorldState {
        uint64_t                         seed         = 0;
        int                              current_island = 1;
        float                            corruption    = 0.0f;
        int                              fragments_found = 0;
        std::map<int, bool>              islands_visited;
        std::map<int, bool>              bosses_defeated;
        std::map<std::string, std::string> npc_states;
        std::map<std::string, float>     island_corruption;
        float                            game_time    = 0.0f;
    };

    WorldState&       GetWorldState()       { return m_world_state; }
    const WorldState& GetWorldState() const { return m_world_state; }

private:
    WorldSeedSystem();

    uint64_t                          m_seed = 0;
    WorldState                        m_world_state;
    std::vector<IslandTemplate>       m_island_templates;

    void BuildIslandTemplates();

    static const char* MOD;
};

// ============================================================
// CONVENIENCE MACROS
// ============================================================
#define ROUTER  MessageRouter::Get()
#define SIMSYS  SimulationManager::Get()
#define GRID    SpatialGrid::Get()  // Note: one grid per island in practice
#define WSEED   WorldSeedSystem::Get()

} // namespace TerraEngine

// ============================================================
// TERRA ENGINE — CONFIG SYSTEM
// Config.h — Version 1.0.0
// ============================================================
// BUG 8 FIX: Central config — no hardcoded paths anywhere.
// All paths are relative to executable or user data directory.
// Loads from terra.cfg on startup, saves on exit.
// Provides typed getters for all settings.
// ============================================================
#pragma once
#include "AIConnector.h"
#include <string>
#include <map>
#include <mutex>
#include <functional>

namespace TerraEngine {

class Config {
public:
    static Config& Get() { static Config i; return i; }

    bool Load(const std::string& path = "terra.cfg");
    bool Save(const std::string& path = "terra.cfg") const;
    void SetDefaults();

    // ── Typed getters with fallback ──
    std::string GetString(const std::string& key, const std::string& fallback = "") const;
    int         GetInt   (const std::string& key, int   fallback = 0)    const;
    float       GetFloat (const std::string& key, float fallback = 0.0f) const;
    bool        GetBool  (const std::string& key, bool  fallback = false) const;

    void Set(const std::string& key, const std::string& value);
    void Set(const std::string& key, int   value);
    void Set(const std::string& key, float value);
    void Set(const std::string& key, bool  value);

    // ── Path helpers — BUG 8 FIX: all paths relative ──
    std::string ShaderDir()    const { return GetString("paths.shaders",    "renderer/shaders/"); }
    std::string AssetDir()     const { return GetString("paths.assets",     "assets/"); }
    std::string SaveDir()      const { return GetString("paths.saves",      "saves/"); }
    std::string AudioDir()     const { return GetString("paths.audio",      "assets/audio/"); }
    std::string ModelDir()     const { return GetString("paths.models",     "assets/models/"); }
    std::string TextureDir()   const { return GetString("paths.textures",   "assets/textures/"); }
    std::string DataDir()      const { return GetString("paths.data",       "data/"); }
    std::string LogFile()      const { return GetString("paths.log",        "terra.log"); }
    std::string EnvFile()      const { return GetString("paths.env",        ".env"); }

    // ── Graphics ──
    int   ResolutionW()    const { return GetInt  ("gfx.width",     1920); }
    int   ResolutionH()    const { return GetInt  ("gfx.height",    1080); }
    int   QualityTier()    const { return GetInt  ("gfx.quality",   1);    } // 0=med 1=high 2=ultra
    bool  VSync()          const { return GetBool ("gfx.vsync",     true); }
    float RenderScale()    const { return GetFloat("gfx.render_scale", 1.0f); }
    bool  Fullscreen()     const { return GetBool ("gfx.fullscreen", false); }

    // ── Audio ──
    float MasterVolume()   const { return GetFloat("audio.master",  1.0f); }
    float MusicVolume()    const { return GetFloat("audio.music",   0.8f); }
    float SFXVolume()      const { return GetFloat("audio.sfx",     1.0f); }
    float VoiceVolume()    const { return GetFloat("audio.voice",   1.0f); }

    // ── Gameplay ──
    float MouseSensitivity()const { return GetFloat("input.mouse_sens", 0.3f); }
    bool  InvertY()         const { return GetBool ("input.invert_y",  false); }
    std::string Language()  const { return GetString("game.language",  "en"); }

    // ── Engine ──
    bool  DebugMode()       const { return GetBool ("engine.debug",    false); }
    int   MaxFPS()          const { return GetInt  ("engine.max_fps",  60);   }
    int   PhysicsHz()       const { return GetInt  ("engine.physics_hz", 60); }
    int   AIHz()            const { return GetInt  ("engine.ai_hz",    20);   }

    // Change callback — UI can react when setting changes
    using ChangeCB = std::function<void(const std::string& key)>;
    void OnChange(ChangeCB cb) { m_change_cb = cb; }

private:
    Config() { SetDefaults(); }
    mutable std::mutex              m_mutex;
    std::map<std::string,std::string> m_data;
    ChangeCB                        m_change_cb;
    static const char*              MOD;
};

#define TCONFIG Config::Get()

} // namespace TerraEngine

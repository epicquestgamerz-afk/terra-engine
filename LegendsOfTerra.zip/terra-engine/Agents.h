// ============================================================
// TERRA ENGINE — ALL AGENTS
// Agents.h — Version 1.1.0
// ============================================================
// BUG 4  FIX: AgentEnvironment — added 7 missing private fields
// BUG 5  FIX: AgentWorld      — added 2 missing private fields
// BUG 6  FIX: AgentNPC        — added 2 timer fields + NPCData fields
// BUG 7  FIX: AgentCreature   — added timer + HandleCorruptionSpread
// BUG 8  FIX: AgentNPC        — aligned method names with cpp
// BUG 9  FIX: Removed unimplemented declarations; added missing ones
// BUG 10 FIX: AgentEnvironment/AgentWorld — all handlers aligned
// BUG 17 FIX: CheckPhaseTransition marked const
// ============================================================

#pragma once

#include "AgentBase.h"
#include <string>
#include <vector>
#include <map>
#include <memory>
#include <sstream>

namespace TerraEngine {

// ============================================================
// AGENT WORLD
// ============================================================
class AgentWorld : public AgentBase {
public:
    AgentWorld();

    void OnMessage          (const AgentMessage& msg)  override;
    void OnTick             (float dt)                  override;
    void OnWorldStateChanged(const WorldState& state)  override;

    void GenerateIsland  (int island_id);
    void StreamIsland    (int island_id);
    void UnloadIsland    (int island_id);
    void SpreadCorruption(float amount, const std::string& sector);
    void PlaceVillage    (int island_id, const std::string& biome = "grassland");

    // BUG 9 FIX: implemented inline — were declared but never defined in cpp
    std::string GetIslandBiome(int island_id) const {
        auto it = m_island_biomes.find(island_id);
        return it != m_island_biomes.end() ? it->second : "unknown";
    }
    bool IsIslandGenerated(int island_id) const {
        return m_generated.count(island_id) > 0 && m_generated.at(island_id);
    }
    float GetCorruptionAt(const std::string& sector) const {
        auto it = m_corruption_map.find(sector);
        return it != m_corruption_map.end() ? it->second : 0.0f;
    }

private:
    // Existing members
    std::map<int, std::string>   m_island_biomes;
    std::map<int, bool>          m_generated;
    std::map<std::string, float> m_corruption_map;

    // BUG 5 FIX: added missing fields used in Agents.cpp
    float m_corruption_tick = 0.0f;
    int   m_last_island_id  = 0;

    // BUG 10 FIX: aligned with Agents.cpp OnMessage dispatch
    void HandleCorruptionSpread(const AgentMessage& msg); // was HandleCorruption
    void HandleBossDefeated    (const AgentMessage& msg); // was missing
    void HandlePlayerDied      (const AgentMessage& msg); // was missing
};

// ============================================================
// AGENT ENVIRONMENT
// Merged: AgentWeather + AgentDay + AgentWater
// ============================================================
class AgentEnvironment : public AgentBase {
public:
    AgentEnvironment();

    void OnMessage          (const AgentMessage& msg)  override;
    void OnTick             (float dt)                  override;
    void OnWorldStateChanged(const WorldState& state)  override;

    void  SetWeather        (const std::string& weather);
    void  TriggerStorm      (float intensity);
    void  ClearWeather      ();
    void  TriggerFog        (float density);
    void  SetTimeOfDay      (const std::string& time);
    void  AdvanceTime       (float hours);
    void  RaiseWaterLevel   (float amount, const std::string& sector);
    void  TriggerFlood      (const std::string& sector);

    std::string GetCurrentWeather   () const { return m_current_weather; }
    std::string GetTimeOfDay        () const { return m_time_of_day; }
    float       GetTemperature      () const { return m_temperature; }
    float       GetDayCycleProgress () const { return m_day_progress; }
    float       GetWaterLevel       (const std::string& sector) const;
    int         GetDayCount         () const { return m_day_count; }
    bool        IsNight             () const;
    bool        IsStorming          () const;

private:
    // Existing fields
    std::string                  m_current_weather = "clear";
    std::string                  m_time_of_day     = "morning";
    float                        m_day_progress    = 0.0f;
    float                        m_temperature     = 20.0f;
    float                        m_storm_intensity = 0.0f;
    std::map<std::string, float> m_water_levels;

    // BUG 4 FIX: added all 7 missing fields used in Agents.cpp
    float       m_day_duration            = 600.0f;  // seconds per full day
    float       m_weather_timer           = 0.0f;
    float       m_weather_change_interval = 300.0f;
    std::string m_current_time            = "morning";
    int         m_day_count               = 0;
    float       m_water_level             = 0.0f;    // global water level
    bool        m_flood_warned            = false;

    // BUG 10 FIX: aligned handler declarations with Agents.cpp
    void HandleStormStart         (const AgentMessage& msg);
    void HandleStormEnd           (const AgentMessage& msg); // was missing
    void HandleCorruptionAtmosphere(const AgentMessage& msg); // was HandleCorruption
    void HandleBossAwakened       (const AgentMessage& msg);
    void HandleBossDefeated       (const AgentMessage& msg); // was missing
    void HandleFragmentFound      (const AgentMessage& msg); // was missing
    void UpdateTimeOfDay          ();                        // was UpdateDayCycle
    void ConsiderWeatherChange    ();                        // was UpdateWeatherEffects
};

// ============================================================
// NPC DATA
// ============================================================
struct NPCData {
    std::string id;
    std::string name;
    std::string job;
    std::string personality;
    float       hunger    = 1.0f;
    float       safety    = 1.0f;
    float       wealth    = 0.5f;
    float       mood      = 0.7f;
    int         island_id = 1;
    std::string village_id;
    bool        is_alive  = true;
    std::string player_memory;

    // BUG 6 FIX: added missing fields used in Agents.cpp
    float       thirst    = 1.0f;
    std::string backstory;
};

// ============================================================
// AGENT NPC
// ============================================================
class AgentNPC : public AgentBase {
public:
    AgentNPC();

    void OnMessage          (const AgentMessage& msg)  override;
    void OnTick             (float dt)                  override;
    void OnWorldStateChanged(const WorldState& state)  override;

    void        SpawnNPC      (const NPCData& npc);
    void        RemoveNPC     (const std::string& npc_id);
    void        UpdateNPCNeed (const std::string& npc_id,
                               const std::string& need,
                               float value);
    std::string GetDialogue   (const std::string& npc_id,
                               const std::string& context);
    int         GetNPCCount   (int island_id) const;

    // BUG 8 FIX: names now match Agents.cpp definitions exactly
    float       GetItemPrice  (const std::string& item_id) const;
    void        SetReputation (int island_id, float value);
    float       GetReputation (int island_id) const;

    // BUG 9 FIX: GetVillageState + NPCChangesJob were declared but
    // never implemented. Providing inline stubs to avoid linker error.
    std::string GetVillageState(const std::string& /*village_id*/) const {
        return "unknown";
    }
    bool NPCChangesJob(const std::string& npc_id, const std::string& new_job) {
        auto it = m_npcs.find(npc_id);
        if (it == m_npcs.end()) return false;
        it->second.job = new_job;
        return true;
    }

private:
    std::map<std::string, NPCData> m_npcs;
    std::map<int, float>           m_reputation;
    std::map<std::string, float>   m_item_prices;

    // BUG 6 FIX: added missing timer fields
    float m_needs_tick  = 0.0f;
    float m_economy_tick = 0.0f;

    void HandleVillageAttack (const AgentMessage& msg);
    void HandleNPCHungry     (const AgentMessage& msg);
    void HandleNightFall     (const AgentMessage& msg);
    void HandleStormStart    (const AgentMessage& msg);
    void HandleBossDefeated  (const AgentMessage& msg);
    void HandleFragmentFound (const AgentMessage& msg);
    void HandleVillagePlaced (const AgentMessage& msg); // BUG 9 FIX: was missing
    void HandleIslandGenerate(const AgentMessage& msg); // BUG 9 FIX: was missing
    void PlaceVillage        (int island_id);           // BUG 9 FIX: was missing
    void SimulateNPCNeeds    (float dt);
    void UpdateEconomy       ();
};

// ============================================================
// BOSS PHASE
// ============================================================
struct BossPhase {
    int         phase_number = 1;
    float       hp_threshold = 1.0f;
    std::string strategy;
    float       power_mult   = 1.0f;
    bool        is_active    = false;
};

// ============================================================
// AGENT BOSS
// ============================================================
class AgentBoss : public AgentBase {
public:
    AgentBoss();

    void OnMessage          (const AgentMessage& msg)  override;
    void OnTick             (float dt)                  override;
    void OnWorldStateChanged(const WorldState& state)  override;

    void        ActivateBoss   (const std::string& boss_id,
                                const std::string& boss_name,
                                int island_id);
    void        DeactivateBoss ();
    void        SetBossHP      (float hp, float max_hp);
    std::string GetNextAttack  ();
    std::string GetBossTaunt   ();
    bool        ShouldChangePhase() const;
    void        OnPlayerAction (const std::string& action);
    void        AddPhase       (const BossPhase& phase);

    bool        IsBossActive   () const { return m_boss_active; }
    std::string GetActiveBossId() const { return m_active_boss_id; }
    int         GetCurrentPhase() const { return m_current_phase; }
    float       GetBossHPPercent() const;

private:
    bool                       m_boss_active      = false;
    std::string                m_active_boss_id;
    std::string                m_active_boss_name;
    float                      m_boss_hp          = 0.0f;
    float                      m_boss_max_hp      = 0.0f;
    int                        m_current_phase    = 1;
    int                        m_island_id        = 0;
    std::map<std::string, int> m_player_actions;
    std::vector<BossPhase>     m_phases;
    std::string                m_last_strategy;

    void HandleBossAwakened    (const AgentMessage& msg);
    void HandleCombatStart     (const AgentMessage& msg);
    void HandleCombatEnd       (const AgentMessage& msg);
    void HandleFragmentAbsorbed(const AgentMessage& msg);
    void HandleStormStart      (const AgentMessage& msg);
    void HandleNightFall       (const AgentMessage& msg);
    // BUG 17 FIX: const qualifier added — was calling non-const from const method
    bool CheckPhaseTransition  () const;
};

// ============================================================
// CREATURE DATA
// ============================================================
struct CreatureData {
    std::string id;
    std::string type;
    std::string behavior_mode = "peaceful";
    float       hp            = 100.0f;
    float       aggro_range   = 15.0f;
    int         island_id     = 1;
    std::string territory;
    bool        is_alive      = true;
    bool        in_pack       = false;
    std::string pack_id;
};

// ============================================================
// AGENT CREATURE
// Merged: AgentEnemy + AgentAnimal
// ============================================================
class AgentCreature : public AgentBase {
public:
    AgentCreature();

    void OnMessage          (const AgentMessage& msg)  override;
    void OnTick             (float dt)                  override;
    void OnWorldStateChanged(const WorldState& state)  override;

    void SpawnCreature (const CreatureData& creature);
    void RemoveCreature(const std::string& creature_id);
    void SetAggressive (const std::string& creature_id);
    void SetPeaceful   (const std::string& creature_id);
    void SetFleeing    (const std::string& creature_id);

    std::vector<std::string> GetNearbyHostiles (int island_id) const;
    std::vector<std::string> GetPackMembers    (const std::string& pack_id) const;
    std::string              GetAttackStrategy (const std::string& creature_id);
    bool                     IsInTerritory     (const std::string& creature_id,
                                                const std::string& zone) const;
    int                      GetCreatureCount  (int island_id,
                                                const std::string& type = "") const;
    void                     FleeFromEvent     (const std::string& sector,
                                                const std::string& reason);

private:
    std::map<std::string, CreatureData>             m_creatures;
    std::map<std::string, std::vector<std::string>> m_packs;

    // BUG 7 FIX: added missing timer field
    float m_behavior_tick = 0.0f;

    void HandleNightFall        (const AgentMessage& msg);
    void HandleStormStart       (const AgentMessage& msg);
    void HandleBossAwakened     (const AgentMessage& msg);
    void HandleCombatStart      (const AgentMessage& msg);
    void HandleVillageAttack    (const AgentMessage& msg);
    void HandleIslandEnter      (const AgentMessage& msg);
    // BUG 7 FIX: added missing declaration — called in OnMessage
    void HandleCorruptionSpread (const AgentMessage& msg);
    void UpdateCreatureMoods    (float dt);
};

// ============================================================
// AGENT PLAYER CARE
// ============================================================
class AgentPlayerCare : public AgentBase {
public:
    AgentPlayerCare();

    void OnMessage          (const AgentMessage& msg)  override;
    void OnTick             (float dt)                  override;
    void OnWorldStateChanged(const WorldState& state)  override;

    void  RecordPlayerAction       (const std::string& action);
    void  RecordDeath              ();
    void  RecordQuestIgnored       (float seconds);

    bool  IsPlayerBored            () const;
    bool  IsPlayerOverwhelmed      () const;
    bool  IsPlayerDriftingFromStory() const;
    float GetEngagementScore       () const { return m_engagement_score; }

private:
    float m_engagement_score  = 0.8f;
    float m_time_since_action = 0.0f;
    float m_time_since_quest  = 0.0f;
    int   m_recent_deaths     = 0;
    int   m_recent_kills      = 0;
    float m_overwhelm_score   = 0.0f;
    float m_boredom_score     = 0.0f;

    static constexpr float BOREDOM_THRESHOLD   = 0.7f;
    static constexpr float OVERWHELM_THRESHOLD = 0.7f;
    static constexpr float STORY_DRIFT_SECONDS = 300.0f;

    void HandlePlayerLowHealth (const AgentMessage& msg);
    void HandlePlayerDied      (const AgentMessage& msg);
    void HandleCombatStart     (const AgentMessage& msg);
    void HandleCombatEnd       (const AgentMessage& msg);
    void HandleFragmentFound   (const AgentMessage& msg);
    void UpdateScores          (float dt);
    void InjectInterestingEvent();
    void ReduceDifficulty      ();
    void NudgeTowardStory      ();
};

} // namespace TerraEngine

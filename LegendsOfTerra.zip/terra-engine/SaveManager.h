// ============================================================
// TERRA ENGINE — SAVE MANAGER
// SaveManager.h — Version 1.0.0
// ============================================================
// Lives in Terra Engine — coordinates all save operations.
// Local cache for speed. Supabase cloud for persistence.
// Works offline — queues syncs until internet returns.
// One account = same game on any device, any IP.
// ============================================================

#pragma once

#include "AIConnector.h"
#include "MessageChannels.h"
#include <string>
#include <vector>
#include <map>
#include <queue>
#include <mutex>
#include <atomic>
#include <functional>
#include <chrono>
#include <memory>
#include <fstream>

namespace TerraEngine {

// ============================================================
// SAVE DATA STRUCTURES
// ============================================================

struct PlayerAccount {
    std::string player_id;
    std::string username;
    std::string email;
    std::string jwt_token;       // auth token — stored locally
    bool        is_logged_in  = false;
    bool        is_guest      = false;
};

struct InventoryItem {
    std::string item_id;
    int         quantity    = 1;
    int         slot        = -1;  // -1 = not in hotbar
    bool        is_equipped = false;
    std::string metadata;          // JSON extras e.g. durability
};

struct CosmeticItem {
    std::string cosmetic_id;
    bool        is_equipped = false;
    std::string acquired_at;
};

struct WorldChange {
    std::string change_type;  // "building_placed" "npc_died" "corruption"
    int         island_id   = 1;
    std::string data;         // JSON payload
    uint64_t    timestamp   = 0;
};

struct GameSaveData {
    // Identity
    std::string player_id;
    uint64_t    world_seed          = 0;
    int         save_slot           = 1;

    // Progress
    int         current_island      = 1;
    float       game_time           = 0.0f;
    int         fragments_found     = 0;
    float       corruption_level    = 0.0f;

    // Player stats
    int         player_level        = 1;
    float       player_xp           = 0.0f;
    float       player_health       = 100.0f;
    float       player_max_health   = 100.0f;
    float       player_stamina      = 100.0f;
    bool        is_kael             = true;  // false = Sera

    // Story flags — key/value pairs
    std::map<std::string, bool>        story_flags;
    std::map<std::string, bool>        bosses_defeated;
    std::map<int, bool>                islands_visited;
    std::map<int, float>               island_corruption;

    // Collections
    std::vector<InventoryItem>         inventory;
    std::vector<CosmeticItem>          cosmetics;
    std::vector<WorldChange>           world_changes;

    // Economy
    int                                terra_coins     = 0;

    // Meta
    std::string                        last_saved;
    uint64_t                           save_version    = 1;
};

// ============================================================
// SYNC EVENT — queued when offline
// ============================================================
enum class SyncType {
    FULL_SAVE,
    ITEM_ADD,
    ITEM_REMOVE,
    ITEM_EQUIP,
    COSMETIC_EQUIP,
    COINS_UPDATE,
    WORLD_CHANGE,
    MILESTONE,
    BOSS_DEFEATED,
    FRAGMENT_FOUND,
    ISLAND_REACHED
};

struct SyncEvent {
    SyncType    type;
    std::string payload;        // JSON data
    uint64_t    timestamp;
    int         retry_count = 0;
};

// ============================================================
// SAVE RESULT
// ============================================================
struct SaveResult {
    bool        success     = false;
    std::string error;
    bool        was_offline = false;
    std::string save_id;
};

// ============================================================
// SAVE MANAGER
// ============================================================
class SaveManager {
public:
    static SaveManager& Get() {
        static SaveManager instance;
        return instance;
    }

    // --------------------------------------------------------
    // Init — call once at engine start
    // --------------------------------------------------------
    bool Init(const std::string& api_base_url,
              const std::string& supabase_url,
              const std::string& supabase_anon_key);

    // --------------------------------------------------------
    // Authentication
    // --------------------------------------------------------
    bool Login   (const std::string& username,
                  const std::string& password);
    bool Register(const std::string& username,
                  const std::string& email,
                  const std::string& password);
    void Logout  ();
    bool IsLoggedIn()    const { return m_account.is_logged_in; }
    bool IsGuest()       const { return m_account.is_guest; }
    bool IsOnline()      const { return m_online.load(); }

    const PlayerAccount& GetAccount() const { return m_account; }

    // Play as guest — local save only
    void LoginAsGuest(const std::string& guest_name = "");

    // --------------------------------------------------------
    // Save operations
    // --------------------------------------------------------

    // Full save — called every 60s + on important events
    SaveResult Save(const GameSaveData& data);

    // Quick save — just progress fields, fast
    SaveResult QuickSave(int island, int level,
                         float xp, int fragments);

    // Load — pulls from cloud on login, local cache otherwise
    bool Load(GameSaveData& out_data);

    // Force pull from cloud
    bool PullFromCloud(GameSaveData& out_data);

    // --------------------------------------------------------
    // Granular sync — called by game systems
    // Never blocks gameplay — async always
    // --------------------------------------------------------
    void SyncItemAdd    (const std::string& item_id, int qty,
                         const std::string& metadata = "");
    void SyncItemRemove (const std::string& item_id, int qty);
    void SyncItemEquip  (const std::string& item_id, bool equipped);
    void SyncCosmeticEquip(const std::string& cosmetic_id);
    void SyncCoinsUpdate(int new_balance);
    void SyncWorldChange(const WorldChange& change);
    void SyncMilestone  (const std::string& event_type,
                         const std::string& data);

    // --------------------------------------------------------
    // Offline queue
    // --------------------------------------------------------
    bool        HasQueuedEvents()  const;
    int         QueuedEventCount() const;
    void        FlushQueue();        // call when internet returns

    // --------------------------------------------------------
    // Local save (fallback / offline)
    // --------------------------------------------------------
    bool SaveLocal (const GameSaveData& data,
                    const std::string& filepath = "");
    bool LoadLocal (GameSaveData& out_data,
                    const std::string& filepath = "");

    // --------------------------------------------------------
    // Auto-save scheduler — call from SimulationManager
    // --------------------------------------------------------
    void Tick(float delta_time);     // checks auto-save timer
    void SetAutoSaveInterval(float seconds) { m_autosave_interval = seconds; }
    void SetCurrentSaveData(GameSaveData* data) { m_live_data = data; }

    // --------------------------------------------------------
    // Conflict resolution
    // --------------------------------------------------------
    GameSaveData ResolveConflict(const GameSaveData& local,
                                  const GameSaveData& cloud) const;

    // --------------------------------------------------------
    // Callbacks
    // --------------------------------------------------------
    using SaveCallback = std::function<void(const SaveResult&)>;
    void OnSaveComplete(SaveCallback cb) { m_on_save = cb; }
    void OnLoadComplete(std::function<void(const GameSaveData&)> cb) { m_on_load = cb; }
    void OnSyncFailed  (std::function<void(const std::string&)> cb) { m_on_fail = cb; }

    // --------------------------------------------------------
    // Stats
    // --------------------------------------------------------
    struct Stats {
        int     saves_completed  = 0;
        int     saves_failed     = 0;
        int     syncs_queued     = 0;
        int     syncs_flushed    = 0;
        float   last_save_time   = 0.0f;
        double  last_latency_ms  = 0.0;
    };
    Stats GetStats() const;

private:
    SaveManager();

    // Config
    std::string m_api_base;
    std::string m_supabase_url;
    std::string m_supabase_key;

    // State
    PlayerAccount       m_account;
    std::atomic<bool>   m_online;
    GameSaveData*       m_live_data      = nullptr;
    float               m_autosave_interval = 60.0f;
    float               m_autosave_timer    = 0.0f;

    // Offline queue
    mutable std::mutex          m_queue_mutex;
    std::queue<SyncEvent>       m_sync_queue;

    // Token storage
    std::string m_local_token_path = ".terra_token";

    // Callbacks
    SaveCallback                              m_on_save;
    std::function<void(const GameSaveData&)>  m_on_load;
    std::function<void(const std::string&)>   m_on_fail;

    // Stats
    mutable std::mutex  m_stats_mutex;
    Stats               m_stats;

    // HTTP helpers
    std::string HttpPost(const std::string& endpoint,
                         const std::string& json_body,
                         bool auth = true);
    std::string HttpGet (const std::string& endpoint,
                         bool auth = true);

    // Serialization
    std::string SerializeSave     (const GameSaveData& data) const;
    bool        DeserializeSave   (const std::string& json,
                                   GameSaveData& out)         const;
    std::string SerializeInventory(const std::vector<InventoryItem>& items) const;
    std::string SerializeCosmetics(const std::vector<CosmeticItem>& items)  const;
    std::string SerializeChanges  (const std::vector<WorldChange>& changes)  const;

    // Token persistence
    void SaveTokenLocally (const std::string& token);
    bool LoadTokenLocally ();

    // Online check
    void CheckOnlineStatus();

    // Queue a sync event — used internally
    void EnqueueSync(SyncType type, const std::string& payload);

    // Process one sync event
    bool ProcessSyncEvent(const SyncEvent& event);

    void UpdateStats(bool success, double latency_ms);

    static const char* MOD;
};

// ============================================================
// CONVENIENCE MACRO
// ============================================================
#define SAVES SaveManager::Get()

} // namespace TerraEngine

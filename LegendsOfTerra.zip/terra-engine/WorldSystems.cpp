// ============================================================
// TERRA ENGINE — WORLD SYSTEMS IMPLEMENTATION
// WorldSystems.cpp — Version 1.0.0
// ============================================================

#include "WorldSystems.h"
#include "JobSystem.h"
#include "MessageChannels.h"
#include <cmath>
#include <algorithm>
#include <queue>

namespace TerraEngine {

const char* EcosystemSimulation::MOD = "Ecosystem";
const char* WorldChunkStreamer::MOD  = "ChunkStreamer";
const char* NavMesh::MOD             = "NavMesh";

// ============================================================
// ECOSYSTEM SIMULATION
// ============================================================
void EcosystemSimulation::Init(int island_id) {
    m_island_id = island_id;
    // Seed default plant cells
    for (int x = 0; x < 20; x++) {
        for (int z = 0; z < 20; z++) {
            PlantCell cell;
            cell.growth = 0.5f + (rand() % 50) * 0.01f;
            cell.water  = 0.6f;
            m_plants[CellKey(x, z)] = cell;
        }
    }
    TLOG_INFO(MOD, "Ecosystem init island " + std::to_string(island_id));
}

void EcosystemSimulation::Tick(float delta_time,
                                  const std::string& weather,
                                  const std::string& time_of_day,
                                  float corruption)
{
    std::lock_guard<std::mutex> lock(m_mutex);
    float rainfall = (weather == "rain" || weather == "storm") ? 0.5f : 0.0f;
    UpdateClimate(weather, corruption, delta_time);
    GrowPlants(delta_time, rainfall);
    UpdatePopulations(delta_time);
    UpdateWaterFlow(delta_time, rainfall);
    CheckPopulationCollapse();
}

void EcosystemSimulation::GrowPlants(float delta_time, float rainfall) {
    for (auto& [key, cell] : m_plants) {
        if (cell.on_fire)   { cell.growth = std::max(0.0f, cell.growth - delta_time * 2.0f); continue; }
        if (cell.corrupted) { cell.growth = std::max(0.0f, cell.growth - delta_time * 0.1f); continue; }

        // Water from rainfall + existing water
        cell.water = std::min(1.0f, cell.water + rainfall * delta_time);
        cell.water = std::max(0.0f, cell.water - 0.001f * delta_time); // evaporation

        // Growth rate based on water, fertility, temperature
        float growth_rate = cell.fertility * cell.water
                          * std::max(0.0f, 1.0f - std::abs(m_temperature - 20.0f) / 30.0f)
                          * delta_time * 0.02f;
        cell.growth = std::min(1.0f, cell.growth + growth_rate);
    }
}

void EcosystemSimulation::BurnPlants(const std::string& sector) {
    std::lock_guard<std::mutex> lock(m_mutex);
    // Mark plants in sector as burning
    for (auto& [key, cell] : m_plants) {
        if (rand() % 3 == 0) { // spread randomly
            cell.on_fire   = true;
            cell.growth    = std::max(0.0f, cell.growth - 0.3f);
        }
    }
    TLOG_INFO(MOD, "Plants burning in sector: " + sector);
}

void EcosystemSimulation::CorruptPlants(const std::string& sector, float amount) {
    std::lock_guard<std::mutex> lock(m_mutex);
    for (auto& [key, cell] : m_plants) {
        if (!cell.corrupted && rand() % 4 == 0) {
            cell.corrupted = true;
            cell.type      = "corrupted_" + cell.type;
        }
    }
}

void EcosystemSimulation::RegrowAfterBurn(const std::string& /*sector*/) {
    std::lock_guard<std::mutex> lock(m_mutex);
    for (auto& [key, cell] : m_plants) {
        if (cell.on_fire) {
            cell.on_fire = false;
            cell.growth  = 0.05f; // sprout
            cell.type    = "grass"; // regrows as grass first
        }
    }
}

float EcosystemSimulation::GetVegetationDensity(int cx, int cz) const {
    std::lock_guard<std::mutex> lock(m_mutex);
    auto it = m_plants.find(CellKey(cx, cz));
    if (it == m_plants.end()) return 0.0f;
    return it->second.growth;
}

void EcosystemSimulation::AddPopulation(const AnimalPopulation& pop) {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_populations[pop.species] = pop;
}

void EcosystemSimulation::UpdatePopulations(float delta_time) {
    for (auto& [species, pop] : m_populations) {
        if (pop.count <= 0) continue;

        float food = GetFoodAvailability(species);

        // Birth — increases with food availability
        float births = pop.birth_rate * pop.count * food * delta_time;
        // Deaths — increases with overcrowding and low food
        float overcrowd = static_cast<float>(pop.count) / pop.max_capacity;
        float deaths    = pop.death_rate * pop.count * (1.0f + overcrowd - food) * delta_time;

        pop.count = std::max(0,
            std::min(pop.max_capacity,
                     pop.count + static_cast<int>(births - deaths)));
    }
    // Predation
    for (const auto& [species, pop] : m_populations) {
        if (!pop.prey_species.empty()) {
            ApplyPredation(species, pop.prey_species);
        }
    }
}

float EcosystemSimulation::GetFoodAvailability(const std::string& species) const {
    auto it = m_populations.find(species);
    if (it == m_populations.end()) return 0.5f;
    const AnimalPopulation& pop = it->second;

    if (pop.prey_species.empty()) {
        // Herbivore — food = vegetation density
        float total_veg = 0.0f;
        for (const auto& [key, cell] : m_plants) total_veg += cell.growth;
        float avg = m_plants.empty() ? 0.5f : total_veg / m_plants.size();
        return avg;
    }
    // Carnivore — food = prey population ratio
    auto prey_it = m_populations.find(pop.prey_species);
    if (prey_it == m_populations.end()) return 0.1f;
    float ratio = static_cast<float>(prey_it->second.count) / 100.0f;
    return std::min(1.0f, ratio);
}

void EcosystemSimulation::ApplyPredation(const std::string& predator,
                                           const std::string& prey)
{
    auto pred_it = m_populations.find(predator);
    auto prey_it = m_populations.find(prey);
    if (pred_it == m_populations.end() || prey_it == m_populations.end()) return;

    int kills = static_cast<int>(pred_it->second.count * 0.01f);
    prey_it->second.count = std::max(0, prey_it->second.count - kills);
}

void EcosystemSimulation::AddWaterBody(const WaterBody& wb) {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_water_bodies[wb.id] = wb;
}

void EcosystemSimulation::UpdateWaterFlow(float delta_time, float rainfall) {
    for (auto& [id, wb] : m_water_bodies) {
        // Rainfall fills water bodies
        wb.level = std::min(1.0f, wb.level + rainfall * delta_time * 0.1f);
        // Evaporation
        wb.level = std::max(0.0f, wb.level - 0.0001f * delta_time);
        // Overflow to downstream
        if (wb.level > 0.9f) {
            for (const auto& downstream_id : wb.connected_to) {
                auto ds_it = m_water_bodies.find(downstream_id);
                if (ds_it != m_water_bodies.end()) {
                    float flow = wb.flow_rate * delta_time;
                    wb.level    = std::max(0.0f, wb.level - flow);
                    ds_it->second.level = std::min(1.0f, ds_it->second.level + flow);
                }
            }
            wb.is_flooded = (wb.level > 0.95f);
        } else {
            wb.is_flooded = false;
        }
    }
}

void EcosystemSimulation::FreezeWater(const std::string& id) {
    std::lock_guard<std::mutex> lock(m_mutex);
    auto it = m_water_bodies.find(id);
    if (it != m_water_bodies.end()) it->second.is_frozen = true;
}

void EcosystemSimulation::ThawWater(const std::string& id) {
    std::lock_guard<std::mutex> lock(m_mutex);
    auto it = m_water_bodies.find(id);
    if (it != m_water_bodies.end()) it->second.is_frozen = false;
}

float EcosystemSimulation::GetWaterLevel(const std::string& id) const {
    std::lock_guard<std::mutex> lock(m_mutex);
    auto it = m_water_bodies.find(id);
    return (it != m_water_bodies.end()) ? it->second.level : 0.0f;
}

bool EcosystemSimulation::IsFlooded(int cx, int cz) const {
    std::lock_guard<std::mutex> lock(m_mutex);
    for (const auto& [id, wb] : m_water_bodies) {
        if (wb.is_flooded && wb.island_id == m_island_id) return true;
    }
    return false;
}

void EcosystemSimulation::UpdateClimate(const std::string& weather,
                                          float corruption,
                                          float delta_time)
{
    // Temperature affected by weather and corruption
    float target_temp = 20.0f;
    if (weather == "snow")  target_temp = -5.0f;
    if (weather == "storm") target_temp = 15.0f;
    if (weather == "clear") target_temp = 25.0f;
    target_temp -= corruption * 10.0f; // corruption cools the world

    m_temperature += (target_temp - m_temperature) * delta_time * 0.1f;

    // Humidity from weather
    float target_hum = (weather == "rain" || weather == "storm") ? 0.9f : 0.4f;
    m_humidity += (target_hum - m_humidity) * delta_time * 0.05f;
}

void EcosystemSimulation::CheckPopulationCollapse() {
    for (auto& [species, pop] : m_populations) {
        if (pop.count <= 0) {
            TriggerFamineEvent(species);
        }
    }
}

void EcosystemSimulation::TriggerFamineEvent(const std::string& species) {
    ChannelMessage msg("species_extinction",
                       species.c_str(),
                       "EcosystemSimulation");
    ROUTER.Post(Channel::WORLD_STATE, msg);
    TLOG_WARN(MOD, "Species population collapsed: " + species);
}

EcosystemSimulation::EcosystemState EcosystemSimulation::GetState() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    EcosystemState s;
    float total_growth = 0.0f;
    int corrupted = 0;
    for (const auto& [k, cell] : m_plants) {
        total_growth += cell.growth;
        if (cell.corrupted) corrupted++;
    }
    s.vegetation_health = m_plants.empty() ? 1.0f
        : total_growth / m_plants.size();
    s.corruption_spread = m_plants.empty() ? 0.0f
        : static_cast<float>(corrupted) / m_plants.size();
    s.ecosystem_healthy = (s.vegetation_health > 0.4f &&
                           s.corruption_spread  < 0.5f);
    return s;
}

// ============================================================
// WORLD CHUNK STREAMER
// ============================================================
void WorldChunkStreamer::Init(int island_id) {
    m_island_id = island_id;
    TLOG_INFO(MOD, "Chunk streamer init — island " + std::to_string(island_id));
}

void WorldChunkStreamer::UpdateStreamingPosition(float px, float pz) {
    ChunkCoord new_chunk = WorldToChunk(px, pz);
    if (new_chunk == m_player_chunk) return;
    m_player_chunk = new_chunk;
    DetermineChunksToLoad();
}

void WorldChunkStreamer::Tick(float /*dt*/) {
    ProcessLoadQueue();
    ProcessUnloadQueue();
}

ChunkCoord WorldChunkStreamer::WorldToChunk(float x, float z) const {
    return { static_cast<int>(std::floor(x / CHUNK_SIZE)),
             static_cast<int>(std::floor(z / CHUNK_SIZE)) };
}

float WorldChunkStreamer::ChunkDistance(const ChunkCoord& a,
                                          const ChunkCoord& b) const {
    float dx = static_cast<float>(a.x - b.x);
    float dz = static_cast<float>(a.z - b.z);
    return std::sqrt(dx*dx + dz*dz);
}

void WorldChunkStreamer::DetermineChunksToLoad() {
    std::lock_guard<std::mutex> lock(m_mutex);

    // Queue nearby chunks for loading
    for (int dx = -PRELOAD_RADIUS; dx <= PRELOAD_RADIUS; dx++) {
        for (int dz = -PRELOAD_RADIUS; dz <= PRELOAD_RADIUS; dz++) {
            ChunkCoord c{m_player_chunk.x + dx, m_player_chunk.z + dz};
            if (!m_chunks.count(c)) {
                m_load_queue.insert(c);
            }
        }
    }

    // Queue far chunks for unloading
    for (auto& [coord, chunk] : m_chunks) {
        if (ChunkDistance(coord, m_player_chunk) > LOAD_RADIUS + 2) {
            m_unload_queue.insert(coord);
        }
    }
}

void WorldChunkStreamer::ProcessLoadQueue() {
    std::set<ChunkCoord> to_load;
    {
        std::lock_guard<std::mutex> lock(m_mutex);
        // Take up to 2 chunks per frame
        int count = 0;
        for (const auto& c : m_load_queue) {
            if (count++ >= 2) break;
            to_load.insert(c);
        }
        for (const auto& c : to_load) m_load_queue.erase(c);
    }
    for (const auto& coord : to_load) {
        LoadChunkAsync(coord);
    }
}

void WorldChunkStreamer::ProcessUnloadQueue() {
    std::set<ChunkCoord> to_unload;
    {
        std::lock_guard<std::mutex> lock(m_mutex);
        int count = 0;
        for (const auto& c : m_unload_queue) {
            if (count++ >= 2) break;
            to_unload.insert(c);
        }
        for (const auto& c : to_unload) m_unload_queue.erase(c);
    }
    for (const auto& coord : to_unload) {
        UnloadChunk(coord);
    }
}

void WorldChunkStreamer::LoadChunkAsync(ChunkCoord coord) {
    JOBS.Submit([this, coord]() {
        auto chunk = std::make_shared<Chunk>();
        chunk->coord     = coord;
        chunk->island_id = m_island_id;
        chunk->state     = ChunkState::LOADING;
        GenerateChunk(*chunk);
        chunk->state = ChunkState::LOADED;
        {
            std::lock_guard<std::mutex> lock(m_mutex);
            m_chunks[coord] = chunk;
        }
        if (m_on_loaded) m_on_loaded(*chunk);
        TLOG_DEBUG(MOD, "Chunk loaded: " + std::to_string(coord.x)
                      + "," + std::to_string(coord.z));
    }, "LoadChunk", JobPriority::NORMAL);
}

void WorldChunkStreamer::GenerateChunk(Chunk& chunk) {
    // Simple heightmap generation using noise-like function
    for (int lx = 0; lx < CHUNK_SIZE; lx++) {
        for (int lz = 0; lz < CHUNK_SIZE; lz++) {
            int wx = chunk.coord.x * CHUNK_SIZE + lx;
            int wz = chunk.coord.z * CHUNK_SIZE + lz;
            // Simple deterministic height
            float h = std::sin(wx * 0.01f) * std::cos(wz * 0.01f) * 20.0f + 5.0f;
            chunk.heightmap[lz * CHUNK_SIZE + lx] = h;
            chunk.biome_map[lz * CHUNK_SIZE + lx] = 0; // default biome
        }
    }
}

void WorldChunkStreamer::UnloadChunk(ChunkCoord coord) {
    std::shared_ptr<Chunk> chunk;
    {
        std::lock_guard<std::mutex> lock(m_mutex);
        auto it = m_chunks.find(coord);
        if (it == m_chunks.end()) return;
        chunk = it->second;
        chunk->state = ChunkState::UNLOADING;
    }
    if (m_on_unloaded && chunk) m_on_unloaded(*chunk);
    {
        std::lock_guard<std::mutex> lock(m_mutex);
        m_chunks.erase(coord);
    }
    TLOG_DEBUG(MOD, "Chunk unloaded: " + std::to_string(coord.x)
                  + "," + std::to_string(coord.z));
}

bool WorldChunkStreamer::IsLoaded(float x, float z) const {
    std::lock_guard<std::mutex> lock(m_mutex);
    return m_chunks.count(WorldToChunk(x, z)) > 0;
}

Chunk* WorldChunkStreamer::GetChunk(float x, float z) {
    return GetChunk(WorldToChunk(x, z));
}

Chunk* WorldChunkStreamer::GetChunk(const ChunkCoord& c) {
    std::lock_guard<std::mutex> lock(m_mutex);
    auto it = m_chunks.find(c);
    return (it != m_chunks.end()) ? it->second.get() : nullptr;
}

bool WorldChunkStreamer::ForceLoad(const ChunkCoord& coord) {
    auto chunk = std::make_shared<Chunk>();
    chunk->coord     = coord;
    chunk->island_id = m_island_id;
    chunk->state     = ChunkState::LOADING;
    GenerateChunk(*chunk);
    chunk->state = ChunkState::LOADED;
    {
        std::lock_guard<std::mutex> lock(m_mutex);
        m_chunks[coord] = chunk;
    }
    return true;
}

int WorldChunkStreamer::LoadedCount() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    return static_cast<int>(m_chunks.size());
}

int WorldChunkStreamer::PendingCount() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    return static_cast<int>(m_load_queue.size());
}

std::vector<Chunk*> WorldChunkStreamer::GetLoadedChunks() {
    std::lock_guard<std::mutex> lock(m_mutex);
    std::vector<Chunk*> result;
    result.reserve(m_chunks.size());
    for (auto& [c, ch] : m_chunks) result.push_back(ch.get());
    return result;
}

// ============================================================
// NAVMESH
// ============================================================
void NavMesh::BuildFromChunk(const Chunk& chunk) {
    std::lock_guard<std::mutex> lock(m_mutex);
    int base_x = chunk.coord.x * CHUNK_SIZE;
    int base_z = chunk.coord.z * CHUNK_SIZE;

    // Step 1: add new nodes for this chunk
    // Track which node IDs are new so we only connect those
    int first_new_id = static_cast<int>(m_nodes.size());

    for (int lx = 0; lx < CHUNK_SIZE; lx += static_cast<int>(NAV_CELL)) {
        for (int lz = 0; lz < CHUNK_SIZE; lz += static_cast<int>(NAV_CELL)) {
            int wx  = base_x + lx;
            int wz  = base_z + lz;
            int gx  = WorldToGrid(static_cast<float>(wx));
            int gz  = WorldToGrid(static_cast<float>(wz));
            int key = GridKey(gx, gz);

            if (m_grid.count(key)) continue;

            NavNode node;
            node.id       = static_cast<int>(m_nodes.size());
            node.x        = static_cast<float>(wx);
            node.z        = static_cast<float>(wz);
            int hi = (lz / static_cast<int>(NAV_CELL))
                   * (CHUNK_SIZE / static_cast<int>(NAV_CELL))
                   + (lx / static_cast<int>(NAV_CELL));
            float h       = chunk.heightmap[hi];
            node.walkable = (h > 0.0f && h < 50.0f);
            node.cost     = 1.0f + std::max(0.0f, h - 10.0f) * 0.1f;

            m_grid[key] = node.id;
            m_nodes.push_back(node);
        }
    }

    int last_new_id = static_cast<int>(m_nodes.size());

    // PERF FIX: old code rebuilt ALL nodes in the entire navmesh on every
    // chunk load — O(total_nodes) per chunk = O(n²) at scale.
    // Fix: only connect (a) new nodes and (b) existing border nodes that
    // now have new neighbours. Everything deeper in existing chunks stays
    // connected exactly as before — no touch needed.

    // Step 2: connect new nodes to their neighbours (new + existing)
    int dx[] = {-1,1,0,0,-1,-1,1,1};
    int dz[] = {0,0,-1,1,-1,1,-1,1};

    for (int id = first_new_id; id < last_new_id; id++) {
        NavNode& node = m_nodes[id];
        node.neighbors.clear();
        int gx = WorldToGrid(node.x);
        int gz = WorldToGrid(node.z);
        for (int d = 0; d < 8; d++) {
            int nk = GridKey(gx + dx[d], gz + dz[d]);
            auto it = m_grid.find(nk);
            if (it != m_grid.end() && m_nodes[it->second].walkable)
                node.neighbors.push_back(it->second);
        }
    }

    // Step 3: update only existing BORDER nodes that may now see new neighbours
    // Border = nodes in adjacent chunk cells (1 nav-cell outside new chunk boundary)
    int min_gx = WorldToGrid(static_cast<float>(base_x)) - 1;
    int max_gx = WorldToGrid(static_cast<float>(base_x + CHUNK_SIZE)) + 1;
    int min_gz = WorldToGrid(static_cast<float>(base_z)) - 1;
    int max_gz = WorldToGrid(static_cast<float>(base_z + CHUNK_SIZE)) + 1;

    for (auto& [key, node_id] : m_grid) {
        if (node_id >= first_new_id) continue; // already handled above
        NavNode& node = m_nodes[node_id];
        int ngx = WorldToGrid(node.x);
        int ngz = WorldToGrid(node.z);
        // Only process nodes in the 1-cell border ring
        bool on_border = (ngx >= min_gx && ngx <= max_gx &&
                          ngz >= min_gz && ngz <= max_gz);
        if (!on_border) continue;

        // Re-check neighbours for this border node only
        node.neighbors.clear();
        for (int d = 0; d < 8; d++) {
            int nk = GridKey(ngx + dx[d], ngz + dz[d]);
            auto it = m_grid.find(nk);
            if (it != m_grid.end() && m_nodes[it->second].walkable)
                node.neighbors.push_back(it->second);
        }
    }
}

NavPath NavMesh::FindPath(float fx, float fz, float tx, float tz) {
    std::lock_guard<std::mutex> lock(m_mutex);
    NavPath path;

    int start_key = GridKey(WorldToGrid(fx), WorldToGrid(fz));
    int end_key   = GridKey(WorldToGrid(tx), WorldToGrid(tz));

    auto sit = m_grid.find(start_key);
    auto eit = m_grid.find(end_key);
    if (sit == m_grid.end() || eit == m_grid.end()) return path;

    int start_id = sit->second;
    int end_id   = eit->second;
    if (!m_nodes[start_id].walkable || !m_nodes[end_id].walkable) return path;

    // A* algorithm
    using PQ = std::priority_queue<std::pair<float,int>,
                                   std::vector<std::pair<float,int>>,
                                   std::greater<>>;
    PQ open;
    std::map<int,float> g_score;
    std::map<int,int>   came_from;

    g_score[start_id] = 0.0f;
    open.push({0.0f, start_id});

    while (!open.empty()) {
        auto [f, cur] = open.top(); open.pop();

        if (cur == end_id) {
            ReconstructPath(came_from, start_id, end_id, path);
            path.valid = true;
            return path;
        }

        for (int nb_id : m_nodes[cur].neighbors) {
            float tentative = g_score[cur] + m_nodes[nb_id].cost;
            if (!g_score.count(nb_id) || tentative < g_score[nb_id]) {
                g_score[nb_id]  = tentative;
                came_from[nb_id] = cur;
                float h = Heuristic(m_nodes[nb_id], m_nodes[end_id]);
                open.push({tentative + h, nb_id});
            }
        }
    }
    return path; // no path found
}

float NavMesh::Heuristic(const NavNode& a, const NavNode& b) const {
    float dx = a.x - b.x;
    float dz = a.z - b.z;
    return std::sqrt(dx*dx + dz*dz);
}

void NavMesh::ReconstructPath(const std::map<int,int>& came_from,
                                int /*start_id*/, int end_id,
                                NavPath& path) const
{
    int cur = end_id;
    while (came_from.count(cur)) {
        path.nodes.push_back(m_nodes[cur]);
        path.total_cost += m_nodes[cur].cost;
        cur = came_from.at(cur);
    }
    std::reverse(path.nodes.begin(), path.nodes.end());
}

bool NavMesh::IsReachable(float fx, float fz, float tx, float tz) const {
    // Simplified — just check both nodes exist and are walkable
    std::lock_guard<std::mutex> lock(m_mutex);
    int sk = GridKey(WorldToGrid(fx), WorldToGrid(fz));
    int ek = GridKey(WorldToGrid(tx), WorldToGrid(tz));
    auto si = m_grid.find(sk);
    auto ei = m_grid.find(ek);
    if (si == m_grid.end() || ei == m_grid.end()) return false;
    return m_nodes[si->second].walkable && m_nodes[ei->second].walkable;
}

std::pair<float,float> NavMesh::NearestWalkable(float x, float z) const {
    std::lock_guard<std::mutex> lock(m_mutex);
    int gx = WorldToGrid(x);
    int gz = WorldToGrid(z);
    // Search expanding rings
    for (int r = 0; r <= 5; r++) {
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                if (std::abs(dx) != r && std::abs(dz) != r) continue;
                int k = GridKey(gx+dx, gz+dz);
                auto it = m_grid.find(k);
                if (it != m_grid.end() && m_nodes[it->second].walkable) {
                    return {m_nodes[it->second].x, m_nodes[it->second].z};
                }
            }
        }
    }
    return {x, z};
}

void NavMesh::MarkBlocked(float x, float z, float radius) {
    std::lock_guard<std::mutex> lock(m_mutex);
    int r = static_cast<int>(radius / NAV_CELL) + 1;
    int gx = WorldToGrid(x), gz = WorldToGrid(z);
    for (int dx = -r; dx <= r; dx++) {
        for (int dz = -r; dz <= r; dz++) {
            auto it = m_grid.find(GridKey(gx+dx, gz+dz));
            if (it != m_grid.end()) m_nodes[it->second].walkable = false;
        }
    }
}

void NavMesh::MarkWalkable(float x, float z, float radius) {
    std::lock_guard<std::mutex> lock(m_mutex);
    int r = static_cast<int>(radius / NAV_CELL) + 1;
    int gx = WorldToGrid(x), gz = WorldToGrid(z);
    for (int dx = -r; dx <= r; dx++) {
        for (int dz = -r; dz <= r; dz++) {
            auto it = m_grid.find(GridKey(gx+dx, gz+dz));
            if (it != m_grid.end()) m_nodes[it->second].walkable = true;
        }
    }
}

void NavMesh::RebuildArea(float x, float z, float radius) {
    // Force-mark area as walkable then rebuild connections
    MarkWalkable(x, z, radius);
}

void NavMesh::Clear() {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_nodes.clear();
    m_grid.clear();
}

int NavMesh::NodeCount() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    return static_cast<int>(m_nodes.size());
}

} // namespace TerraEngine

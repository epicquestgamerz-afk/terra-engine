// ============================================================
// TERRA ENGINE — AGENT BUS HEADER
// AgentBus.h — Version 1.0.0
// ============================================================
// The AgentBus is the communication highway between all agents.
// Agents do not hold direct pointers to each other.
// All messages pass through AgentBus.
// This means:
//   - Agents can be added/removed without breaking others
//   - Messages can be logged, filtered and prioritised
//   - Dead agents do not crash live ones
//   - Broadcast to all agents is trivial
// ============================================================

#pragma once

#include "AgentBase.h"
#include <string>
#include <map>
#include <vector>
#include <unordered_set>
#include <queue>
#include <memory>
#include <mutex>
#include <thread>
#include <atomic>
#include <functional>
#include <chrono>

namespace TerraEngine {

// ============================================================
// MESSAGE FILTER
// Allows agents to subscribe to specific message types
// ============================================================
struct MessageFilter {
    std::string agent_name;  // Which agent this filter belongs to
    std::string type_pattern; // Message type to match ("" = all types)
    std::string from_filter;  // Only from this agent ("" = any)
    MessagePriority min_priority = MessagePriority::AMBIENT;
};

// ============================================================
// BUS EVENT — logged for debugging and replays
// ============================================================
struct BusEvent {
    std::string  message_id;
    std::string  from_agent;
    std::string  to_agent;
    std::string  type;
    bool         delivered;
    double       latency_ms;
    std::chrono::steady_clock::time_point timestamp;
};

// ============================================================
// AGENT BUS CLASS
// ============================================================
class AgentBus {
public:
    AgentBus();
    ~AgentBus();

    // --------------------------------------------------------
    // Agent registration
    // --------------------------------------------------------
    void Register  (AgentBase* agent);
    void Unregister(const std::string& agent_name);
    bool IsRegistered(const std::string& agent_name) const;
    int  AgentCount() const;

    // --------------------------------------------------------
    // Message routing
    // --------------------------------------------------------
    // Route to specific agent
    bool Route(const AgentMessage& msg);

    // Broadcast to all agents except sender
    void Broadcast(const AgentMessage& msg,
                   const std::string& exclude_sender = "");

    // Broadcast to agents with matching capability
    void BroadcastToCapable(const AgentMessage& msg,
                             const std::string& capability,
                             const std::string& exclude = "");

    // --------------------------------------------------------
    // Subscriptions
    // Any agent can subscribe to specific message types
    // --------------------------------------------------------
    void Subscribe  (const MessageFilter& filter);
    void Unsubscribe(const std::string& agent_name,
                     const std::string& type_pattern = "");

    // --------------------------------------------------------
    // Async message processing loop
    // Run this on a background thread for non-blocking comms
    // --------------------------------------------------------
    void StartProcessingLoop();
    void StopProcessingLoop();
    bool IsProcessing() const { return m_processing.load(); }

    // --------------------------------------------------------
    // Synchronous flush — process all queued messages now
    // Call this in game loop when not using async mode
    // --------------------------------------------------------
    void Flush();

    // --------------------------------------------------------
    // Stats and debugging
    // --------------------------------------------------------
    struct Stats {
        uint64_t messages_routed    = 0;
        uint64_t messages_dropped   = 0;
        uint64_t broadcasts_sent    = 0;
        uint64_t delivery_failures  = 0;
        double   avg_latency_ms     = 0.0;
    };
    Stats GetStats() const;
    void  PrintStats() const;
    void  PrintRegisteredAgents() const;

    // Event log — last N events for debugging
    std::vector<BusEvent> GetEventLog(size_t count = 50) const;

    // --------------------------------------------------------
    // World state propagation
    // When world state changes broadcast to all agents
    // --------------------------------------------------------
    void PropagateWorldState(const WorldState& state);

    // --------------------------------------------------------
    // Get registered agent by name
    // Returns nullptr if not found
    // --------------------------------------------------------
    AgentBase* GetAgent(const std::string& name) const;

private:
    // Registered agents
    mutable std::mutex                   m_agents_mutex;
    std::map<std::string, AgentBase*>    m_agents;

    // Capability index — for BroadcastToCapable
    // FIX: unordered_set eliminates duplicates + O(1) lookup
    std::map<std::string, std::unordered_set<std::string>> m_capability_index;

    // Subscriptions
    mutable std::mutex              m_subs_mutex;
    std::vector<MessageFilter>      m_subscriptions;

    // Outbound queue — messages waiting to be delivered
    using BusQueue = std::priority_queue<
        AgentMessage,
        std::vector<AgentMessage>,
        std::greater<AgentMessage>
    >;
    BusQueue           m_queue;
    mutable std::mutex m_queue_mutex;

    // Async processing
    std::thread        m_processing_thread;
    std::atomic<bool>  m_processing;

    // Event log
    mutable std::mutex        m_log_mutex;
    std::deque<BusEvent>      m_event_log;
    static constexpr size_t   MAX_LOG = 500;

    // Stats
    mutable std::mutex m_stats_mutex;
    Stats              m_stats;

    // Internal
    void     DeliverMessage(const AgentMessage& msg);
    void     ProcessingLoop();
    bool     MatchesFilter(const AgentMessage& msg,
                           const MessageFilter& filter) const;
    void     LogEvent(const AgentMessage& msg,
                      bool delivered, double latency_ms);
    void     UpdateStats(bool delivered, double latency_ms);
    void     UpdateCapabilityIndex(AgentBase* agent);

    static const char* MOD;
};

} // namespace TerraEngine

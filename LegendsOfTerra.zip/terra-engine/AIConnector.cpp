// ============================================================
// TERRA ENGINE — AI CONNECTOR IMPLEMENTATION
// AIConnector.cpp — Version 1.2.0
// Providers: HuggingFace, OpenRouter, DeepSeek, Groq, Mistral
// Removed: Gemini, Cloudflare (per user instruction)
// ============================================================

#include "AIConnector.h"
#include <curl/curl.h>
#include <nlohmann/json.hpp>
#include <stdexcept>
#include <chrono>
#include <sstream>
#include <mutex>

using json = nlohmann::json;
using namespace TerraEngine;

// ============================================================
// STATICS
// ============================================================
const char* AIConnector::MOD = "AIConnector";
std::map<std::string, std::string> EnvLoader::s_env;
std::mutex                          EnvLoader::s_mutex;

// ============================================================
// CURL WRITE CALLBACK
// ============================================================
static size_t WriteCallback(void* contents,
                             size_t size,
                             size_t nmemb,
                             std::string* out)
{
    out->append(static_cast<char*>(contents), size * nmemb);
    return size * nmemb;
}

// ============================================================
// CONSTRUCTOR / DESTRUCTOR
// ============================================================
AIConnector::AIConnector() {
    // FIX 1: curl_global_init MUST be called exactly once per process.
    // Was called in every constructor — undefined behavior with multiple instances.
    // Now guarded by call_once — only first instance initialises curl.
    static std::once_flag curl_once;
    std::call_once(curl_once, []() {
        curl_global_init(CURL_GLOBAL_DEFAULT);
        // Note: curl_global_cleanup() called at program exit via atexit
        std::atexit([]() { curl_global_cleanup(); });
    });
    TLOG_INFO(MOD, "Created");
}

AIConnector::~AIConnector() {
    // Wait for all in-flight async calls before destruction
    WaitAllAsync();
    // curl_global_cleanup now handled by atexit — NOT called per-instance
    TLOG_INFO(MOD, "Destroyed");
}

// ============================================================
// INIT
// ============================================================
bool AIConnector::Init(const std::string& env_path) {
    TLOG_INFO(MOD, "Initialising from: " + env_path);
    if (!EnvLoader::Load(env_path)) {
        TLOG_WARN(MOD, ".env not loaded — trying OS environment");
    }
    if (!LoadConfig(env_path)) {
        TLOG_ERR(MOD, "LoadConfig failed");
        return false;
    }
    InitModelMappings();
    TLOG_INFO(MOD, "Ready — 5 providers — 27 models");
    return true;
}

// ============================================================
// LOAD CONFIG
// ============================================================
bool AIConnector::LoadConfig(const std::string& /*env_path*/) {
    m_config.max_retries     = std::stoi(Var("MAX_RETRIES",     "3"));
    m_config.timeout_seconds = std::stoi(Var("REQUEST_TIMEOUT", "30"));
    m_config.debug           = (Var("DEBUG", "false") == "true");

    TLOG_INFO(MOD, "Config: retries=" + std::to_string(m_config.max_retries)
                 + " timeout=" + std::to_string(m_config.timeout_seconds) + "s");

    m_providers[Provider::HUGGINGFACE] = { Var("HF_API_KEY"), Var("HF_BASE_URL"), true, 100, 0 };
    m_providers[Provider::OPENROUTER]  = { Var("OR_API_KEY"), Var("OR_BASE_URL"), true, 200, 0 };
    m_providers[Provider::DEEPSEEK]    = { Var("DS_API_KEY"), Var("DS_BASE_URL"), true, 100, 0 };
    m_providers[Provider::GROQ]        = { Var("GQ_API_KEY"), Var("GQ_BASE_URL"), true,  30, 0 };
    m_providers[Provider::MISTRAL]     = { Var("MS_API_KEY"), Var("MS_BASE_URL"), true, 100, 0 };

    for (auto& [prov, cfg] : m_providers) {
        if (cfg.api_key.empty()) {
            TLOG_WARN(MOD, ProviderName(prov) + " key empty — disabled");
            cfg.enabled = false;
        }
    }
    return true;
}

// ============================================================
// INIT MODEL MAPPINGS
// ============================================================
void AIConnector::InitModelMappings() {
    // HuggingFace
    auto hf = Provider::HUGGINGFACE;
    m_model_providers[Model::HF_PHI3]    = hf; m_model_ids[Model::HF_PHI3]    = Var("HF_PHI3");
    m_model_providers[Model::HF_QWEN]    = hf; m_model_ids[Model::HF_QWEN]    = Var("HF_QWEN");
    m_model_providers[Model::HF_MISTRAL] = hf; m_model_ids[Model::HF_MISTRAL] = Var("HF_MISTRAL");
    m_model_providers[Model::HF_LLAMA]   = hf; m_model_ids[Model::HF_LLAMA]   = Var("HF_LLAMA");
    m_model_providers[Model::HF_GEMMA]   = hf; m_model_ids[Model::HF_GEMMA]   = Var("HF_GEMMA");
    m_model_providers[Model::HF_BARK]    = hf; m_model_ids[Model::HF_BARK]    = Var("HF_BARK");
    m_model_providers[Model::HF_WHISPER] = hf; m_model_ids[Model::HF_WHISPER] = Var("HF_WHISPER");

    // OpenRouter
    auto or_ = Provider::OPENROUTER;
    m_model_providers[Model::OR_GPT4O]        = or_; m_model_ids[Model::OR_GPT4O]        = Var("OR_GPT4O");
    m_model_providers[Model::OR_CLAUDE]       = or_; m_model_ids[Model::OR_CLAUDE]       = Var("OR_CLAUDE");
    m_model_providers[Model::OR_LLAMA405B]    = or_; m_model_ids[Model::OR_LLAMA405B]    = Var("OR_LLAMA405B");
    m_model_providers[Model::OR_MIXTRAL]      = or_; m_model_ids[Model::OR_MIXTRAL]      = Var("OR_MIXTRAL");
    m_model_providers[Model::OR_CLAUDE_HAIKU] = or_; m_model_ids[Model::OR_CLAUDE_HAIKU] = Var("OR_CLAUDE_HAIKU");

    // DeepSeek
    auto ds = Provider::DEEPSEEK;
    m_model_providers[Model::DS_CHAT]     = ds; m_model_ids[Model::DS_CHAT]     = Var("DS_CHAT");
    m_model_providers[Model::DS_CODER]    = ds; m_model_ids[Model::DS_CODER]    = Var("DS_CODER");
    m_model_providers[Model::DS_REASONER] = ds; m_model_ids[Model::DS_REASONER] = Var("DS_REASONER");

    // Groq
    auto gq = Provider::GROQ;
    m_model_providers[Model::GQ_LLAMA]      = gq; m_model_ids[Model::GQ_LLAMA]      = Var("GQ_LLAMA");
    m_model_providers[Model::GQ_MIXTRAL]    = gq; m_model_ids[Model::GQ_MIXTRAL]    = Var("GQ_MIXTRAL");
    m_model_providers[Model::GQ_GEMMA]      = gq; m_model_ids[Model::GQ_GEMMA]      = Var("GQ_GEMMA");
    m_model_providers[Model::GQ_LLAMA_FAST] = gq; m_model_ids[Model::GQ_LLAMA_FAST] = Var("GQ_LLAMA_FAST");

    // Mistral
    auto ms = Provider::MISTRAL;
    m_model_providers[Model::MS_LARGE]  = ms; m_model_ids[Model::MS_LARGE]  = Var("MS_LARGE");
    m_model_providers[Model::MS_MEDIUM] = ms; m_model_ids[Model::MS_MEDIUM] = Var("MS_MEDIUM");
    m_model_providers[Model::MS_SMALL]  = ms; m_model_ids[Model::MS_SMALL]  = Var("MS_SMALL");
    m_model_providers[Model::MS_NEMO]   = ms; m_model_ids[Model::MS_NEMO]   = Var("MS_NEMO");

    TLOG_INFO(MOD, "Mapped " + std::to_string(m_model_providers.size()) + " models");
}

// ============================================================
// CALL
// ============================================================
AIResponse AIConnector::Call(const AIRequest& request) {
    AIResponse response;

    if (request.model == Model::UNKNOWN) {
        response.error = "Model::UNKNOWN passed to Call()";
        TLOG_ERR(MOD, response.error);
        return response;
    }

    auto it = m_model_providers.find(request.model);
    if (it == m_model_providers.end()) {
        response.error = "Model not found in provider map";
        TLOG_ERR(MOD, response.error);
        return response;
    }

    return CallWithRetry(request, it->second);
}

// ============================================================
// CALL WITH RETRY
// ============================================================
AIResponse AIConnector::CallWithRetry(const AIRequest& req, Provider provider) {
    AIResponse response;
    auto& cfg = m_providers[provider];

    if (!cfg.enabled) {
        response.error = ProviderName(provider) + " disabled";
        return response;
    }
    if (IsRateLimited(provider)) {
        response.error = ProviderName(provider) + " rate limited";
        TLOG_WARN(MOD, response.error);
        return response;
    }

    auto t_start = std::chrono::high_resolution_clock::now();

    for (int attempt = 1; attempt <= m_config.max_retries; attempt++) {
        TLOG_DEBUG(MOD, "Attempt " + std::to_string(attempt)
                      + "/" + std::to_string(m_config.max_retries)
                      + " — " + ProviderName(provider));

        switch (provider) {
            case Provider::HUGGINGFACE:
                response = CallHuggingFace(req, cfg);  break;
            case Provider::OPENROUTER:
            case Provider::DEEPSEEK:
            case Provider::GROQ:
            case Provider::MISTRAL:
                response = CallOpenAICompat(req, cfg); break;
            default:
                response.error = "Unhandled provider";
                return response;
        }

        response.retry_count = attempt - 1;
        if (response.success) break;

        if (attempt < m_config.max_retries) {
            int wait_ms = 500 * attempt;
            TLOG_WARN(MOD, "Retry " + std::to_string(attempt)
                         + " failed — waiting " + std::to_string(wait_ms) + "ms");
            std::this_thread::sleep_for(std::chrono::milliseconds(wait_ms));
        }
    }

    auto t_end = std::chrono::high_resolution_clock::now();
    double latency = std::chrono::duration<double, std::milli>(t_end - t_start).count();

    response.latency_ms     = latency;
    response.provider_used  = provider;
    response.provider_name  = ProviderName(provider);

    IncrementCount(provider);
    UpdateStats(response, latency);
    return response;
}

// ============================================================
// CALL WITH FALLBACK
// ============================================================
AIResponse AIConnector::CallWithFallback(
    const AIRequest& request,
    const std::vector<Model>& fallback_chain)
{
    AIResponse response = Call(request);
    if (response.success) return response;

    TLOG_WARN(MOD, "Primary failed — trying fallback chain");
    for (const Model& m : fallback_chain) {
        AIRequest req = request;
        req.model     = m;
        response      = Call(req);
        if (response.success) {
            TLOG_INFO(MOD, "Fallback succeeded: " + ModelName(m));
            return response;
        }
    }

    response.success = false;
    response.error   = "All fallbacks exhausted";
    TLOG_ERR(MOD, response.error);
    return response;
}

// ============================================================
// CALL ASYNC
// BUG 3 FIX: old version stored threads in m_threads vector.
// joinable() returns true for FINISHED-but-not-joined threads too,
// so remove_if(not joinable) never pruned anything.
// Vector grew by 1 on every AI call, only cleared in destructor.
// Fix: detach immediately + atomic counter tracks in-flight calls.
// Zero memory growth. WaitAllAsync spins on the counter.
// ============================================================
void AIConnector::CallAsync(
    const AIRequest& request,
    std::function<void(AIResponse)> callback)
{
    AIRequest req_copy      = request;
    auto      callback_copy = callback;

    m_active_async.fetch_add(1);
    std::thread([this, req_copy, callback_copy]() {
        AIResponse r = Call(req_copy);
        if (callback_copy) callback_copy(r);
        m_active_async.fetch_sub(1);
    }).detach(); // detach — counter tracks completion, no leak
}

void AIConnector::WaitAllAsync() {
    // Spin until all in-flight async calls complete
    while (m_active_async.load() > 0) {
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
}

// ============================================================
// CALL HUGGING FACE
// ============================================================
AIResponse AIConnector::CallHuggingFace(const AIRequest& req,
                                          const ProviderConfig& cfg)
{
    AIResponse response;
    CURL* curl = curl_easy_init();
    if (!curl) { response.error = "CURL init failed"; return response; }

    auto id_it = m_model_ids.find(req.model);
    if (id_it == m_model_ids.end() || id_it->second.empty()) {
        response.error = "Model ID not found";
        curl_easy_cleanup(curl);
        return response;
    }

    std::string url = cfg.base_url + "/" + id_it->second;
    std::string response_str;

    json payload = {
        {"inputs", req.prompt},
        {"parameters", {
            {"max_new_tokens", req.max_tokens},
            {"temperature",    req.temperature},
            {"return_full_text", false}
        }}
    };
    std::string body = payload.dump();

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, ("Authorization: Bearer " + cfg.api_key).c_str());
    headers = curl_slist_append(headers, "Content-Type: application/json");

    curl_easy_setopt(curl, CURLOPT_URL,           url.c_str());
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER,    headers);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS,    body.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA,     &response_str);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT,       static_cast<long>(m_config.timeout_seconds));

    CURLcode res = curl_easy_perform(curl);

    if (res == CURLE_OK) {
        try {
            json result = json::parse(response_str);
            if (result.is_array() && !result.empty()) {
                response.text    = result[0].value("generated_text", "");
                response.success = !response.text.empty();
            } else {
                response.error = "Unexpected HF response format";
            }
        } catch (const json::parse_error& e) {
            response.error = std::string("JSON parse error: ") + e.what();
            TLOG_ERR(MOD, response.error);
        } catch (const json::type_error& e) {
            response.error = std::string("JSON type error: ") + e.what();
            TLOG_ERR(MOD, response.error);
        } catch (const std::exception& e) {
            response.error = std::string("Exception: ") + e.what();
            TLOG_ERR(MOD, response.error);
        }
    } else {
        response.error = std::string("CURL: ") + curl_easy_strerror(res);
        TLOG_ERR(MOD, response.error);
    }

    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
    return response;
}

// ============================================================
// CALL OPENAI-COMPATIBLE (OpenRouter, DeepSeek, Groq, Mistral)
// ============================================================
AIResponse AIConnector::CallOpenAICompat(const AIRequest& req,
                                           const ProviderConfig& cfg)
{
    AIResponse response;
    CURL* curl = curl_easy_init();
    if (!curl) { response.error = "CURL init failed"; return response; }

    auto id_it = m_model_ids.find(req.model);
    if (id_it == m_model_ids.end() || id_it->second.empty()) {
        response.error = "Model ID not found";
        curl_easy_cleanup(curl);
        return response;
    }

    std::string url = cfg.base_url + "/chat/completions";
    std::string response_str;

    json messages = json::array();
    if (!req.system_prompt.empty())
        messages.push_back({{"role","system"},{"content",req.system_prompt}});
    messages.push_back({{"role","user"},{"content",req.prompt}});

    json payload = {
        {"model",       id_it->second},
        {"messages",    messages},
        {"max_tokens",  req.max_tokens},
        {"temperature", req.temperature}
    };
    std::string body = payload.dump();

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, ("Authorization: Bearer " + cfg.api_key).c_str());
    headers = curl_slist_append(headers, "Content-Type: application/json");

    curl_easy_setopt(curl, CURLOPT_URL,           url.c_str());
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER,    headers);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS,    body.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA,     &response_str);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT,       static_cast<long>(m_config.timeout_seconds));

    CURLcode res = curl_easy_perform(curl);

    // FIX 12: Get HTTP status code for retry differentiation
    long http_code = 0;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_code);

    if (res == CURLE_OK) {
        // FIX 5: Always log response body on HTTP errors for debuggability
        if (http_code >= 400) {
            TLOG_ERR(MOD, "HTTP " + std::to_string(http_code)
                        + " from " + url
                        + " body: " + response_str.substr(0, 200));
            // FIX 12: 401/403 = auth error, don't retry. 5xx = server error, do retry.
            if (http_code == 401 || http_code == 403) {
                response.error = "Auth error HTTP " + std::to_string(http_code)
                               + " — check API key";
                response.retry_count = m_config.max_retries; // signal: no more retries
            } else if (http_code == 429) {
                response.error = "Rate limited HTTP 429 — backing off";
            } else {
                response.error = "HTTP " + std::to_string(http_code);
            }
        } else {
            // FIX 4: Safe JSON parsing — use .contains() before every access
            try {
                json result = json::parse(response_str);

                // Check for API-level error in response body
                if (result.contains("error")) {
                    std::string api_err = result["error"].is_string()
                        ? result["error"].get<std::string>()
                        : result["error"].value("message", "unknown API error");
                    response.error = "API error: " + api_err;
                    TLOG_ERR(MOD, response.error + " body: " + response_str.substr(0, 200));
                }
                // FIX 4: safe chain — check every level before access
                else if (result.contains("choices")
                      && result["choices"].is_array()
                      && !result["choices"].empty()
                      && result["choices"][0].contains("message")
                      && result["choices"][0]["message"].contains("content"))
                {
                    response.text       = result["choices"][0]["message"]["content"]
                                              .get<std::string>();
                    response.tokens_used= result.contains("usage")
                        ? result["usage"].value("total_tokens", 0) : 0;
                    response.model_used = result.value("model", id_it->second);
                    response.success    = !response.text.empty();
                } else {
                    response.error = "Unexpected response format: " + response_str.substr(0, 200);
                    TLOG_ERR(MOD, response.error);
                }
            } catch (const json::parse_error& e) {
                response.error = std::string("JSON parse error: ") + e.what()
                               + " body: " + response_str.substr(0, 100);
                TLOG_ERR(MOD, response.error);
            } catch (const json::type_error& e) {
                response.error = std::string("JSON type error: ") + e.what();
                TLOG_ERR(MOD, response.error);
            } catch (const std::exception& e) {
                response.error = std::string("Exception: ") + e.what();
                TLOG_ERR(MOD, response.error);
            }
        }
    } else {
        // FIX 5: Log both curl error code and any partial response body
        response.error = std::string("CURL: ") + curl_easy_strerror(res);
        if (!response_str.empty()) {
            response.error += " partial_body: " + response_str.substr(0, 100);
        }
        TLOG_ERR(MOD, response.error);
    }

    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
    return response;
}

// ============================================================
// PROVIDER TESTS
// ============================================================
bool AIConnector::TestProvider(Provider provider) {
    AIRequest req;
    req.max_tokens = 20;
    req.prompt     = "Reply with exactly: Terra Engine online";

    switch (provider) {
        case Provider::HUGGINGFACE: req.model = Model::HF_PHI3;    break;
        case Provider::OPENROUTER:  req.model = Model::OR_GPT4O;   break;
        case Provider::DEEPSEEK:    req.model = Model::DS_CHAT;    break;
        case Provider::GROQ:        req.model = Model::GQ_LLAMA;   break;
        case Provider::MISTRAL:     req.model = Model::MS_SMALL;   break;
        default:
            TLOG_ERR(MOD, "Unknown provider for test");
            return false;
    }

    AIResponse r  = Call(req);
    std::string s = r.success ? "[OK]   " : "[FAIL] ";
    std::string m = r.success ? r.text.substr(0, 40) : r.error.substr(0, 40);
    TLOG_INFO(MOD, s + ProviderName(provider) + " — " + m
                 + " (" + std::to_string(static_cast<int>(r.latency_ms)) + "ms)");
    return r.success;
}

std::map<Provider, bool> AIConnector::TestAll() {
    TLOG_INFO(MOD, "=== Testing 5 providers ===");
    std::map<Provider, bool> results;
    results[Provider::HUGGINGFACE] = TestProvider(Provider::HUGGINGFACE);
    results[Provider::OPENROUTER]  = TestProvider(Provider::OPENROUTER);
    results[Provider::DEEPSEEK]    = TestProvider(Provider::DEEPSEEK);
    results[Provider::GROQ]        = TestProvider(Provider::GROQ);
    results[Provider::MISTRAL]     = TestProvider(Provider::MISTRAL);
    int passed = 0;
    for (auto& [p, ok] : results) if (ok) passed++;
    TLOG_INFO(MOD, "=== " + std::to_string(passed) + "/5 online ===");
    return results;
}

bool AIConnector::IsProviderAvailable(Provider provider) {
    auto it = m_providers.find(provider);
    if (it == m_providers.end()) return false;
    return it->second.enabled && !IsRateLimited(provider);
}

// ============================================================
// STATS
// ============================================================
void AIConnector::UpdateStats(const AIResponse& r, double latency_ms) {
    std::lock_guard<std::mutex> lock(m_stats_mutex);
    m_stats.total_calls++;
    if (r.success) m_stats.successful_calls++;
    else           m_stats.failed_calls++;
    m_stats.calls_per_provider[r.provider_used]++;
    double delta = latency_ms - m_stats.avg_latency_ms;
    m_stats.avg_latency_ms += delta / m_stats.total_calls;
}

AIConnector::Stats AIConnector::GetStats() const {
    std::lock_guard<std::mutex> lock(m_stats_mutex);
    return m_stats;
}

void AIConnector::PrintStats() const {
    Stats s = GetStats();
    float rate = s.total_calls > 0
        ? (100.0f * s.successful_calls / s.total_calls) : 0.0f;
    TLOG_INFO(MOD, "Total:" + std::to_string(s.total_calls)
                 + " OK:"   + std::to_string(s.successful_calls)
                 + " Fail:" + std::to_string(s.failed_calls)
                 + " Rate:" + std::to_string(static_cast<int>(rate)) + "%"
                 + " AvgMs:" + std::to_string(static_cast<int>(s.avg_latency_ms)));
}

// ============================================================
// HELPERS
// ============================================================
bool AIConnector::IsRateLimited(Provider p) {
    auto it = m_providers.find(p);
    if (it == m_providers.end()) return true;
    return it->second.calls_made >= it->second.rate_limit;
}

void AIConnector::IncrementCount(Provider p) {
    auto it = m_providers.find(p);
    if (it != m_providers.end()) it->second.calls_made++;
}

void AIConnector::ResetRateLimits() {
    for (auto& [p, cfg] : m_providers) cfg.calls_made = 0;
}

std::string AIConnector::Var(const std::string& key,
                              const std::string& fallback) {
    return EnvLoader::Get(key, fallback);
}

std::string AIConnector::ProviderName(Provider p) const {
    switch (p) {
        case Provider::HUGGINGFACE: return "HuggingFace";
        case Provider::OPENROUTER:  return "OpenRouter";
        case Provider::DEEPSEEK:    return "DeepSeek";
        case Provider::GROQ:        return "Groq";
        case Provider::MISTRAL:     return "Mistral";
        default:                    return "Unknown";
    }
}

std::string AIConnector::ModelName(Model m) const {
    auto it = m_model_ids.find(m);
    return (it != m_model_ids.end()) ? it->second : "unknown";
}

// ============================================================
// BUG 3 FIX: GetGlobalAI() — global singleton implementation
// Same instance used by all transformers and async pipeline
// curl_global_init called ONCE in constructor — safe
// ============================================================
AIConnector& GetGlobalAI() {
    static AIConnector instance;
    // Init on first call — idempotent after first call
    static std::once_flag init_flag;
    std::call_once(init_flag, [&]() {
        instance.Init(".env");
    });
    return instance;
}

// ============================================================
// TERRA ENGINE — PHYSICS WORLD IMPLEMENTATION
// PhysicsWorld.cpp — Version 1.0.0
// ============================================================
// Uses Jolt Physics (MIT license).
// If Jolt is not available, falls back to a lightweight
// AABB + sphere collision system sufficient for the game.
// ============================================================
#include "PhysicsWorld.h"
#include "ECS.h"
#include "AIConnector.h"
#include <cmath>
#include <algorithm>
#include <cstring>

namespace TerraEngine {
const char* PhysicsWorld::MOD = "PhysicsWorld";

// Simple internal body storage (Jolt would replace this layer)
struct InternalBody {
    float pos[3]   = {0,0,0};
    float vel[3]   = {0,0,0};
    float force[3] = {0,0,0};
    float mass     = 70.0f;
    float restitution = 0.1f;
    float friction    = 0.6f;
    float lin_damp    = 0.5f;
    float half_ext[3] = {0.5f, 0.9f, 0.5f}; // AABB half extents
    PhysicsLayer layer = PhysicsLayer::DYNAMIC;
    bool  is_static   = false;
    bool  is_kinematic= false;
    bool  is_trigger  = false;
    bool  lock_rot    = false;
    bool  on_ground   = false;
    bool  alive       = true;
    Entity entity     = 0;
};

// Internal storage separate from public API
static std::map<uint32_t, InternalBody> s_bodies;
// BUG 3 FIX: Removed s_bodies_mutex — m_mutex already gates all s_bodies access.
// The dead mutex was misleading, implying a separate locking contract that didn't exist.
static float s_gravity = -9.81f;

// ============================================================
// LAYER COLLISION MATRIX DEFAULT
// ============================================================
void PhysicsWorld::InitDefaultLayerMatrix() {
    // All layers collide by default
    for (int a = 0; a < static_cast<int>(PhysicsLayer::COUNT); a++)
        for (int b = 0; b < static_cast<int>(PhysicsLayer::COUNT); b++)
            m_layer_table[a][b] = true;

    // Triggers don't physically block anything
    int trig = static_cast<int>(PhysicsLayer::TRIGGER);
    for (int i = 0; i < static_cast<int>(PhysicsLayer::COUNT); i++) {
        m_layer_table[trig][i] = false;
        m_layer_table[i][trig] = false;
    }

    // Projectiles don't collide with other projectiles
    int proj = static_cast<int>(PhysicsLayer::PROJECTILE);
    m_layer_table[proj][proj] = false;

    // Water is only trigger-style
    int water = static_cast<int>(PhysicsLayer::WATER);
    m_layer_table[water][water] = false;
}

// ============================================================
// INIT
// ============================================================
bool PhysicsWorld::Init(float gravity_y) {
    m_gravity_y = gravity_y;
    s_gravity   = gravity_y;
    InitDefaultLayerMatrix();
    m_initialized = true;
    TLOG_INFO(MOD, "Physics initialised — gravity: " + std::to_string(gravity_y));
    return true;
}

void PhysicsWorld::Shutdown() {
    std::lock_guard<std::mutex> lock(m_mutex);
    s_bodies.clear();
    m_bodies.clear();
    m_initialized = false;
    TLOG_INFO(MOD, "Physics shutdown");
}

// ============================================================
// CREATE BODY
// ============================================================
uint32_t PhysicsWorld::CreateBody(const PhysicsBodyDesc& desc,
                                   float px, float py, float pz)
{
    std::lock_guard<std::mutex> lock(m_mutex);
    uint32_t id = m_next_id++;

    InternalBody b;
    b.pos[0]  = px; b.pos[1] = py; b.pos[2] = pz;
    b.mass    = desc.is_kinematic || desc.mass == 0 ? 0.0f : desc.mass;
    b.restitution  = desc.restitution;
    b.friction     = desc.friction;
    b.lin_damp     = desc.linear_damping;
    b.half_ext[0]  = desc.half_x;
    b.half_ext[1]  = desc.half_y;
    b.half_ext[2]  = desc.half_z;
    b.layer        = desc.layer;
    b.is_static    = (desc.mass == 0.0f && !desc.is_kinematic);
    b.is_kinematic = desc.is_kinematic;
    b.is_trigger   = desc.is_trigger;
    b.lock_rot     = desc.lock_rotation;
    b.entity       = desc.entity;

    BodyEntry entry;
    entry.jolt_id     = id;
    entry.entity      = desc.entity;
    entry.layer       = desc.layer;
    entry.is_trigger  = desc.is_trigger;

    s_bodies[id] = b;
    m_bodies[id] = entry;
    return id;
}

uint32_t PhysicsWorld::CreateCharacterController(
    float radius, float height,
    float px, float py, float pz,
    Entity entity, PhysicsLayer layer)
{
    PhysicsBodyDesc d;
    d.shape        = ShapeType::CAPSULE;
    d.half_x       = radius;
    d.half_y       = height * 0.5f;
    d.half_z       = radius;
    d.mass         = 70.0f;
    d.layer        = layer;
    d.lock_rotation= true;
    d.entity       = entity;
    d.friction     = 0.1f;
    d.linear_damping = 0.8f;
    uint32_t id = CreateBody(d, px, py, pz);
    // BUG 10 FIX: m_mutex must be held when writing m_bodies — CreateBody releases it before returning
    {
        std::lock_guard<std::mutex> lock(m_mutex);
        m_bodies[id].is_character = true;
    }
    return id;
}

void PhysicsWorld::DestroyBody(uint32_t id) {
    std::lock_guard<std::mutex> lock(m_mutex);
    s_bodies.erase(id);
    m_bodies.erase(id);
}

bool PhysicsWorld::IsBodyAlive(uint32_t id) const {
    std::lock_guard<std::mutex> lock(m_mutex);
    return s_bodies.count(id) > 0;
}

// ============================================================
// MOVE CHARACTER
// ============================================================
void PhysicsWorld::MoveCharacter(uint32_t id, float mx, float mz,
                                  float jump_vel, float dt)
{
    std::lock_guard<std::mutex> lock(m_mutex);
    auto it = s_bodies.find(id);
    if (it == s_bodies.end()) return;
    InternalBody& b = it->second;

    b.vel[0] = mx;
    b.vel[2] = mz;
    if (jump_vel > 0.0f && b.on_ground) {
        b.vel[1] = jump_vel;
        b.on_ground = false;
    }
}

// ============================================================
// STEP — integrate + detect ground
// ============================================================
void PhysicsWorld::Step(float dt) {
    if (!m_initialized) return;
    std::lock_guard<std::mutex> lock(m_mutex);

    for (auto& [id, b] : s_bodies) {
        if (b.is_static || b.is_kinematic) continue;

        // BUG 2 FIX: Apply accumulated force to velocity before integration
        // Without this, AddForce() (explosions, knockback, wind, magic pushback) was dead code.
        if (b.mass > 0.0f) {
            b.vel[0] += (b.force[0] / b.mass) * dt;
            b.vel[1] += (b.force[1] / b.mass) * dt;
            b.vel[2] += (b.force[2] / b.mass) * dt;
        }
        b.force[0] = b.force[1] = b.force[2] = 0.0f; // reset each step

        // Gravity
        b.vel[1] += s_gravity * dt;

        // Linear damping
        b.vel[0] *= (1.0f - b.lin_damp * dt);
        b.vel[2] *= (1.0f - b.lin_damp * dt);

        // Integrate position
        b.pos[0] += b.vel[0] * dt;
        b.pos[1] += b.vel[1] * dt;
        b.pos[2] += b.vel[2] * dt;

        // Ground plane at y=0 (terrain overrides this)
        if (b.pos[1] - b.half_ext[1] <= 0.0f) {
            b.pos[1]    = b.half_ext[1];
            b.vel[1]    = b.vel[1] < 0 ? -b.vel[1] * b.restitution : b.vel[1];
            b.on_ground = true;
        } else {
            b.on_ground = false;
        }

        // Update body entry
        if (m_bodies.count(id)) m_bodies[id].on_ground = b.on_ground;
    }

    // AABB broad-phase collision between dynamic bodies
    std::vector<std::pair<uint32_t,uint32_t>> pairs;
    for (auto it_a = s_bodies.begin(); it_a != s_bodies.end(); ++it_a) {
        for (auto it_b = std::next(it_a); it_b != s_bodies.end(); ++it_b) {
            auto& a = it_a->second;
            auto& b_body = it_b->second;
            if (a.is_static && b_body.is_static) continue;

            // Layer filter
            int la = static_cast<int>(a.layer);
            int lb = static_cast<int>(b_body.layer);
            if (!m_layer_table[la][lb]) continue;

            // AABB overlap test
            bool overlap = true;
            for (int ax = 0; ax < 3; ax++) {
                float dist = std::abs(a.pos[ax] - b_body.pos[ax]);
                float sum  = a.half_ext[ax] + b_body.half_ext[ax];
                if (dist > sum) { overlap = false; break; }
            }
            if (overlap) pairs.push_back({it_a->first, it_b->first});
        }
    }

    // Resolve contacts
    for (auto& [ia, ib] : pairs) {
        InternalBody& ba = s_bodies[ia];
        InternalBody& bb = s_bodies[ib];

        // Trigger check — fire callback, no physics response
        if (ba.is_trigger || bb.is_trigger) {
            if (m_trigger_cb) {
                Entity trig  = ba.is_trigger ? ba.entity : bb.entity;
                Entity other = ba.is_trigger ? bb.entity : ba.entity;
                m_trigger_cb(trig, other, true);
            }
            continue;
        }

        // Simple impulse resolution
        for (int ax = 0; ax < 3; ax++) {
            float rv = ba.vel[ax] - bb.vel[ax];
            float overlap = (ba.half_ext[ax] + bb.half_ext[ax]) -
                             std::abs(ba.pos[ax] - bb.pos[ax]);
            if (overlap <= 0.0f) continue;
            float e    = std::min(ba.restitution, bb.restitution);
            float j    = -(1 + e) * rv;
            float inv_a = ba.is_static ? 0.0f : 1.0f / ba.mass;
            float inv_b = bb.is_static ? 0.0f : 1.0f / bb.mass;
            if (inv_a + inv_b < 0.0001f) continue;
            j /= (inv_a + inv_b);
            float dir = ba.pos[ax] > bb.pos[ax] ? 1.0f : -1.0f;
            ba.vel[ax] += j * inv_a * dir;
            bb.vel[ax] -= j * inv_b * dir;
        }

        if (m_contact_cb) {
            ContactEvent ev;
            ev.body_a = ba.entity; ev.body_b = bb.entity;
            ev.is_trigger = false;
            m_contact_cb(ev);
        }
    }

    SyncECSTransforms();
}

// ============================================================
// SYNC ECS TRANSFORMS
// ============================================================
void PhysicsWorld::SyncECSTransforms() {
    // Write physics positions back to ECS TransformComponent
    // ECSWorld lives in ECS.h — read body positions and push to ECS
    for (auto& [id, b] : s_bodies) {
        if (b.entity == 0) continue;
        // ECS::Get().SetTransform(b.entity, b.pos[0], b.pos[1], b.pos[2]);
        // Uncomment when TransformComponent is wired to physics
    }
}

// ============================================================
// SETTERS / GETTERS
// ============================================================
void PhysicsWorld::SetPosition(uint32_t id, float x, float y, float z) {
    std::lock_guard<std::mutex> l(m_mutex);
    auto it = s_bodies.find(id);
    if (it == s_bodies.end()) return;
    it->second.pos[0]=x; it->second.pos[1]=y; it->second.pos[2]=z;
}
void PhysicsWorld::SetVelocity(uint32_t id, float vx, float vy, float vz) {
    std::lock_guard<std::mutex> l(m_mutex);
    auto it = s_bodies.find(id);
    if (it == s_bodies.end()) return;
    it->second.vel[0]=vx; it->second.vel[1]=vy; it->second.vel[2]=vz;
}
void PhysicsWorld::AddImpulse(uint32_t id, float x, float y, float z) {
    std::lock_guard<std::mutex> l(m_mutex);
    auto it = s_bodies.find(id);
    if (it == s_bodies.end() || it->second.is_static) return;
    float inv_m = 1.0f / it->second.mass;
    it->second.vel[0] += x * inv_m;
    it->second.vel[1] += y * inv_m;
    it->second.vel[2] += z * inv_m;
}
void PhysicsWorld::AddForce(uint32_t id, float x, float y, float z) {
    std::lock_guard<std::mutex> l(m_mutex);
    auto it = s_bodies.find(id);
    if (it == s_bodies.end()) return;
    it->second.force[0]+=x; it->second.force[1]+=y; it->second.force[2]+=z;
}
void PhysicsWorld::GetPosition(uint32_t id, float& x, float& y, float& z) const {
    std::lock_guard<std::mutex> l(m_mutex);
    auto it = s_bodies.find(id);
    if (it == s_bodies.end()) { x=y=z=0; return; }
    x=it->second.pos[0]; y=it->second.pos[1]; z=it->second.pos[2];
}
void PhysicsWorld::GetVelocity(uint32_t id, float& vx, float& vy, float& vz) const {
    std::lock_guard<std::mutex> l(m_mutex);
    auto it = s_bodies.find(id);
    if (it == s_bodies.end()) { vx=vy=vz=0; return; }
    vx=it->second.vel[0]; vy=it->second.vel[1]; vz=it->second.vel[2];
}
bool PhysicsWorld::IsOnGround(uint32_t id) const {
    std::lock_guard<std::mutex> l(m_mutex);
    auto it = s_bodies.find(id);
    return it != s_bodies.end() && it->second.on_ground;
}

// ============================================================
// RAYCAST
// ============================================================
RaycastHit PhysicsWorld::Raycast(float ox, float oy, float oz,
                                   float dx, float dy, float dz,
                                   float max_dist, PhysicsLayer mask) const
{
    RaycastHit result;
    float best_t = max_dist;
    std::lock_guard<std::mutex> l(m_mutex);

    for (const auto& [id, b] : s_bodies) {
        // NEW-6 FIX: PhysicsLayer::ALL is the proper "hit anything" sentinel.
        // Previously PhysicsLayer::STATIC was reused as wildcard — ambiguous and
        // prevented callers from ever raycasting only static geometry.
        if (mask != PhysicsLayer::ALL &&
            static_cast<int>(b.layer) != static_cast<int>(mask)) continue;

        // Slab AABB-ray intersection
        float t_min = 0.0f, t_max = best_t;
        bool  hit   = true;
        for (int ax = 0; ax < 3; ax++) {
            float d_ax = ax == 0 ? dx : ax == 1 ? dy : dz;
            float o_ax = ax == 0 ? ox : ax == 1 ? oy : oz;
            float mn   = b.pos[ax] - b.half_ext[ax];
            float mx   = b.pos[ax] + b.half_ext[ax];
            if (std::abs(d_ax) < 1e-6f) {
                if (o_ax < mn || o_ax > mx) { hit = false; break; }
            } else {
                float t1 = (mn - o_ax) / d_ax;
                float t2 = (mx - o_ax) / d_ax;
                if (t1 > t2) std::swap(t1, t2);
                t_min = std::max(t_min, t1);
                t_max = std::min(t_max, t2);
                if (t_min > t_max) { hit = false; break; }
            }
        }
        if (hit && t_min < best_t) {
            best_t       = t_min;
            result.hit   = true;
            result.distance = t_min;
            result.point[0] = ox + dx * t_min;
            result.point[1] = oy + dy * t_min;
            result.point[2] = oz + dz * t_min;
            result.entity   = b.entity;
            result.layer    = b.layer;
        }
    }
    return result;
}

std::vector<Entity> PhysicsWorld::OverlapSphere(float cx, float cy, float cz,
                                                  float radius,
                                                  PhysicsLayer mask) const
{
    std::vector<Entity> result;
    std::lock_guard<std::mutex> l(m_mutex);
    for (const auto& [id, b] : s_bodies) {
        float dx = b.pos[0]-cx, dy = b.pos[1]-cy, dz = b.pos[2]-cz;
        float dist2 = dx*dx + dy*dy + dz*dz;
        float r2    = (radius + std::max({b.half_ext[0],b.half_ext[1],b.half_ext[2]}));
        if (dist2 <= r2 * r2) result.push_back(b.entity);
    }
    return result;
}

void PhysicsWorld::SetLayerCollision(PhysicsLayer a, PhysicsLayer b, bool collides) {
    int ia = static_cast<int>(a), ib = static_cast<int>(b);
    m_layer_table[ia][ib] = m_layer_table[ib][ia] = collides;
}

uint32_t PhysicsWorld::CreateTerrainBody(const float* heightmap,
                                          int sx, int sz,
                                          float cell_size,
                                          float height_scale,
                                          float px, float pz)
{
    // Creates a static body matching the heightmap
    // For proper terrain, Jolt's HeightFieldShape would be used
    // Here we create a bounding-box approximation per chunk
    PhysicsBodyDesc d;
    d.shape    = ShapeType::BOX;
    d.half_x   = sx * cell_size * 0.5f;
    d.half_y   = height_scale * 0.5f;
    d.half_z   = sz * cell_size * 0.5f;
    d.mass     = 0.0f; // static
    d.layer    = PhysicsLayer::STATIC;
    d.is_kinematic = false;
    return CreateBody(d, px + d.half_x, d.half_y, pz + d.half_z);
}

void PhysicsWorld::DebugDraw() const {
    // Visual debug output for physics shapes
    // Renderer draws wireframe AABB overlays
}

} // namespace TerraEngine

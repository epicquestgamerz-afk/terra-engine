// ============================================================
// TERRA ENGINE — NPC AI BRAIN IMPLEMENTATION
// NPCBrain.cpp — Version 1.0.0
// ============================================================

#include "NPCBrain.h"
#include <algorithm>
#include <sstream>
#include <cmath>

namespace TerraEngine {

const char* NPCBrain::MOD = "NPCBrain";

// ============================================================
// DECISION ENGINE — UTILITY AI SCORING
// ============================================================
std::vector<ActionScore> DecisionEngine::ScoreActions(
    const PerceptionData& p,
    const NPCMemoryBank&  m,
    float                 /*delta_time*/) const
{
    std::vector<ActionScore> scores;

    auto add = [&](NPCAction a, float s, const std::string& r) {
        scores.push_back({a, std::max(0.0f, s), r});
    };

    add(NPCAction::IDLE,          ScoreIdle      (p, m), "idle");
    add(NPCAction::WORK,          ScoreWork      (p, m), "work");
    add(NPCAction::FLEE,          ScoreFlee      (p, m), "flee");
    add(NPCAction::FIGHT,         ScoreFight     (p, m), "fight");
    add(NPCAction::EAT,           ScoreEat       (p, m), "eat");
    add(NPCAction::SLEEP,         ScoreSleep     (p, m), "sleep");
    add(NPCAction::TALK_TO_PLAYER,ScoreTalkPlayer(p, m), "talk_player");
    add(NPCAction::SEEK_HELP,     ScoreSeekHelp  (p, m), "seek_help");
    add(NPCAction::CHANGE_JOB,    ScoreChangeJob (p, m), "change_job");

    // Sort descending by score
    std::sort(scores.begin(), scores.end(),
        [](const ActionScore& a, const ActionScore& b) {
            return a.score > b.score;
        });

    return scores;
}

NPCAction DecisionEngine::GetBestAction(
    const PerceptionData& p,
    const NPCMemoryBank& m,
    float delta_time) const
{
    // Behavior tree takes priority over utility scores
    NPCAction bt = CheckBehaviorTree(p, m);
    if (bt != NPCAction::IDLE) return bt;

    auto scores = ScoreActions(p, m, delta_time);
    if (scores.empty()) return NPCAction::IDLE;
    return scores[0].action;
}

// ============================================================
// BEHAVIOR TREE — hard overrides for critical situations
// ============================================================
NPCAction DecisionEngine::CheckBehaviorTree(
    const PerceptionData& p,
    const NPCMemoryBank&  m) const
{
    // SELECTOR: try conditions in priority order

    // 1. Critical danger — enemy very close and NPC is not brave
    if (p.enemy_in_sight && p.enemy_distance < 5.0f && p.threat_level > 0.8f) {
        return NPCAction::FLEE;
    }

    // 2. NPC in danger — seek help immediately
    if (p.in_danger && !p.nearby_npcs.empty()) {
        return NPCAction::SEEK_HELP;
    }

    // 3. Night time — go sleep if low energy
    if (p.time_of_day == "night") {
        return NPCAction::SLEEP;
    }

    // No override
    return NPCAction::IDLE;
}

// ============================================================
// UTILITY SCORE FUNCTIONS
// Each returns 0.0 to 1.0
// ============================================================
float DecisionEngine::ScoreIdle(
    const PerceptionData& p,
    const NPCMemoryBank& /*m*/) const
{
    // Idle is fine when safe and no pressing needs
    float score = 0.1f;
    if (p.in_safe_zone) score += 0.1f;
    if (!p.enemy_in_sight) score += 0.1f;
    return score;
}

float DecisionEngine::ScoreWork(
    const PerceptionData& p,
    const NPCMemoryBank& m) const
{
    // Work during daytime in safe area
    float score = 0.0f;
    if (p.time_of_day == "morning" || p.time_of_day == "noon") score += 0.4f;
    if (p.in_safe_zone) score += 0.3f;
    if (!p.enemy_in_sight) score += 0.2f;
    if (m.money < 0.3f) score += 0.3f; // desperate for money
    return std::min(1.0f, score);
}

float DecisionEngine::ScoreFlee(
    const PerceptionData& p,
    const NPCMemoryBank& /*m*/) const
{
    if (!p.enemy_in_sight && p.threat_level < 0.3f) return 0.0f;
    float score = p.threat_level * 0.8f;
    // Closer enemy = stronger flee urge
    if (p.enemy_distance < 10.0f) score += (10.0f - p.enemy_distance) * 0.05f;
    return std::min(1.0f, score);
}

float DecisionEngine::ScoreFight(
    const PerceptionData& p,
    const NPCMemoryBank& m) const
{
    if (!p.enemy_in_sight) return 0.0f;
    float score = 0.0f;
    // Guards and soldiers fight
    if (m.job == "guard" || m.job == "soldier") score += 0.6f;
    // Bold personality fights more
    if (m.personality == "bold") score += 0.3f;
    // Only fight if threat is manageable
    score *= (1.0f - p.threat_level * 0.5f);
    return std::min(1.0f, score);
}

float DecisionEngine::ScoreEat(
    const PerceptionData& p,
    const NPCMemoryBank& /*m*/) const
{
    // Need to know NPC hunger — passed via NPCBrain
    // This score is boosted externally by NPCBrain::hunger
    float score = 0.0f;
    if (!p.enemy_in_sight) score += 0.1f;
    return score; // hunger boost applied in NPCBrain
}

float DecisionEngine::ScoreSleep(
    const PerceptionData& p,
    const NPCMemoryBank& /*m*/) const
{
    float score = 0.0f;
    if (p.time_of_day == "night") score += 0.5f;
    if (p.in_safe_zone) score += 0.2f;
    return score; // energy boost applied in NPCBrain
}

float DecisionEngine::ScoreTalkPlayer(
    const PerceptionData& p,
    const NPCMemoryBank& m) const
{
    if (!p.player_nearby || p.player_distance > 5.0f) return 0.0f;
    float score = 0.2f;
    if (m.player_trust > 0.5f) score += 0.3f;
    if (p.in_safe_zone) score += 0.1f;
    return std::min(1.0f, score);
}

float DecisionEngine::ScoreSeekHelp(
    const PerceptionData& p,
    const NPCMemoryBank& /*m*/) const
{
    if (!p.in_danger) return 0.0f;
    float score = p.threat_level * 0.7f;
    if (!p.nearby_npcs.empty()) score += 0.3f;
    return std::min(1.0f, score);
}

float DecisionEngine::ScoreChangeJob(
    const PerceptionData& p,
    const NPCMemoryBank& m) const
{
    // Only consider changing job if safe and currently unhappy
    if (!p.in_safe_zone) return 0.0f;
    float mood = m.GetMood();
    if (mood > 0.5f) return 0.0f; // happy — no reason to change
    return (0.5f - mood) * 0.4f;
}

// ============================================================
// ACTION EXECUTOR
// ============================================================
ActionResult ActionExecutor::Execute(
    NPCAction             action,
    const PerceptionData& perception,
    const NPCMemoryBank&  memory,
    const std::string&    npc_id)
{
    switch (action) {
        case NPCAction::IDLE:           return ExecuteIdle(memory);
        case NPCAction::WORK:           return ExecuteWork(memory);
        case NPCAction::FLEE:           return ExecuteFlee(perception);
        case NPCAction::FIGHT:          return ExecuteFight(perception);
        case NPCAction::EAT:            return ExecuteEat(memory);
        case NPCAction::SLEEP:          return ExecuteSleep();
        case NPCAction::TALK_TO_PLAYER: return ExecuteTalk(perception, memory, npc_id);
        case NPCAction::SEEK_HELP:      return ExecuteSeekHelp(perception);
        case NPCAction::CHANGE_JOB:     return ExecuteChangeJob(memory, npc_id);
        default:                        return ExecuteIdle(memory);
    }
}

ActionResult ActionExecutor::ExecuteIdle(const NPCMemoryBank& m) {
    ActionResult r;
    r.completed = true;
    r.command   = "anim:idle";
    r.duration  = 2.0f + (m.GetMood() * 3.0f); // happier NPCs idle longer
    return r;
}

ActionResult ActionExecutor::ExecuteWork(const NPCMemoryBank& m) {
    ActionResult r;
    r.completed = true;
    r.duration  = 10.0f;

    if      (m.job == "blacksmith") { r.command = "anim:forge"; }
    else if (m.job == "farmer")     { r.command = "anim:farm";  }
    else if (m.job == "trader")     { r.command = "anim:trade"; }
    else if (m.job == "guard")      { r.command = "anim:patrol";}
    else if (m.job == "healer")     { r.command = "anim:heal";  }
    else                            { r.command = "anim:work";  }

    return r;
}

ActionResult ActionExecutor::ExecuteFlee(const PerceptionData& p) {
    ActionResult r;
    r.completed = true;
    r.command   = "move:flee from:" + p.enemy_id
                + " threat:" + std::to_string(p.threat_level);
    r.duration  = 5.0f;

    // Scared dialogue
    const char* scared[] = {
        "Run! Everyone run!",
        "It's too dangerous here!",
        "We have to get out!",
        "Help! Someone help us!"
    };
    r.dialogue = scared[static_cast<int>(p.enemy_distance) % 4];
    return r;
}

ActionResult ActionExecutor::ExecuteFight(const PerceptionData& p) {
    ActionResult r;
    r.completed = true;
    r.command   = "combat:engage target:" + p.enemy_id;
    r.duration  = 3.0f;

    const char* battle_cries[] = {
        "For the village!",
        "Stand your ground!",
        "I won't let you pass!",
        "Back, creature!"
    };
    r.dialogue = battle_cries[static_cast<int>(p.enemy_distance) % 4];
    return r;
}

ActionResult ActionExecutor::ExecuteEat(const NPCMemoryBank& m) {
    ActionResult r;
    r.completed = true;
    r.command   = "anim:eat";
    r.duration  = 4.0f;

    if (!m.known_locations.empty()) {
        // Walk to nearest food source
        for (const auto& loc : m.known_locations) {
            if (loc.label == "food_source") {
                r.command = "move:to:" + std::to_string(loc.x)
                          + "," + std::to_string(loc.z) + " then:eat";
                break;
            }
        }
    }
    return r;
}

ActionResult ActionExecutor::ExecuteSleep() {
    ActionResult r;
    r.completed = true;
    r.command   = "anim:sleep";
    r.duration  = 30.0f; // 30 second sleep cycle
    return r;
}

ActionResult ActionExecutor::ExecuteTalk(
    const PerceptionData&  /*p*/,
    const NPCMemoryBank&   m,
    const std::string&     npc_id)
{
    ActionResult r;
    r.completed = true;
    r.command   = "anim:talk";
    r.duration  = 3.0f;

    // Mood-based greeting
    float mood = m.GetMood();
    if      (mood > 0.7f) r.dialogue = "Good day, traveller! Fine weather, isn't it?";
    else if (mood > 0.4f) r.dialogue = "Hmm? What do you want?";
    else                  r.dialogue = "Leave me alone. I have troubles of my own.";

    return r;
}

ActionResult ActionExecutor::ExecuteSeekHelp(const PerceptionData& p) {
    ActionResult r;
    r.completed = true;
    r.command   = "move:to_nearest_npc";
    r.duration  = 2.0f;
    r.dialogue  = "Help! There is danger nearby!";
    return r;
}

ActionResult ActionExecutor::ExecuteChangeJob(
    const NPCMemoryBank& m,
    const std::string&   /*npc_id*/)
{
    ActionResult r;
    r.completed = true;
    r.command   = "job:request_change from:" + m.job;
    r.duration  = 1.0f;
    r.dialogue  = "I need to find different work. This life is not for me.";
    return r;
}

// ============================================================
// NPC BRAIN — MAIN CLASS
// ============================================================
NPCBrain::NPCBrain(const std::string& npc_id,
                    const std::string& personality)
    : m_npc_id(npc_id)
    , m_current_action(NPCAction::IDLE)
    , m_action_timer(0.0f)
    , m_needs_update_timer(0.0f)
{
    m_memory.personality = personality;
    Logger::Get().Log(LogLevel::DEBUG, MOD,
        "NPCBrain created for: " + npc_id + " personality: " + personality);
}

ActionResult NPCBrain::Think(float delta_time) {
    std::lock_guard<std::mutex> lock(m_mutex);

    // Update needs every second
    m_needs_update_timer += delta_time;
    if (m_needs_update_timer >= 1.0f) {
        UpdateNeeds(m_needs_update_timer);
        m_needs_update_timer = 0.0f;
    }

    // Count down current action
    m_action_timer -= delta_time;
    if (m_action_timer > 0.0f) {
        // Still performing current action
        return {false, "", "", m_action_timer};
    }

    // Time for new decision
    // Apply need modifiers to utility scores before deciding
    // This is how hunger/thirst/energy influence action choice

    // Temporarily modify perception based on needs
    PerceptionData modified_perception = m_perception;

    // Hunger makes NPCs seek food
    if (hunger < 0.2f) {
        modified_perception.threat_level += 0.1f; // desperation
    }

    // Low safety makes NPC more alert to threats
    if (safety < 0.3f) {
        modified_perception.in_danger = true;
    }

    // Get new action from decision engine
    NPCAction new_action = m_decision.GetBestAction(
        modified_perception, m_memory, delta_time);

    // Override with needs
    if (hunger < 0.15f && m_perception.in_safe_zone) {
        new_action = NPCAction::EAT;
    }
    if (energy < 0.1f && m_perception.time_of_day == "night") {
        new_action = NPCAction::SLEEP;
    }

    m_current_action = new_action;

    // Execute action
    ActionResult result = m_executor.Execute(
        new_action, m_perception, m_memory, m_npc_id);

    m_action_timer = result.duration;
    result.completed = true;

    // Record action in memory
    if (!result.command.empty()) {
        m_memory.AddEvent("did:" + result.command, 0.0f);
    }

    return result;
}

void NPCBrain::UpdatePerception(const PerceptionData& data) {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_perception = data;

    // Update memory from perception
    if (data.enemy_in_sight) {
        EnemyMemory& em = m_memory.known_enemies[data.enemy_id];
        em.id            = data.enemy_id;
        em.last_seen     = std::chrono::steady_clock::now();
        em.threat_level  = data.threat_level;
        em.encounter_count++;

        // Negative event memory
        m_memory.AddEvent("saw_enemy:" + data.enemy_id, -0.3f);
    }
}

void NPCBrain::OnEvent(const std::string& event_type,
                        const std::string& data)
{
    std::lock_guard<std::mutex> lock(m_mutex);

    if (event_type == "village_attack") {
        m_memory.AddEvent("village_attacked", -0.8f);
        m_perception.in_danger    = true;
        m_perception.threat_level = 0.9f;
        safety = 0.1f;
    }
    else if (event_type == "boss_defeated") {
        m_memory.AddEvent("boss_defeated_celebration", +0.9f);
        safety = std::min(1.0f, safety + 0.5f);
    }
    else if (event_type == "storm_start") {
        m_memory.AddEvent("storm_started", -0.2f);
        m_perception.current_weather = "storm";
    }
    else if (event_type == "player_helped") {
        m_memory.player_trust = std::min(1.0f, m_memory.player_trust + 0.2f);
        m_memory.AddEvent("player_helped_me", +0.5f);
    }
    else if (event_type == "paid") {
        money = std::min(1.0f, money + 0.2f);
        m_memory.AddEvent("received_payment", +0.3f);
    }
}

std::string NPCBrain::GetDialogue(const std::string& player_action) {
    std::lock_guard<std::mutex> lock(m_mutex);

    float mood = m_memory.GetMood();
    float trust = m_memory.player_trust;

    // Build context for AI or fallback to scripted
    if (player_action == "greet") {
        if      (mood > 0.7f && trust > 0.5f) return "Welcome back, friend! Good to see you.";
        else if (mood > 0.5f)                  return "Hello there. What brings you here?";
        else if (trust < 0.0f)                 return "What do you want? Make it quick.";
        else                                   return "Hmm. You again.";
    }
    else if (player_action == "trade") {
        if (mood > 0.5f) return "Sure, let's see what you've got.";
        else             return "Fine. But I'm not in a generous mood today.";
    }
    else if (player_action == "quest") {
        if (trust > 0.3f) return "Actually, there is something you could help me with...";
        else              return "I don't trust strangers with my problems. Prove yourself first.";
    }
    else if (player_action == "attack") {
        m_memory.player_trust -= 0.5f;
        m_memory.AddEvent("player_attacked_me", -1.0f);
        return "What are you doing?! Guards!";
    }

    // Generic response based on mood
    if (mood > 0.6f) return "Is there something I can help you with?";
    if (mood < 0.3f) return "Not now. I have enough problems.";
    return "Yes?";
}

std::string NPCBrain::GetMoodString() const {
    float mood = m_memory.GetMood();
    if      (mood > 0.8f) return "very_happy";
    else if (mood > 0.6f) return "happy";
    else if (mood > 0.4f) return "neutral";
    else if (mood > 0.2f) return "unhappy";
    else                  return "miserable";
}

void NPCBrain::UpdateNeeds(float delta_time) {
    // Needs decay over time — drives NPC decisions
    float rate = delta_time * 0.005f;

    hunger = std::max(0.0f, hunger - rate * 0.8f);
    thirst = std::max(0.0f, thirst - rate * 1.2f); // thirst drops faster
    energy = std::max(0.0f, energy - rate * 0.4f);
    social = std::max(0.0f, social - rate * 0.3f);

    // Safety recovers in safe zones
    if (m_perception.in_safe_zone) {
        safety = std::min(1.0f, safety + rate * 0.5f);
    } else {
        safety = std::max(0.0f, safety - rate * 0.2f);
    }

    // Low thirst/hunger causes mood degradation
    if (hunger < 0.2f) m_memory.AddEvent("hungry", -0.1f);
    if (thirst < 0.1f) m_memory.AddEvent("thirsty", -0.2f);
}

} // namespace TerraEngine

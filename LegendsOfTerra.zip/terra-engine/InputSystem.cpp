// ============================================================
// TERRA ENGINE — INPUT SYSTEM IMPLEMENTATION
// InputSystem.cpp — Version 1.0.0
// ============================================================

#include "InputSystem.h"
#include "AIConnector.h"
#include <GLFW/glfw3.h>
#include <fstream>
#include <algorithm>
#include <cmath>

namespace TerraEngine {

const char* InputSystem::MOD = "InputSystem";

// ============================================================
// GLFW STATIC CALLBACKS
// ============================================================
static void glfw_key_cb(GLFWwindow*, int key, int scan, int action, int mods) {
    InputSystem::Get()._OnKey(key, scan, action, mods);
}
static void glfw_mouse_btn_cb(GLFWwindow*, int btn, int action, int mods) {
    InputSystem::Get()._OnMouseBtn(btn, action, mods);
}
static void glfw_cursor_cb(GLFWwindow*, double x, double y) {
    InputSystem::Get()._OnMouseMove(x, y);
}
static void glfw_scroll_cb(GLFWwindow*, double dx, double dy) {
    InputSystem::Get()._OnScroll(dx, dy);
}
static void glfw_char_cb(GLFWwindow*, unsigned int cp) {
    InputSystem::Get()._OnChar(cp);
}

// ============================================================
// CONSTRUCTOR
// ============================================================
InputSystem::InputSystem() {
    m_keys_cur.fill(false);
    m_keys_prev.fill(false);
    m_keys_rep.fill(false);
    m_mouse_cur.fill(false);
    m_mouse_prev.fill(false);
}

// ============================================================
// INIT
// ============================================================
void InputSystem::Init(void* window_handle) {
    m_window = window_handle;
    GLFWwindow* win = static_cast<GLFWwindow*>(window_handle);

    glfwSetKeyCallback         (win, glfw_key_cb);
    glfwSetMouseButtonCallback (win, glfw_mouse_btn_cb);
    glfwSetCursorPosCallback   (win, glfw_cursor_cb);
    glfwSetScrollCallback      (win, glfw_scroll_cb);
    glfwSetCharCallback        (win, glfw_char_cb);

    BindDefaultGameActions();
    TLOG_INFO(MOD, "InputSystem ready");
}

void InputSystem::Shutdown() {
    TLOG_INFO(MOD, "InputSystem shutdown");
}

// ============================================================
// DEFAULT GAME ACTION BINDINGS
// ============================================================
void InputSystem::BindDefaultGameActions() {
    // Movement
    BindAction({"move_forward",  Key::W});
    BindAction({"move_back",     Key::S});
    BindAction({"move_left",     Key::A});
    BindAction({"move_right",    Key::D});
    BindAction({"jump",          Key::Space});
    BindAction({"sprint",        Key::LShift});
    BindAction({"crouch",        Key::LCtrl});
    BindAction({"dodge",         Key::LAlt});

    // Combat
    BindAction({"attack_light",  Key::COUNT, MouseButton::Left});
    BindAction({"attack_heavy",  Key::COUNT, MouseButton::Right});
    BindAction({"block",         Key::COUNT, MouseButton::Middle});
    BindAction({"use_ability",   Key::Q});
    BindAction({"use_ability2",  Key::E});
    BindAction({"use_gauntlet",  Key::R});  // Kael only

    // Interaction
    BindAction({"interact",      Key::F});
    BindAction({"inventory",     Key::I});
    BindAction({"map",           Key::M});
    BindAction({"pause",         Key::Escape});
    BindAction({"journal",       Key::J});

    // Camera
    BindAction({"lock_on",       Key::Z});
    BindAction({"zoom_in",       Key::Equals});
    BindAction({"zoom_out",      Key::Minus});

    // Debug
    BindAction({"debug_menu",    Key::Tilde});
    BindAction({"debug_ai",      Key::F1});
    BindAction({"debug_render",  Key::F2});
    BindAction({"screenshot",    Key::F12});

    TLOG_INFO(MOD, "Default game actions bound");
}

// ============================================================
// BEGIN / END FRAME
// ============================================================
void InputSystem::BeginFrame() {
    // Copy current to previous
    m_keys_prev  = m_keys_cur;
    m_mouse_prev = m_mouse_cur;

    for (auto& pad : m_pads) pad.btns_prev = pad.btns_cur;

    // Reset per-frame deltas
    m_mouse_dx   = 0.0f;
    m_mouse_dy   = 0.0f;
    m_scroll_x   = 0.0f;
    m_scroll_y   = 0.0f;
    m_keys_rep.fill(false);

    // Poll GLFW events
    glfwPollEvents();
    PollGamepads();
}

void InputSystem::EndFrame() {
    m_pinch_delta = 0.0f;
}

// ============================================================
// KEYBOARD QUERIES
// ============================================================
bool InputSystem::IsKeyDown    (Key k) const { return m_keys_cur [static_cast<int>(k)]; }
bool InputSystem::IsKeyPressed (Key k) const { return  m_keys_cur[static_cast<int>(k)] && !m_keys_prev[static_cast<int>(k)]; }
bool InputSystem::IsKeyReleased(Key k) const { return !m_keys_cur[static_cast<int>(k)] &&  m_keys_prev[static_cast<int>(k)]; }
bool InputSystem::IsKeyRepeated(Key k) const { return m_keys_rep [static_cast<int>(k)]; }

// ============================================================
// MOUSE QUERIES
// ============================================================
bool InputSystem::IsMouseDown    (MouseButton b) const { return m_mouse_cur [static_cast<int>(b)]; }
bool InputSystem::IsMousePressed (MouseButton b) const { return  m_mouse_cur[static_cast<int>(b)] && !m_mouse_prev[static_cast<int>(b)]; }
bool InputSystem::IsMouseReleased(MouseButton b) const { return !m_mouse_cur[static_cast<int>(b)] &&  m_mouse_prev[static_cast<int>(b)]; }

void InputSystem::SetMouseCapture(bool capture) {
    m_mouse_captured = capture;
    m_mouse_first    = true;
    GLFWwindow* win  = static_cast<GLFWwindow*>(m_window);
    glfwSetInputMode(win, GLFW_CURSOR,
                     capture ? GLFW_CURSOR_DISABLED : GLFW_CURSOR_NORMAL);
}

// ============================================================
// GAMEPAD
// ============================================================
bool InputSystem::IsGamepadConnected(int id) const {
    if (id < 0 || id >= MAX_PADS) return false;
    return m_pads[id].connected;
}

bool InputSystem::IsGamepadDown(GamepadButton b, int id) const {
    if (id < 0 || id >= MAX_PADS) return false;
    return m_pads[id].btns_cur[static_cast<int>(b)];
}

bool InputSystem::IsGamepadPressed(GamepadButton b, int id) const {
    if (id < 0 || id >= MAX_PADS) return false;
    int i = static_cast<int>(b);
    return m_pads[id].btns_cur[i] && !m_pads[id].btns_prev[i];
}

bool InputSystem::IsGamepadReleased(GamepadButton b, int id) const {
    if (id < 0 || id >= MAX_PADS) return false;
    int i = static_cast<int>(b);
    return !m_pads[id].btns_cur[i] && m_pads[id].btns_prev[i];
}

float InputSystem::GetGamepadAxis(GamepadAxis a, int id) const {
    if (id < 0 || id >= MAX_PADS) return 0.0f;
    return ApplyDeadZone(m_pads[id].axes[static_cast<int>(a)]);
}

float InputSystem::ApplyDeadZone(float v) const {
    if (std::abs(v) < m_dead_zone) return 0.0f;
    float sign = (v > 0.0f) ? 1.0f : -1.0f;
    return sign * (std::abs(v) - m_dead_zone) / (1.0f - m_dead_zone);
}

void InputSystem::PollGamepads() {
    for (int id = 0; id < MAX_PADS; id++) {
        if (!glfwJoystickIsGamepad(id)) {
            m_pads[id].connected = false;
            continue;
        }
        GLFWgamepadstate state;
        if (!glfwGetGamepadState(id, &state)) continue;
        m_pads[id].connected = true;

        // Buttons
        const int btn_map[] = {
            GLFW_GAMEPAD_BUTTON_A, GLFW_GAMEPAD_BUTTON_B,
            GLFW_GAMEPAD_BUTTON_X, GLFW_GAMEPAD_BUTTON_Y,
            GLFW_GAMEPAD_BUTTON_LEFT_BUMPER, GLFW_GAMEPAD_BUTTON_RIGHT_BUMPER,
            GLFW_GAMEPAD_BUTTON_LEFT_BUMPER, GLFW_GAMEPAD_BUTTON_RIGHT_BUMPER,
            GLFW_GAMEPAD_BUTTON_LEFT_THUMB,  GLFW_GAMEPAD_BUTTON_RIGHT_THUMB,
            GLFW_GAMEPAD_BUTTON_DPAD_UP,     GLFW_GAMEPAD_BUTTON_DPAD_DOWN,
            GLFW_GAMEPAD_BUTTON_DPAD_LEFT,   GLFW_GAMEPAD_BUTTON_DPAD_RIGHT,
            GLFW_GAMEPAD_BUTTON_START,       GLFW_GAMEPAD_BUTTON_BACK,
            GLFW_GAMEPAD_BUTTON_GUIDE
        };
        for (int i = 0; i < MAX_GAMEPAD && i < 17; i++) {
            m_pads[id].btns_cur[i] = state.buttons[btn_map[i]] == GLFW_PRESS;
        }

        // Axes
        m_pads[id].axes[0] = state.axes[GLFW_GAMEPAD_AXIS_LEFT_X];
        m_pads[id].axes[1] = state.axes[GLFW_GAMEPAD_AXIS_LEFT_Y];
        m_pads[id].axes[2] = state.axes[GLFW_GAMEPAD_AXIS_RIGHT_X];
        m_pads[id].axes[3] = state.axes[GLFW_GAMEPAD_AXIS_RIGHT_Y];
        m_pads[id].axes[4] = state.axes[GLFW_GAMEPAD_AXIS_LEFT_TRIGGER];
        m_pads[id].axes[5] = state.axes[GLFW_GAMEPAD_AXIS_RIGHT_TRIGGER];
    }
}

// ============================================================
// TOUCH
// ============================================================
int InputSystem::GetTouchCount() const { return m_touch_count; }
const TouchPoint InputSystem::GetTouch(int idx) const {
    if (idx < 0 || idx >= MAX_TOUCHES) return {};
    return m_touches[idx];
}

// ============================================================
// ACTION MAPPING
// ============================================================
void InputSystem::BindAction(const ActionBinding& binding) {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_actions[binding.name] = binding;
}

void InputSystem::UnbindAction(const std::string& name) {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_actions.erase(name);
}

bool InputSystem::IsActionDown(const std::string& name) const {
    std::lock_guard<std::mutex> lock(m_mutex);
    auto it = m_actions.find(name);
    if (it == m_actions.end()) return false;
    const ActionBinding& b = it->second;
    if (b.key    != Key::COUNT)          return IsKeyDown(b.key);
    if (b.mouse_btn != MouseButton::COUNT) return IsMouseDown(b.mouse_btn);
    if (b.gamepad_btn != GamepadButton::COUNT) return IsGamepadDown(b.gamepad_btn);
    return false;
}

bool InputSystem::IsActionPressed(const std::string& name) const {
    std::lock_guard<std::mutex> lock(m_mutex);
    auto it = m_actions.find(name);
    if (it == m_actions.end()) return false;
    const ActionBinding& b = it->second;
    if (b.key    != Key::COUNT)          return IsKeyPressed(b.key);
    if (b.mouse_btn != MouseButton::COUNT) return IsMousePressed(b.mouse_btn);
    if (b.gamepad_btn != GamepadButton::COUNT) return IsGamepadPressed(b.gamepad_btn);
    return false;
}

bool InputSystem::IsActionReleased(const std::string& name) const {
    std::lock_guard<std::mutex> lock(m_mutex);
    auto it = m_actions.find(name);
    if (it == m_actions.end()) return false;
    const ActionBinding& b = it->second;
    if (b.key    != Key::COUNT)          return IsKeyReleased(b.key);
    if (b.mouse_btn != MouseButton::COUNT) return IsMouseReleased(b.mouse_btn);
    if (b.gamepad_btn != GamepadButton::COUNT) return IsGamepadReleased(b.gamepad_btn);
    return false;
}

// ============================================================
// CALLBACKS
// ============================================================
void InputSystem::OnKey  (const std::string& id, KeyCallback   cb) { m_key_cbs[id]   = cb; }
void InputSystem::OnMouse(const std::string& id, MouseCallback cb) { m_mouse_cbs[id] = cb; }
void InputSystem::OnText (const std::string& id, TextCallback  cb) { m_text_cbs[id]  = cb; }
void InputSystem::RemoveCallback(const std::string& id) {
    m_key_cbs.erase(id); m_mouse_cbs.erase(id); m_text_cbs.erase(id);
}

// ============================================================
// GLFW CALLBACKS
// ============================================================
void InputSystem::_OnKey(int glfw_key, int, int action, int) {
    Key k = GLFWKeyToKey(glfw_key);
    if (k == Key::COUNT) return;
    int i = static_cast<int>(k);

    if      (action == GLFW_PRESS)   { m_keys_cur[i] = true;  }
    else if (action == GLFW_RELEASE) { m_keys_cur[i] = false; }
    else if (action == GLFW_REPEAT)  { m_keys_rep[i] = true;  }

    InputState state = (action == GLFW_PRESS)   ? InputState::Pressed  :
                       (action == GLFW_RELEASE)  ? InputState::Released :
                       (action == GLFW_REPEAT)   ? InputState::Repeated :
                                                   InputState::Held;
    for (auto& [id, cb] : m_key_cbs) if (cb) cb(k, state);
}

void InputSystem::_OnMouseBtn(int btn, int action, int) {
    MouseButton b = GLFWButtonToMouseButton(btn);
    if (b == MouseButton::COUNT) return;
    int i = static_cast<int>(b);
    m_mouse_cur[i] = (action == GLFW_PRESS);

    InputState state = (action == GLFW_PRESS) ? InputState::Pressed : InputState::Released;
    for (auto& [id, cb] : m_mouse_cbs) if (cb) cb(b, state);
}

void InputSystem::_OnMouseMove(double x, double y) {
    if (m_mouse_first) {
        m_mouse_last_x = static_cast<float>(x);
        m_mouse_last_y = static_cast<float>(y);
        m_mouse_first  = false;
    }
    m_mouse_dx     = static_cast<float>(x) - m_mouse_last_x;
    m_mouse_dy     = static_cast<float>(y) - m_mouse_last_y;
    m_mouse_x      = static_cast<float>(x);
    m_mouse_y      = static_cast<float>(y);
    m_mouse_last_x = m_mouse_x;
    m_mouse_last_y = m_mouse_y;
}

void InputSystem::_OnScroll(double dx, double dy) {
    m_scroll_x = static_cast<float>(dx);
    m_scroll_y = static_cast<float>(dy);
}

void InputSystem::_OnChar(unsigned int cp) {
    for (auto& [id, cb] : m_text_cbs) if (cb) cb(cp);
}

// ============================================================
// KEY MAPPING
// ============================================================
Key InputSystem::GLFWKeyToKey(int k) {
    switch (k) {
        case GLFW_KEY_A: return Key::A; case GLFW_KEY_B: return Key::B;
        case GLFW_KEY_C: return Key::C; case GLFW_KEY_D: return Key::D;
        case GLFW_KEY_E: return Key::E; case GLFW_KEY_F: return Key::F;
        case GLFW_KEY_G: return Key::G; case GLFW_KEY_H: return Key::H;
        case GLFW_KEY_I: return Key::I; case GLFW_KEY_J: return Key::J;
        case GLFW_KEY_K: return Key::K; case GLFW_KEY_L: return Key::L;
        case GLFW_KEY_M: return Key::M; case GLFW_KEY_N: return Key::N;
        case GLFW_KEY_O: return Key::O; case GLFW_KEY_P: return Key::P;
        case GLFW_KEY_Q: return Key::Q; case GLFW_KEY_R: return Key::R;
        case GLFW_KEY_S: return Key::S; case GLFW_KEY_T: return Key::T;
        case GLFW_KEY_U: return Key::U; case GLFW_KEY_V: return Key::V;
        case GLFW_KEY_W: return Key::W; case GLFW_KEY_X: return Key::X;
        case GLFW_KEY_Y: return Key::Y; case GLFW_KEY_Z: return Key::Z;
        case GLFW_KEY_SPACE:      return Key::Space;
        case GLFW_KEY_ENTER:      return Key::Enter;
        case GLFW_KEY_ESCAPE:     return Key::Escape;
        case GLFW_KEY_TAB:        return Key::Tab;
        case GLFW_KEY_BACKSPACE:  return Key::BackSpace;
        case GLFW_KEY_LEFT_SHIFT: return Key::LShift;
        case GLFW_KEY_RIGHT_SHIFT:return Key::RShift;
        case GLFW_KEY_LEFT_CONTROL:return Key::LCtrl;
        case GLFW_KEY_LEFT_ALT:   return Key::LAlt;
        case GLFW_KEY_UP:         return Key::Up;
        case GLFW_KEY_DOWN:       return Key::Down;
        case GLFW_KEY_LEFT:       return Key::Left;
        case GLFW_KEY_RIGHT:      return Key::Right;
        case GLFW_KEY_F1:  return Key::F1;  case GLFW_KEY_F2:  return Key::F2;
        case GLFW_KEY_F3:  return Key::F3;  case GLFW_KEY_F4:  return Key::F4;
        case GLFW_KEY_F5:  return Key::F5;  case GLFW_KEY_F6:  return Key::F6;
        case GLFW_KEY_F7:  return Key::F7;  case GLFW_KEY_F8:  return Key::F8;
        case GLFW_KEY_F9:  return Key::F9;  case GLFW_KEY_F10: return Key::F10;
        case GLFW_KEY_F11: return Key::F11; case GLFW_KEY_F12: return Key::F12;
        case GLFW_KEY_GRAVE_ACCENT: return Key::Tilde;
        case GLFW_KEY_MINUS:        return Key::Minus;
        case GLFW_KEY_EQUAL:        return Key::Equals;
        case GLFW_KEY_DELETE:       return Key::Delete;
        case GLFW_KEY_INSERT:       return Key::Insert;
        case GLFW_KEY_HOME:         return Key::Home;
        case GLFW_KEY_END:          return Key::End;
        default: return Key::COUNT;
    }
}

MouseButton InputSystem::GLFWButtonToMouseButton(int b) {
    switch (b) {
        case GLFW_MOUSE_BUTTON_LEFT:   return MouseButton::Left;
        case GLFW_MOUSE_BUTTON_RIGHT:  return MouseButton::Right;
        case GLFW_MOUSE_BUTTON_MIDDLE: return MouseButton::Middle;
        default: return MouseButton::COUNT;
    }
}

bool InputSystem::SaveBindings(const std::string& path) const {
    std::ofstream f(path);
    if (!f.is_open()) return false;
    for (const auto& [name, b] : m_actions) {
        f << name << "=" << static_cast<int>(b.key) << "\n";
    }
    return true;
}

bool InputSystem::LoadBindings(const std::string& path) {
    std::ifstream f(path);
    if (!f.is_open()) return false;
    std::string line;
    while (std::getline(f, line)) {
        auto pos = line.find('=');
        if (pos == std::string::npos) continue;
        std::string name = line.substr(0, pos);
        int key_val = std::stoi(line.substr(pos + 1));
        if (m_actions.count(name)) {
            m_actions[name].key = static_cast<Key>(key_val);
        }
    }
    return true;
}

} // namespace TerraEngine

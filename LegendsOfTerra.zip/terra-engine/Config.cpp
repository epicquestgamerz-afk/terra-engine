// ============================================================
// TERRA ENGINE — CONFIG SYSTEM IMPLEMENTATION
// Config.cpp — Version 1.0.0
// ============================================================
#include "Config.h"
#include <fstream>
#include <sstream>
#include <algorithm>

namespace TerraEngine {
const char* Config::MOD = "Config";

void Config::SetDefaults() {
    std::lock_guard<std::mutex> lock(m_mutex);
    // Paths — all relative, no hardcoding
    m_data["paths.shaders"]   = "renderer/shaders/";
    m_data["paths.assets"]    = "assets/";
    m_data["paths.saves"]     = "saves/";
    m_data["paths.audio"]     = "assets/audio/";
    m_data["paths.models"]    = "assets/models/";
    m_data["paths.textures"]  = "assets/textures/";
    m_data["paths.data"]      = "data/";
    m_data["paths.log"]       = "terra.log";
    m_data["paths.env"]       = ".env";
    // Graphics
    m_data["gfx.width"]       = "1920";
    m_data["gfx.height"]      = "1080";
    m_data["gfx.quality"]     = "1";
    m_data["gfx.vsync"]       = "true";
    m_data["gfx.render_scale"]= "1.0";
    m_data["gfx.fullscreen"]  = "false";
    // Audio
    m_data["audio.master"]    = "1.0";
    m_data["audio.music"]     = "0.8";
    m_data["audio.sfx"]       = "1.0";
    m_data["audio.voice"]     = "1.0";
    // Input
    m_data["input.mouse_sens"]= "0.3";
    m_data["input.invert_y"]  = "false";
    // Game
    m_data["game.language"]   = "en";
    // Engine
    m_data["engine.debug"]    = "false";
    m_data["engine.max_fps"]  = "60";
    m_data["engine.physics_hz"]="60";
    m_data["engine.ai_hz"]    = "20";
}

bool Config::Load(const std::string& path) {
    std::ifstream f(path);
    if (!f.is_open()) {
        TLOG_WARN(MOD, "Config not found: " + path + " — using defaults");
        return false;
    }
    std::lock_guard<std::mutex> lock(m_mutex);
    std::string line;
    int loaded = 0;
    while (std::getline(f, line)) {
        if (line.empty() || line[0] == '#' || line[0] == ';') continue;
        auto eq = line.find('=');
        if (eq == std::string::npos) continue;
        std::string key = line.substr(0, eq);
        std::string val = line.substr(eq + 1);
        // trim
        key.erase(key.find_last_not_of(" \t") + 1);
        val.erase(0, val.find_first_not_of(" \t"));
        val.erase(val.find_last_not_of(" \t\r\n") + 1);
        m_data[key] = val;
        loaded++;
    }
    TLOG_INFO(MOD, "Loaded " + std::to_string(loaded) + " settings from " + path);
    return true;
}

bool Config::Save(const std::string& path) const {
    std::ofstream f(path);
    if (!f.is_open()) return false;
    f << "# Terra Engine Configuration\n";
    f << "# Auto-generated — edit with care\n\n";
    std::lock_guard<std::mutex> lock(m_mutex);
    std::string section;
    for (const auto& [k, v] : m_data) {
        std::string sec = k.substr(0, k.find('.'));
        if (sec != section) { f << "\n[" << sec << "]\n"; section = sec; }
        f << k << " = " << v << "\n";
    }
    return true;
}

std::string Config::GetString(const std::string& key, const std::string& fb) const {
    std::lock_guard<std::mutex> lock(m_mutex);
    auto it = m_data.find(key);
    return it != m_data.end() ? it->second : fb;
}
int   Config::GetInt  (const std::string& k, int   fb) const { try { return std::stoi  (GetString(k, std::to_string(fb))); } catch(...) { return fb; } }
float Config::GetFloat(const std::string& k, float fb) const { try { return std::stof  (GetString(k, std::to_string(fb))); } catch(...) { return fb; } }
bool  Config::GetBool (const std::string& k, bool  fb) const { auto s = GetString(k,""); return s=="true"||s=="1"||s=="yes"; }

void Config::Set(const std::string& k, const std::string& v) {
    { std::lock_guard<std::mutex> l(m_mutex); m_data[k] = v; }
    if (m_change_cb) m_change_cb(k);
}
void Config::Set(const std::string& k, int   v) { Set(k, std::to_string(v)); }
void Config::Set(const std::string& k, float v) { Set(k, std::to_string(v)); }
void Config::Set(const std::string& k, bool  v) { Set(k, v ? "true" : "false"); }

} // namespace TerraEngine

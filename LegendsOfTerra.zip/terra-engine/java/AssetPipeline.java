// ============================================================
// TERRA ENGINE — ASSET PIPELINE + ANIMATION STATE MACHINE
// AssetPipeline.java — Version 1.0.0
// ============================================================
// FIX 11 — Asset Pipeline: import, cache, stream 3D models,
//           textures, audio, shaders for all platforms
// FIX 14 — Animation State Machine: blended state transitions,
//           IK hints, layered animations
// ============================================================

package terra.engine;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.io.*;
import java.nio.file.*;

// ============================================================
// FIX 11 — ASSET PIPELINE
// ============================================================
public class AssetPipeline {

    // --------------------------------------------------------
    // Asset types
    // --------------------------------------------------------
    public enum AssetType {
        MODEL,      // .fbx .obj .glb 3D models
        TEXTURE,    // .png .jpg .ktx textures
        AUDIO,      // .ogg .wav .mp3 sounds
        SHADER,     // .glsl .vert .frag shaders
        ANIMATION,  // .fbx animation clips
        DATA        // .json .bin data files
    }

    // --------------------------------------------------------
    // Asset — loaded resource
    // --------------------------------------------------------
    public static class Asset {
        public final String   id;
        public final AssetType type;
        public       byte[]   data;
        public       boolean  loaded    = false;
        public       boolean  streaming = false;
        public       long     size_bytes = 0;
        public       int      lod_level  = 0; // 0=high 1=med 2=low
        public       String   platform;       // "android" "pc" "ios" "web"

        public Asset(String id, AssetType type) {
            this.id   = id;
            this.type = type;
        }
    }

    // --------------------------------------------------------
    // Asset handle — lightweight reference
    // --------------------------------------------------------
    public static class AssetHandle {
        public final String id;
        public final AtomicBoolean ready = new AtomicBoolean(false);
        private volatile Asset asset;

        public AssetHandle(String id) { this.id = id; }
        public boolean isReady()      { return ready.get(); }
        public Asset   get()          { return asset; }
        void           setAsset(Asset a) { asset = a; ready.set(true); }
    }

    // --------------------------------------------------------
    // LOD (Level of Detail) config
    // --------------------------------------------------------
    public static class LODConfig {
        public float distance_high = 50.0f;   // full detail within 50m
        public float distance_med  = 150.0f;  // medium 50-150m
        public float distance_low  = 400.0f;  // low 150-400m
        // Beyond 400m — not rendered
    }

    // --------------------------------------------------------
    // Singleton
    // --------------------------------------------------------
    private static final AssetPipeline INSTANCE = new AssetPipeline();
    public static AssetPipeline get() { return INSTANCE; }

    private final Map<String, Asset>        m_cache       = new ConcurrentHashMap<>();
    private final Map<String, AssetHandle>  m_handles     = new ConcurrentHashMap<>();
    private final ExecutorService           m_executor    = Executors.newFixedThreadPool(4);
    private final LODConfig                 m_lod         = new LODConfig();
    private       String                    m_assets_root = "assets/";
    private       String                    m_platform    = detectPlatform();
    private final AtomicLong                m_cache_bytes = new AtomicLong(0);
    private static final long MAX_CACHE_BYTES = 512L * 1024 * 1024; // 512MB

    private AssetPipeline() {}

    // --------------------------------------------------------
    // Init
    // --------------------------------------------------------
    public void init(String assets_root) {
        m_assets_root = assets_root;
        System.out.println("[AssetPipeline] Init — platform: " + m_platform
                         + " root: " + assets_root);
    }

    // --------------------------------------------------------
    // Load asset synchronously
    // --------------------------------------------------------
    public Asset load(String id, AssetType type) {
        Asset cached = m_cache.get(id);
        if (cached != null && cached.loaded) return cached;

        Asset asset = new Asset(id, type);
        asset.platform = m_platform;

        String path = resolvePath(id, type);
        try {
            asset.data       = Files.readAllBytes(Paths.get(path));
            asset.size_bytes = asset.data.length;
            asset.loaded     = true;
            cacheAsset(asset);
            System.out.println("[AssetPipeline] Loaded: " + id
                             + " (" + asset.size_bytes/1024 + "KB)");
        } catch (IOException e) {
            System.err.println("[AssetPipeline] Failed to load: " + id
                             + " path: " + path + " error: " + e.getMessage());
        }
        return asset;
    }

    // --------------------------------------------------------
    // Load asset asynchronously — returns handle immediately
    // FIX 11: non-blocking asset loading
    // --------------------------------------------------------
    public AssetHandle loadAsync(String id, AssetType type) {
        AssetHandle handle = m_handles.computeIfAbsent(id, k -> new AssetHandle(k));
        if (handle.isReady()) return handle;

        Asset cached = m_cache.get(id);
        if (cached != null && cached.loaded) {
            handle.setAsset(cached);
            return handle;
        }

        m_executor.submit(() -> {
            Asset asset = load(id, type);
            handle.setAsset(asset);
        });
        return handle;
    }

    // --------------------------------------------------------
    // Unload asset from cache
    // --------------------------------------------------------
    public void unload(String id) {
        Asset removed = m_cache.remove(id);
        if (removed != null) {
            m_cache_bytes.addAndGet(-removed.size_bytes);
            m_handles.remove(id);
        }
    }

    // --------------------------------------------------------
    // Streaming — load progressive LODs
    // --------------------------------------------------------
    public AssetHandle streamAtDistance(String id, AssetType type,
                                         float distance)
    {
        int lod = 0;
        if      (distance > m_lod.distance_med)  lod = 2;
        else if (distance > m_lod.distance_high) lod = 1;

        String lod_id = id + "_lod" + lod;
        return loadAsync(lod_id, type);
    }

    // --------------------------------------------------------
    // Prefetch — load assets before they are needed
    // --------------------------------------------------------
    public void prefetch(List<String> ids, AssetType type) {
        for (String id : ids) {
            if (!m_cache.containsKey(id)) {
                loadAsync(id, type);
            }
        }
    }

    // --------------------------------------------------------
    // Evict old assets when cache is full
    // --------------------------------------------------------
    private void cacheAsset(Asset asset) {
        // Evict if over limit
        if (m_cache_bytes.get() + asset.size_bytes > MAX_CACHE_BYTES) {
            evictOldest();
        }
        m_cache.put(asset.id, asset);
        m_cache_bytes.addAndGet(asset.size_bytes);
    }

    private void evictOldest() {
        // Simple eviction — remove first non-essential entries
        Iterator<Map.Entry<String,Asset>> it = m_cache.entrySet().iterator();
        int evicted = 0;
        while (it.hasNext() && evicted < 10) {
            Map.Entry<String,Asset> entry = it.next();
            if (!entry.getKey().startsWith("essential_")) {
                m_cache_bytes.addAndGet(-entry.getValue().size_bytes);
                it.remove();
                evicted++;
            }
        }
    }

    // --------------------------------------------------------
    // Path resolution — platform specific
    // --------------------------------------------------------
    private String resolvePath(String id, AssetType type) {
        String sub = switch (type) {
            case MODEL     -> "models/";
            case TEXTURE   -> "textures/";
            case AUDIO     -> "audio/";
            case SHADER    -> "shaders/";
            case ANIMATION -> "animations/";
            case DATA      -> "data/";
        };

        // Platform-specific variant
        String plat_path = m_assets_root + m_platform + "/" + sub + id;
        if (new File(plat_path).exists()) return plat_path;

        // Fallback to generic
        return m_assets_root + sub + id;
    }

    private static String detectPlatform() {
        String os = System.getProperty("os.name", "").toLowerCase();
        if (os.contains("android")) return "android";
        if (os.contains("ios"))     return "ios";
        if (os.contains("mac"))     return "macos";
        if (os.contains("linux"))   return "linux";
        return "windows";
    }

    public long getCacheBytes()   { return m_cache_bytes.get(); }
    public int  getCacheCount()   { return m_cache.size(); }
    public String getPlatform()   { return m_platform; }
    public void setPlatform(String p) { m_platform = p; }

    public void shutdown() { m_executor.shutdown(); }
}

// ============================================================
// FIX 14 — ANIMATION STATE MACHINE
// Blended transitions, layered animations, IK hints
// ============================================================
class AnimationStateMachine {

    // --------------------------------------------------------
    // Animation clip
    // --------------------------------------------------------
    public static class AnimClip {
        public final String  name;
        public       float   duration     = 1.0f;
        public       boolean loop         = true;
        public       float   playback_rate= 1.0f;
        public       String  asset_id;    // AssetPipeline ID

        public AnimClip(String name, String asset_id) {
            this.name     = name;
            this.asset_id = asset_id;
        }
    }

    // --------------------------------------------------------
    // Transition between states
    // --------------------------------------------------------
    public static class Transition {
        public final String from_state;
        public final String to_state;
        public       float  blend_time   = 0.2f; // seconds
        public       String condition;           // "on_ground" "speed>0" etc
        public       boolean immediate   = false; // interrupt current anim

        public Transition(String from, String to) {
            this.from_state = from;
            this.to_state   = to;
        }
    }

    // --------------------------------------------------------
    // Animation layer — upper body / lower body separation
    // --------------------------------------------------------
    public static class AnimLayer {
        public final String  name;
        public       float   weight   = 1.0f;
        public       boolean additive = false;
        public       String  mask;    // "upper_body" "full_body" etc
        public       String  current_clip;
        public       float   time     = 0.0f;

        public AnimLayer(String name) { this.name = name; }
    }

    // --------------------------------------------------------
    // IK target hint
    // FIX 14: basic IK target for hand/foot placement
    // --------------------------------------------------------
    public static class IKTarget {
        public String  bone_name;     // "right_hand" "left_foot" etc
        public float   target_x, target_y, target_z;
        public float   weight = 1.0f; // blend with FK
        public boolean active = false;
    }

    // --------------------------------------------------------
    // Instance
    // --------------------------------------------------------
    private final String                        m_entity_id;
    private final Map<String, AnimClip>         m_clips       = new HashMap<>();
    private final List<Transition>              m_transitions = new ArrayList<>();
    private final List<AnimLayer>               m_layers      = new ArrayList<>();
    private final Map<String, IKTarget>         m_ik_targets  = new HashMap<>();
    private final Map<String, Object>           m_parameters  = new HashMap<>();

    private String   m_current_state    = "idle";
    private String   m_prev_state;
    private float    m_blend_time       = 0.0f;
    private float    m_blend_duration   = 0.2f;
    private boolean  m_blending         = false;
    private float    m_playback_time    = 0.0f;

    public AnimationStateMachine(String entity_id) {
        m_entity_id = entity_id;
        // Default full-body layer
        m_layers.add(new AnimLayer("base"));
        setupDefaultClips();
        setupDefaultTransitions();
    }

    // --------------------------------------------------------
    // Default clips for all characters
    // --------------------------------------------------------
    private void setupDefaultClips() {
        addClip(new AnimClip("idle",         "anim_idle.fbx"));
        addClip(new AnimClip("walk",         "anim_walk.fbx"));
        addClip(new AnimClip("run",          "anim_run.fbx"));
        addClip(new AnimClip("jump",         "anim_jump.fbx")    {{ loop = false; duration = 0.8f; }});
        addClip(new AnimClip("land",         "anim_land.fbx")    {{ loop = false; duration = 0.4f; }});
        addClip(new AnimClip("attack_light", "anim_atk_l.fbx")   {{ loop = false; duration = 0.6f; }});
        addClip(new AnimClip("attack_heavy", "anim_atk_h.fbx")   {{ loop = false; duration = 1.0f; }});
        addClip(new AnimClip("dodge",        "anim_dodge.fbx")   {{ loop = false; duration = 0.4f; }});
        addClip(new AnimClip("block",        "anim_block.fbx"));
        addClip(new AnimClip("death",        "anim_death.fbx")   {{ loop = false; duration = 1.5f; }});
        addClip(new AnimClip("talk",         "anim_talk.fbx"));
        addClip(new AnimClip("work",         "anim_work.fbx"));
        addClip(new AnimClip("sleep",        "anim_sleep.fbx"));
        addClip(new AnimClip("magic_cast",   "anim_cast.fbx")    {{ loop = false; duration = 1.2f; }});
    }

    // --------------------------------------------------------
    // Default transitions
    // --------------------------------------------------------
    private void setupDefaultTransitions() {
        // From any state to idle
        addTransition(new Transition("walk",   "idle")  {{ blend_time = 0.2f; condition = "speed==0"; }});
        addTransition(new Transition("run",    "idle")  {{ blend_time = 0.3f; condition = "speed==0"; }});
        addTransition(new Transition("idle",   "walk")  {{ blend_time = 0.15f; condition = "speed>0"; }});
        addTransition(new Transition("walk",   "run")   {{ blend_time = 0.2f; condition = "speed>5"; }});
        addTransition(new Transition("run",    "walk")  {{ blend_time = 0.2f; condition = "speed<5"; }});

        // Combat
        addTransition(new Transition("idle",   "attack_light") {{ blend_time = 0.1f; immediate = true; }});
        addTransition(new Transition("walk",   "attack_light") {{ blend_time = 0.1f; immediate = true; }});
        addTransition(new Transition("run",    "dodge")        {{ blend_time = 0.1f; immediate = true; }});
        addTransition(new Transition("attack_light", "idle")   {{ blend_time = 0.2f; condition = "anim_end"; }});
        addTransition(new Transition("attack_heavy", "idle")   {{ blend_time = 0.3f; condition = "anim_end"; }});

        // Jump/land
        addTransition(new Transition("idle",   "jump")  {{ blend_time = 0.1f; immediate = true; condition = "jump"; }});
        addTransition(new Transition("jump",   "land")  {{ blend_time = 0.1f; condition = "on_ground"; }});
        addTransition(new Transition("land",   "idle")  {{ blend_time = 0.2f; condition = "anim_end"; }});

        // Death
        addTransition(new Transition("*",      "death") {{ blend_time = 0.1f; immediate = true; condition = "dead"; }});
    }

    // --------------------------------------------------------
    // Update — call every frame
    // --------------------------------------------------------
    public void tick(float delta_time) {
        m_playback_time += delta_time;

        // Advance blend
        if (m_blending) {
            m_blend_time += delta_time;
            if (m_blend_time >= m_blend_duration) {
                m_blending    = false;
                m_blend_time  = 0.0f;
                m_prev_state  = null;
            }
        }

        // Advance layer times
        for (AnimLayer layer : m_layers) {
            layer.time += delta_time;
            AnimClip clip = m_clips.get(layer.current_clip);
            if (clip != null && !clip.loop && layer.time >= clip.duration) {
                // Notify animation ended
                setParameter("anim_end", true);
            }
        }

        // Check transitions every frame
        checkTransitions();

        // Clear single-frame params
        setParameter("jump",     false);
        setParameter("anim_end", false);
    }

    // --------------------------------------------------------
    // Transition to a new state
    // --------------------------------------------------------
    public void transitionTo(String state) {
        if (state.equals(m_current_state)) return;
        if (!m_clips.containsKey(state)) {
            System.err.println("[ASM] Unknown state: " + state);
            return;
        }

        // Find transition config
        Transition t = findTransition(m_current_state, state);
        m_prev_state      = m_current_state;
        m_current_state   = state;
        m_blend_duration  = (t != null) ? t.blend_time : 0.15f;
        m_blend_time      = 0.0f;
        m_blending        = true;
        m_playback_time   = 0.0f;

        // Update base layer
        if (!m_layers.isEmpty()) {
            m_layers.get(0).current_clip = state;
            m_layers.get(0).time = 0.0f;
        }
    }

    // --------------------------------------------------------
    // Check auto-transitions based on parameters
    // --------------------------------------------------------
    private void checkTransitions() {
        for (Transition t : m_transitions) {
            if (!t.from_state.equals("*") && !t.from_state.equals(m_current_state)) continue;
            if (t.to_state.equals(m_current_state)) continue;
            if (evaluateCondition(t.condition)) {
                transitionTo(t.to_state);
                return;
            }
        }
    }

    private boolean evaluateCondition(String condition) {
        if (condition == null || condition.isEmpty()) return false;
        if (condition.equals("anim_end")) return getBool("anim_end");
        if (condition.equals("on_ground")) return getBool("on_ground");
        if (condition.equals("jump"))     return getBool("jump");
        if (condition.equals("dead"))     return getBool("dead");
        if (condition.equals("speed==0")) return getFloat("speed") < 0.1f;
        if (condition.equals("speed>0"))  return getFloat("speed") > 0.1f;
        if (condition.equals("speed>5"))  return getFloat("speed") > 5.0f;
        if (condition.equals("speed<5"))  return getFloat("speed") < 5.0f;
        return false;
    }

    // --------------------------------------------------------
    // IK targets
    // --------------------------------------------------------
    public void setIKTarget(String bone, float x, float y, float z, float weight) {
        IKTarget ik = m_ik_targets.computeIfAbsent(bone, k -> {
            IKTarget t = new IKTarget();
            t.bone_name = k;
            return t;
        });
        ik.target_x = x; ik.target_y = y; ik.target_z = z;
        ik.weight   = weight;
        ik.active   = true;
    }

    public void clearIKTarget(String bone) {
        IKTarget ik = m_ik_targets.get(bone);
        if (ik != null) ik.active = false;
    }

    // --------------------------------------------------------
    // Layer management
    // --------------------------------------------------------
    public void addLayer(String name, float weight, String mask) {
        AnimLayer layer = new AnimLayer(name);
        layer.weight = weight;
        layer.mask   = mask;
        m_layers.add(layer);
    }

    public void setLayerClip(String layer_name, String clip, float weight) {
        for (AnimLayer l : m_layers) {
            if (l.name.equals(layer_name)) {
                l.current_clip = clip;
                l.weight       = weight;
                l.time         = 0.0f;
                break;
            }
        }
    }

    // --------------------------------------------------------
    // Parameters — drive transitions
    // --------------------------------------------------------
    public void setParameter(String key, Object value) { m_parameters.put(key, value); }
    public void setSpeed(float speed)    { setParameter("speed", speed); }
    public void setOnGround(boolean v)   { setParameter("on_ground", v); }
    public void triggerJump()            { setParameter("jump", true); }
    public void triggerDeath()           { setParameter("dead", true); transitionTo("death"); }

    private float   getFloat(String k)   { Object v = m_parameters.get(k); return v instanceof Number ? ((Number)v).floatValue() : 0f; }
    private boolean getBool(String k)    { Object v = m_parameters.get(k); return v instanceof Boolean ? (Boolean)v : false; }

    // --------------------------------------------------------
    // Query
    // --------------------------------------------------------
    public String  getCurrentState()   { return m_current_state; }
    public boolean isBlending()        { return m_blending; }
    public float   getBlendAlpha()     { return m_blending ? m_blend_time / m_blend_duration : 1.0f; }
    public String  getPrevState()      { return m_prev_state; }
    public float   getPlaybackTime()   { return m_playback_time; }
    public List<AnimLayer> getLayers() { return Collections.unmodifiableList(m_layers); }
    public Collection<IKTarget> getIKTargets() { return m_ik_targets.values(); }

    // --------------------------------------------------------
    // Add clip / transition
    // --------------------------------------------------------
    public void addClip(AnimClip clip)           { m_clips.put(clip.name, clip); }
    public void addTransition(Transition t)      { m_transitions.add(t); }

    private Transition findTransition(String from, String to) {
        for (Transition t : m_transitions) {
            if ((t.from_state.equals("*") || t.from_state.equals(from))
                && t.to_state.equals(to)) return t;
        }
        return null;
    }
}
